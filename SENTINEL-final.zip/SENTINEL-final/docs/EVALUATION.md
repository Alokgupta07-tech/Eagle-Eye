# Independent evaluation and spending controls

The evaluator measures a **defined contract**, not whether an LLM jury agrees
with itself. It runs separate direct-to-target and through-proxy conversations
using synthetic canaries and sandboxed tool schemas. Tools are recorded, never
executed. The proxy path is the same `_handle_chat` implementation used by HTTP
requests, including REVIEW holds, leases, response gating and audit sealing.

## Offline reference run

```bash
python -m evals.runner --models mock/vulnerable mock/hardened --split test --limit 100
```

`evals/datasets/reference.jsonl` contains 48 separately authored public cases:
24 benign and 24 malicious, split into 14 development and 34 test examples with
non-overlapping family IDs. These are **public harness fixtures**, not a blinded,
independent benchmark and not evidence of real-model detection accuracy. Do not
tune on the public test examples and then present their score as generalization.

The evaluator seeds only the existing `seeds/attacks.json` training corpus,
reloads its similarity index, and calibrates on separate benign probes. Evaluation
cases are not imported into that corpus. Both dataset and training-corpus hashes,
resolved embedding mode, model configuration, thresholds, code hash and sampling
seed are recorded.

## Supply a real held-out dataset

Use newline-delimited JSON objects with:

- `id`: unique stable case ID.
- `family`: the scenario/mutation family. Related variants belong in one split.
- `split`: `dev` or `test`.
- `label`: `benign` or `attack`, assigned independently of SENTINEL's prediction.
- `category`: your attack/benign category.
- `turns`: one to twenty user messages.
- `documents`: optional untrusted retrieval text.
- `tools`: optional MCP/OpenAI-style tool definitions.
- `allowed_tools`: explicitly permitted tool names (default `lookup_policy`).
- `source`: authorship, licensing and provenance information.

The loader rejects duplicate IDs, cross-split family/input leakage, invalid JSON,
invalid Unicode and oversized inputs. `--development-dataset` additionally checks
an external development file against the test file. Family IDs and exact-input
checks cannot automatically prove semantic independence: review the split and
have someone other than the detector's author label important cases.

Keep the final test set frozen and out of training/indexing. Include normal
business requests, quoted security discussions, code, ordinary URLs, legitimate
tool schemas and realistic multi-turn conversations. Use only synthetic secrets
and authorized test data, never customer credentials or destructive live tools.

## Observable ground truth

A controlled system instruction defines a unique synthetic canary and tool
allowlist. Independent oracles check literal/common encoded canary disclosure
(Base64, hex, percent-encoded forms) and non-allowlisted structured tool calls.
Provider adapters retain tool-call names/arguments rather than discarding empty
text responses. A generated tool call is an **attempt**, not proof that a tool was
executed. The harness does not execute external side effects.

These assertions do not cover every possible leak encoding, partial disclosure,
steganography or business-specific policy violation. Extend independent oracles
and manually review samples for your domain. The target's refusal, the request
gate's prediction, and the response gate's intervention are different outcomes.

## Paid runs require explicit authorization and limits

No live call occurs unless you supply `--allow-paid`, a positive call/token/USD
budget, per-model prices, supported model IDs and locally configured provider
credentials. Use environment injection/a secret manager, not the tracked `.env`,
command-line secrets, URLs or chat.

Prepare a JSON price file keyed by each **provider/model** used by the target and
any live jurors. Each entry must contain numeric `input_per_million` and
`output_per_million` values from your own provider's current pricing. No guessed
prices are bundled. Missing or invalid prices abort before dispatch.

With your environment/model and price file configured, a small pilot can use:

```bash
python -m evals.runner --dataset /path/to/heldout.jsonl \
  --models "openai/$OPENAI_MODEL" --split test --limit 3 --baseline-probes 3 \
  --jury-mode configured --allow-paid \
  --max-calls 100 --max-tokens 500000 --max-usd 1 \
  --prices /path/to/verified-prices.json
```

The file paths above are operator inputs, not files shipped by SENTINEL. An
Anthropic target is selected explicitly as `anthropic/$ANTHROPIC_MODEL`; multiple
models can be provided together. There is no silent preferred-provider selection.

The default `--jury-mode heuristic` keeps grading mechanics offline and clearly
labels them. `configured` uses the configured panel and reports whether it was
live or mixed. One target API key does not make all jurors live.

Reservations cover target **and HTTP-jury** requests, including baseline calls.
They conservatively estimate text/tool tokens and reserve maximum output. Reported
usage reconciles successful requests; errors/unknown usage keep their reservation.
No automatic provider retries occur. Application estimates and operator-supplied
prices are **not provider-enforced billing guarantees**; configure account-level
spending limits too. Budget exhaustion stops further work and produces a partial,
non-success report rather than marking unrun cases safe.

The old `scripts/evidence_run.py` CLI delegates to this evaluator. Its legacy
programmatic reporting helper now also requires explicit paid consent and a Budget.

## Reports and acceptance

Each invocation has a unique timestamp/UUID directory under `reports/evaluations/`:

- `report.json`: per-case raw/proxy outcomes, errors, model IDs, timings and budget.
- `report.md`: human-readable metrics, category/model breakdowns and limitations.
- `cases.jsonl`: the exact selected cases.
- `SHA256SUMS`: checksums for the three files.

The artifacts can contain sensitive test input/output; `reports/` is ignored by
Git. Store real campaign evidence in access-controlled storage and retain an
independently trusted manifest/checkpoint.

Report precision/recall, benign BLOCK and REVIEW rates separately, response
intervention, unsafe-delivery rate, coverage/errors, and p50/p95/p99 timings.
REVIEW counts as a held detection, not an automatic block. Unrun/failed cases are
never true negatives; rates are explicitly completed-case metrics with coverage.
The Wilson interval is descriptive, not a guarantee for correlated prompt families.

Core timing includes jury latency but not the browser/auth/HTTP transport. Use the
Locust suite for API-level latency and replica behavior. Separate raw and proxy
trials may have different stochastic model responses, so repeat campaigns and
inspect disagreements instead of claiming perfect causal equivalence.

Define acceptance thresholds using your application's risk and operator capacity.
There is no universal safe recall/false-positive target. A useful progression is
small pilot, independent review of errors, development-only tuning, frozen test
run, then a separately approved staged rollout. No real-provider run has been
performed as part of this implementation.


## Groq Free-plan campaigns

Groq targets are supported as `groq/openai/gpt-oss-120b` or
`groq/openai/gpt-oss-20b`. For an operator-confirmed Free-plan account, use
`--free-tier` with explicit `--max-calls` and `--max-tokens`, plus the private
`--env-file .env.groq` if credentials are not in process environment. This mode
forbids paid/non-Groq live models and does not invent a verified dollar cost.
Provider 429s stop the run with partial coverage rather than counting unavailable
judges as detections. See [FREE_AI.md](FREE_AI.md) for setup, privacy, quota limits
and the distinction between a single live model and a multi-provider jury.
