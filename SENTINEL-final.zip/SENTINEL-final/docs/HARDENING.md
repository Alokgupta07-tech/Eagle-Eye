# SENTINEL security model, deployment and migration

For the current production setup, identity flow and durability guarantees, also read
[PRODUCTION.md](PRODUCTION.md), [EVALUATION.md](EVALUATION.md) and [TESTING.md](TESTING.md).

## What is enforced

| Boundary | Implemented behavior |
|---|---|
| Control plane | OIDC issuer/audience/signature validation and route-level roles in production; constant-time admin API keys remain available for the lab. Reports, executions, comparison exports and operator actions are authenticated. |
| Data plane | OIDC proxy permission or a constant-time machine key in production. Live BLOCK never dispatches; live REVIEW waits for an authorized operator. |
| Quarantine | A five-minute default lease holds the original request, tools, inspection and conversation snapshot. The snapshot has its own HMAC. Atomic consumption prevents approval replay, including concurrent approvals. Expired snapshots are removed; audit evidence remains. |
| Request inspection | Full tool-definition JSON and the message enter the same session-aware engine. Decode variants include punctuation-delimited Base64/hex, keyword-gated ROT13, homoglyphs, spaced keywords, nested JSON/string and HTML-entity views, leetspeak, interior-anagram folding, hidden markup and Unicode format controls. |
| ASCII smuggling | The entire Unicode Tags range `U+E0000–U+E007F` is removed. Tag-bearing requests trigger review. The target adapter also strips invisible controls from messages and nested tool definitions; normalized key collisions fail closed. |
| Multi-turn targets | Batch and live HTTP adapters send accumulated user/assistant history. Anthropic receives system text in its separate `system` field. Each batch turn is response-inspected, and an early proven compromise is retained even if the final reply refuses. |
| Response leakage | JWT shapes, whole private-key blocks, AWS access/session shapes, password values and configured internal-host privacy checks augment named secrets and entropy candidates are examined in ordinary text, URL path segments, query/fragment values and Markdown destinations. Percent-encoded values are decoded for inspection and redacted at their original offsets. Named spans take precedence; overlapping spans are merged without leaving secret suffixes. |
| Behavioral drift | Separate request and response centroids are calibrated on benign probes. A bounded per-session, per-target rolling centroid and increasing trajectory identify slow displacement. Baseline changes reset the trajectory. Drift invokes the jury and may require REVIEW; it alone does not prove compromise. |
| Jury activation | Subthreshold rule hints, obfuscation and elevated drift activate request voting even below the normal 30-point band. Missing votes on a suspicious request require review. Every dispatched response is independently inspected; if the configured response-vote quorum is unavailable, the reply is withheld. |
| Session lifecycle | Memory queues have a cancellable async expiration sweep, activity-extended TTL and an LRU capacity bound. Redis queues use transactional append/trim/expire/read and native TTL. Shutdown awaits background task cancellation. |
| SSRF | Registration and every dispatch validate the destination. Only exact supported internal aliases or public HTTP(S) addresses are accepted. All DNS results must be public; loopback, private, link-local, metadata, multicast, reserved, mapped-private and transition addresses are rejected. The validated IP is pinned for the TCP connection with the original Host/TLS identity preserved. Redirects and environment proxies are disabled; model requests have absolute deadlines, a 2 MiB response ceiling and reject compressed responses to avoid decompression amplification. |
| Client identity | Forwarding headers are ignored unless the immediate peer matches `SENTINEL_TRUSTED_PROXIES`. X-Forwarded-For is peeled from right to left across trusted hops only; malformed chains fall back to the direct peer. X-Real-IP is supported for a trusted ingress without XFF. |
| At-rest credentials | New encrypted credentials use PBKDF2-HMAC-SHA256 with 100,000 iterations and a 32-byte derived key, then Fernet authenticated encryption. A configured `SENTINEL_SALT` or independent random 128-bit salt is stored in a versioned envelope. API lists mask both plaintext and ciphertext. |
| Audit integrity | HMAC-SHA256 chains bind the previous hash to canonical JSON. The key is not stored in the database. SQLite `BEGIN IMMEDIATE` and PostgreSQL transaction advisory locks serialize appends across workers. Malformed/non-object JSON and MAC failures return an invalid-chain result with the first bad sequence, not an exception. |
| Browser | A shared same-origin fetch client attaches the admin/proxy headers. Authenticated exports use blobs, not credential-free anchor navigation. Untrusted console text and intercepted schemas use text nodes, not HTML. Page CSP disallows inline scripts. Lab mode permits hosted previews; production rejects framing. OIDC browser sessions use encrypted server-side state, HttpOnly cookies and CSRF protection. Weight previews never replace sealed decisions. |

## Production configuration

The checked-in `.env` and `.env.example` deliberately enable the **public**
`sentinel-admin-demo-key` for reproducible offline demonstrations. Do not expose
that credential on a production service. Generate independent, high-entropy values:

```bash
python -c 'import secrets; print(secrets.token_urlsafe(32))'
```

Use separate generated values for `SENTINEL_ADMIN_KEY`, `SENTINEL_PROXY_KEY`,
`SENTINEL_SECRET` and `SENTINEL_AUDIT_SECRET`. Load them from your secret manager;
do not commit them, place them in URLs or write them to application logs.
`SENTINEL_SALT` is nonsecret but should be installation-specific if configured.
Leaving it empty uses a fresh random salt per credential.

Run with `python run.py`, which binds `0.0.0.0` and disables Uvicorn's independent
proxy-header rewriting. For a direct Uvicorn deployment, use:

```bash
uvicorn app.main:app --host 0.0.0.0 --port 8000 --no-proxy-headers
```

Terminate TLS at your ingress. Configure `SENTINEL_TRUSTED_PROXIES` with only the
actual ingress peer IPs/CIDRs. The ingress must sanitize/append forwarding headers.
Do not use a blanket trust range or put `0.0.0.0/0` in this setting. Keep CORS
same-origin or configure an explicit list of origins. The browser uses relative
API paths, so reverse-proxy and hosted preview URLs do not call browser localhost.

Only public target URLs are accepted, even from an authenticated administrator.
Use `internal://mock`, `internal://mock-hardened`, `internal://mock-rag`,
`internal://mock-rag-hardened`, `internal://openai` or `internal://anthropic` for the
built-in adapters. There is intentionally no private-network SSRF bypass switch.

For multiple replicas, share PostgreSQL, Redis and the same audit/encryption
secrets. Configure ingress quotas and concurrency limits in addition to the
shared identity/IP quotas and durable SQL worker queue. Install `requirements-production.txt` and
`sentence-transformers` backends when using those features. A change of embedding
model requires re-indexing the corpus and rebaselining every target.

## Durable audit keys and old databases

If `SENTINEL_AUDIT_SECRET` is empty, SENTINEL creates a 32-byte random installation
key in a private file (mode `0600`). The default location is `.audit-secret.key`
next to the SQLite database, or `data/.audit-secret.key` for PostgreSQL. An explicit
`SENTINEL_AUDIT_KEY_FILE` overrides that path. Atomic publication prevents workers
from creating different keys. The key survives restarts and is excluded from Git.
An unreadable, insecurely permissioned or malformed existing key fails startup;
SENTINEL never overwrites an existing key. Restore the matching key **before**
starting a restored database: a missing file produces a fresh key, which cannot
verify the previous history.

Back up the key separately from the database and restrict filesystem access.
For multi-host deployments, set the secret through a shared secret manager instead
of relying on local fallback files. Changing or losing the key invalidates existing
HMACs. Key rotation therefore requires an independently verified archive/checkpoint
and a new audit store; historical records are never automatically re-signed.

The repository's original `data/sentinel.db` contains **legacy unkeyed SHA-256**
evidence. It is retained untouched. The hardened default points to
`data/sentinel-secure.db`; run `python scripts/demo_setup.py` to populate that fresh
store. If you deliberately point at a legacy database, schema upgrades preserve its
rows and verification reports a MAC mismatch. This is expected: unkeyed history
cannot honestly be promoted to authenticated history by re-hashing it. Archive it
as legacy evidence and establish a separately verified starting point.

`enc:` credentials from the old unsalted derivation remain readable using their
original `SENTINEL_SECRET`. At database connection time, plaintext/legacy values are
rewritten to `enc:v2:` PBKDF2 ciphertext when that secret is configured. The salt
lives in each envelope, so later changes to `SENTINEL_SALT` do not strand old values.
A wrong encryption secret fails decryption rather than returning plaintext or
silently replacing the stored value.

The `/audit/verify` result exposes `algorithm`, `checked`, `total_records`,
`first_bad_seq`, `reason`, and `verified_head`. Run-scoped verification still checks
the entire chain; `run_records` counts verified matching records before any failure.
Retain verified heads in external append-only/object-lock storage. HMAC prevents
forging content without the key, but a chain in one database **cannot independently
prove that its tail was not deleted or that an older full snapshot was not restored**.

## Operator workflow

1. Submit a live prompt, optionally with MCP/OpenAI tool definitions.
2. ALLOW dispatches. BLOCK does not. REVIEW returns `action: QUARANTINE`,
   `verdict: HELD`, `content: null` and an expiring `quarantine` identifier.
3. Reloading the console restores the authenticated original request and tools via
   `GET /admin/quarantine/{id}` without consuming it. Resolve with
   `POST /admin/quarantine/{id}/resolve` and JSON
   `{"action":"allow_once","reason":"review explanation"}` or
   `{"action":"block","reason":"confirmed injection"}`, using an authorized
   OIDC session/token (or the lab admin header).
4. Approval uses the signed original snapshot and always runs the response gate.
   A second approval receives `410`. Changed snapshots receive `409` and are not
   dispatched. An upstream/inspection error serves no raw reply.
5. Verify the HMAC chain from the console or assessment page. Authenticated Markdown
   and JSON downloads preserve the same evidence as the report view.

Batch assessments remain deliberately **permissive** by default: request findings
are reported while measuring the target's resistance. `enforce_request_block: true`
preflights every turn and prevents the entire pattern from being dispatched if any
request receives BLOCK. Batch REVIEW is not an
interactive operator lease; it is a reported assessment signal. The report names
this policy rather than equating target resistance with firewall interception.

## Remaining deployment limits

- The offline embedder and mock judges are deterministic heuristics. They are useful
  for regression testing and demonstrations, not proof of general prompt-injection
  detection accuracy. Configure independent live providers and run measured evidence
  against representative targets before deployment.
- API-key-only access is a lab mode. Production OIDC/RBAC is implemented, but your
  issuer, callback, roles, MFA and organizational access policy must be configured
  and validated in your actual environment.
- SQL jobs, Redis quotas/leases, idempotency and durable conversation transcripts
  are implemented. They do not make remote side effects exactly once; interrupted
  upstream calls are explicitly indeterminate and are not automatically resent.
- Memory fallback is single-process only. Required Redis failures are not silently
  downgraded. Semantic statistics remain finite-window cache data and may reset
  after Redis data loss; durable served transcripts can rebuild request windows.
- Model requests have bounded bodies and absolute deadlines. Still use ingress
  concurrency/body/deadline limits and an outbound network policy.
- Session windows are finite. A very long or deliberately diluted conversation can
  evade a centroid/rule window; semantic drift is an additional signal, not a proof.
- Genuine binary image data URIs are excluded from generic entropy alarms. This is
  not an image steganography or multimodal content scanner.
- The proxy cannot see external target-side retrieval or internal tool side effects
  unless the target exposes those surfaces. Gate tool execution/retrieval inside
  the target as well; redacting a reply cannot undo a tool that already executed.
- The built-in mock HTTP route is intentionally vulnerable and the RAG lab KB is
  process-local demonstration state. Production mode disables mock HTTP routes and mock dispatch.


## Corpus authoring and privacy-policy additions

See [CONTRIBUTING.md](../CONTRIBUTING.md). New language/rule coverage is exercised
with positive and benign regression cases, not treated as independent accuracy
proof. Normalization is inspection-only: decoded ROT13 or JSON/XML instructions
are never automatically executed upstream. XML entity handling is textual and
never resolves external entities.

`REDACT_INTERNAL_IPS=true` redacts valid RFC 1918 hosts; malformed addresses and
public documentation networks are not internal-host findings. Standard public
RFC 1918 CIDR declarations are also excluded. Networking assistants may opt out of
this response privacy policy without disabling request-side SSRF protections.
Credential-pattern matches are redaction evidence, not cryptographic validation
of an active JWT/key or proof of compromise. Complete and unterminated private-key
material is withheld, not just its BEGIN header.
