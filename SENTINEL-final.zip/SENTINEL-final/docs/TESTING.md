# Validation and evidence

## Offline regression suite

```bash
pip install -r requirements-dev.txt
pytest -q -m 'not integration'
```

The existing 295 hardened-engine tests remain, with additional OIDC/CSRF/RBAC,
quota/lease/idempotency, durable recovery, transport, spending-guard and evaluation
regressions. The suite uses deterministic local data, not real provider accounts.

`pytest -q` runs offline cases and explicitly skips opt-in integration tests. Those
skips are not evidence that real services passed. CI runs a separate real-backend
job and fails if requested services are absent or an implementation falls back.

## Real PostgreSQL and Redis

Use a dedicated database ending in `_test`, then provide both connection URLs:

```bash
pip install -r requirements-production.txt
pytest -q --integration -m integration
```

The command expects `TEST_DATABASE_URL` and `TEST_REDIS_URL` in its environment.
Tests create isolated `sentinel_it_*` schemas and unique Redis prefixes, removing
only their own data. They never issue FLUSHDB/FLUSHALL. Do not use production data
or credentials, even though schema/key cleanup is scoped.

Real-service coverage includes:

- Concurrent startup/migrations and HMAC appenders across application instances.
- Redis window TTL, cross-replica quotas, competing leases and stale-owner fencing.
- Cross-replica single-use quarantine resolution and durable request replay.
- API restart and transient Redis state loss with durable SQL conversation history.
- A separate worker process killed with SIGKILL mid-assessment. The replacement
  worker resumes receipts and marks the uncertain call INCONCLUSIVE without retry.
- Logical audit snapshot restoration, matching-key verification and wrong-key rejection.
- Signed policy propagation, malformed PostgreSQL audit JSON and cache-failure readiness.

The logical restoration test validates evidence/key handling, not an operational
PITR/pg_dump backup procedure. Rehearse your actual infrastructure backup and
restore plan separately before deployment.

## Browser workflows

```bash
pip install -r requirements-dev.txt
playwright install chromium
python scripts/demo_setup.py
# Start python run.py in another terminal, then:
python scripts/browser_smoke.py
```

The smoke test selects only an internal mock target. It covers seven pipeline
nodes, calibrated drift, operator approve/block, redaction, tool inspection, safe
text rendering, audit verification, report downloads, keyboard interaction,
credential reconnect, quarantine restoration and desktop/tablet/mobile layouts.
`CHROMIUM_EXECUTABLE` can select an existing browser installation.

OIDC backend tests validate discovery/JWKS, signed claims, PKCE/nonce/state,
encrypted cookie binding, CSRF, logout, role boundaries and audit actors using
controlled cryptographic fixtures. They are not an integration certification of a
particular external identity-provider tenant. Configure/test your actual issuer,
audience, callback and role mappings before production access is enabled.

## Evaluation and load

See `EVALUATION.md` for independent datasets, observable oracles and paid-run
consent/budgets. See `load/README.md` for mixed, quota and contention profiles.
No real-provider calls were made during implementation validation.

### Earlier observed local results — 2026-09-06

These measurements precede the subsequent 160-seed corpus/normalization expansion;
they are retained as historical observations, not updated accuracy claims.

These are implementation measurements in an isolated sandbox, not production
capacity estimates or general detection claims:

- Real integration tests ran against **PostgreSQL 18.4** and **Redis 6.2.14** over
  private Unix sockets. The CI matrix additionally defines PostgreSQL 16/18 and
  Redis 7 jobs; those hosted CI runs have not been executed in this session.
- Browser workflows passed at desktop, tablet and mobile widths in Chromium.
- A **two-minute, 10-user Locust run** against a separate PostgreSQL/Redis staging
  instance completed **5,419 HTTP requests with zero failures**. Aggregate observed
  rate was **45.5 requests/second**, average response time **19.5 ms**, p95 **37 ms**,
  and p99 **49 ms**. This includes discovery and quarantine cleanup requests.
- The target, embedder and jury were mock/offline; staging quotas were disabled
  for that throughput profile. A think-time workload is not a saturation test.
  API RSS was about **100.2 MB** after the run (about **92.1 MB** before the earlier
  warm-up run). These samples alone do not prove a long-duration memory plateau.
- The staging HMAC chain verified successfully after load: **5,773 records**.
- The public reference evaluation completed **68 paired model/case trials** across
  the two mocks. It exposed **low request-only recall: 5.9%** on the reference
  attack intents, while **no modeled unsafe deliveries** were observed. Raw target
  contract violations occurred in only 5.9% of completed trials. These different
  measurements must not be collapsed into a claim of perfect detection.

The low reference request recall is a real limitation of the heuristic configuration,
not a metric to hide or fix by relabelling examples. Use development-only tuning,
independent held-out data, real model configurations and appropriate manual review
before relying on SENTINEL for a production security decision.

Generated evidence lives under the Git-ignored `reports/` directory. The load
HTML/CSV and evaluation JSON/Markdown include details needed to inspect the results.

## CI

`.github/workflows/ci.yml` defines:

1. Python 3.11/3.12 offline regressions, fatal lint, JavaScript syntax checks and a
   mock-only reference evaluation.
2. Real PostgreSQL/Redis integration tests, including process crash recovery.
3. A browser smoke test and bounded mock-only load test.

No workflow uses provider secrets or paid APIs. Artifacts have a 14-day retention
period. Dependency/IdP/cloud deployment validation beyond this matrix remains the
operator's responsibility; do not treat a skipped or unrun job as passing.


## Corpus/normalization expansion validation

The subsequent expansion passes **480 tests**, including **15 real PostgreSQL/Redis
integration cases**. This adds 104 regressions beyond the prior 376-test baseline,
covering ROT13/composed obfuscation, all requested homoglyphs, spaced and structured
instructions, native-language positive/benign controls, whole-key/JWT/password/IP
redaction, authoring validation and actual structured tool-schema persistence.

A fresh, isolated mock-canary corpus run checked **160 seeds and 244 mutations**:
**355** were reproduced on the local fixture and **49** were retained as `dead`
(unreproduced), with **0 live-validated** claims. The unreproduced set includes the
12 native-language additions that the English-oriented target simulator cannot
interpret. They remain legitimate candidate tests; they were not relabelled to
inflate success counts. The original 92 seeds and the reference evaluation file
were checked against the preceding ZIP and remain unchanged.

This establishes tested implementation behavior, not a new real-model accuracy
claim. The earlier 5.9% reference recall and load figures above are historical
measurements; a fresh independent, budget-approved evaluation is still required
before production claims.


## Groq free-plan integration validation

The optional Groq integration passes **515 tests**: **500 offline cases** and
**15 real PostgreSQL/Redis integration cases**. Its 35 new synthetic cases cover
pinned transport/history/tool preservation, strict jury schemas, missing Free-plan
confirmation, quota errors/no fallback, incomplete replies, small baselines,
assessment caps, per-campaign request/token budgets, and private profile loading.

The browser smoke suite now also checks the unconfigured Free AI panel and an
isolated browser-only registration/selection contract with no provider request.
It rejects non-heuristic server juries before running, so the demo smoke cannot
accidentally spend live/free provider quota. No Groq account or live model request
was used for these checks; actual account setup/connectivity/accuracy remain to be
verified by the operator. See `FREE_AI.md` before enabling hosted inference.
