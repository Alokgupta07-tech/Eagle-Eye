# Optional free-plan AI: Groq + GPT-OSS

SENTINEL now supports `internal://groq` as a live target and
`groq/openai/gpt-oss-120b` as a jury member. **No OpenAI API key is needed** for
that model: Groq hosts it and authenticates it with your `GROQ_API_KEY`.

## Why this default

The practical default is **GPT-OSS 120B**, with **GPT-OSS 20B** available as a
lighter alternative. Both are listed as Groq production models and support strict
JSON-schema responses. The jury uses that structured mode; target requests can
instead carry custom function definitions. Groq currently does not combine tool
use/streaming with Structured Outputs, so the adapter keeps those paths separate.
See the model documentation [2](https://console.groq.com/docs/model/openai/gpt-oss-120b)
and structured-output contract [1](https://console.groq.com/docs/structured-outputs).

This is a fit-for-purpose integration choice, **not a claim that this model has
won a SENTINEL accuracy benchmark**. No live provider evaluation was performed
without an operator-supplied account and consent.

## What “free” means

Use your own **Groq Free-plan** account. Free quotas vary by model/organization;
inspect the [current account limits](https://console.groq.com/settings/limits)
and rate-limit documentation [1](https://console.groq.com/docs/rate-limits).
Rate limits include both requests and tokens, so a multi-stage security inspection
may hit a limit before an ordinary chat application would.

SENTINEL cannot infer or verify the account's billing plan from its API key.
`GROQ_FREE_PLAN_CONFIRMED=true` is your explicit confirmation, **not a billing
verification API**. If you use a paid account or change the account's plan, provider
charges may apply. The integration does not upgrade plans, switch providers,
select unlisted models, retry a failed completion, or fall back to a paid model.

The model is hosted: requests, tool schemas and the response text sent to a live
juror leave your machine. Use synthetic test data first and review
https://console.groq.com/docs/your-data and your provider data controls before
sending proprietary or personal information. This is not local/offline inference.

## Private setup

1. Create your own account/key at https://console.groq.com/keys and verify it is on
   the Free plan. Do not paste the key into chat or the dashboard Admin Key field.
2. Copy `.env.groq.example` to `.env.groq`. The latter is Git-ignored.
3. Put your provider key in `GROQ_API_KEY` in that private file. Set
   `GROQ_FREE_PLAN_CONFIRMED=true` only after checking the plan.
4. Generate **two distinct SENTINEL access keys**, one for the control plane and
   one for the proxy, and place them in `SENTINEL_ADMIN_KEY` and
   `SENTINEL_PROXY_KEY`. These are not your provider key:

   ```bash
   python -c 'import secrets; print(secrets.token_urlsafe(32))'
   ```

5. Install dependencies and validate the local configuration:

   ```bash
   pip install -r requirements.txt
   python scripts/run_free_ai.py --env-file .env.groq --check
   ```

   `--check` makes **zero network calls**, never displays key values and does not
   claim that the credentials or billing tier were verified remotely.

6. Stop the previous local server if it occupies the same port, then start:

   ```bash
   python scripts/run_free_ai.py --env-file .env.groq
   ```

   The launcher runs a **single-process lab**, not production mode. It chooses one
   live Groq juror, requests semantic judgment even for prompts without lexical
   hints, uses offline embeddings, and disables unrelated OpenAI/Anthropic/Google
   credentials for this process. It requires private access keys and keeps the
   production multi-provider checks unchanged. The listener binds 0.0.0.0; keep it
   behind your firewall/HTTPS ingress rather than exposing an unprotected port.

7. In the console's **Access keys** panel, enter the two SENTINEL keys. Expand
   **Free AI option** under Target uplink, then click **Register & select model**.
   That action registers/selects a target but makes **no provider calls**. Start
   with one benign message. The free-profile model selector permits only the two
   supported GPT-OSS model IDs.

No provider credentials are entered into or returned to browser JavaScript.
If the key or plan confirmation is missing, the UI says setup is required and
registration is refused. Configuration readiness is not displayed as a successful
connection test.

### Existing application configuration

You can also keep your normal launcher and set `GROQ_API_KEY`,
`GROQ_FREE_PLAN_CONFIRMED=true`, `GROQ_MODEL`, and
`JURY_MODELS=groq/openai/gpt-oss-120b` in process environment. Set
`GROQ_JUDGE_ALL_REQUESTS=true` to invoke the live semantic judge even without a
keyword hit. Protect the API/proxy with private credentials as described in
`PRODUCTION.md`. Never put real keys in the repository's tracked `.env` or examples.

The custom launcher is the safer lab shortcut because it avoids unrelated paid
jurors. A manually configured mixed jury is reported as mixed; one live Groq model
must never be presented as three independent model families.

## Quotas and bounded work

- Registering a Groq target does not start the usual 50-probe baseline.
- Clicking **Baseline** explicitly runs at most `GROQ_BASELINE_PROBES` probes
  (default 3). This consumes provider quota.
- API batch assessments involving a Groq target or active Groq juror require an
  explicit `limit` no greater than `GROQ_MAX_RUN_CASES` (default 5). Queued jobs
  enforce the same guard when executed.
- `GROQ_TARGET_MAX_TOKENS` and `GROQ_JUDGE_MAX_TOKENS` default to 1024 completion
  tokens. These include the model's reasoning allowance. Low reasoning effort is
  requested, and hidden reasoning is not returned/served.
- `GROQ_MAX_INPUT_BYTES` bounds the serialized provider payload (default 16,000).
  Oversized inputs are rejected, not silently truncated into a different test.
- Provider 429s propagate as safe quota notices. An unavailable jury/target does
  not serve unchecked content. There is no automatic retry or model fallback.
- The all-request profile can use **up to four provider calls per turn**: request
  classification, possibly a separate accumulated-context classification, target
  generation, and response classification. REVIEW can stop dispatch earlier.

Do not run the full `demo_setup.py` with an enabled Groq jury. It now rejects that
combination rather than consuming a large free quota. Seed the offline demo before
enabling a live juror, or use `scripts/seed_corpus.py`, which explicitly disables
all live provider credentials and does not run assessments.

These controls reduce accidental consumption; they do not replace provider-side
quotas or billing controls. Other software using the same organization can consume
its allowance too. Wait for the provider's reset before deliberately making a new
request; idempotency still prevents blindly repeating an uncertain operation.

## Small, budgeted free-tier evaluation

After the private file is configured, use the existing independent evaluator:

```bash
python -m evals.runner --env-file .env.groq \
  --models groq/openai/gpt-oss-120b --jury-mode configured \
  --free-tier --limit 1 --baseline-probes 1 \
  --max-calls 8 --max-tokens 80000
```

This uses only approved Groq model IDs and explicit request/token caps. It cannot
be combined with `--allow-paid`, dollar budgets or a non-Groq live target/juror.
Target **and jury** calls, including calibration, consume the budget. Unknown usage
retains its reservation. The report records the operator-confirmed plan but sets
`billing_verified=false` and does not invent a measured dollar cost.

A quota hit stops the campaign with `provider_rate_limited`; unrun/failed cases are
not counted as safe or successful detections. Budget exhaustion similarly produces
a partial report. Keep the corpus/reference/held-out separation in `EVALUATION.md`.

## Validation status

The provider integration is covered by synthetic transport tests: message history,
tool schemas, strict JSON, local schema/range checks, incomplete output, quota
errors, missing consent, no paid fallback, private configuration, registration
without calls, baseline caps, and authenticated status. These tests do not prove
that your Groq account is configured or that the model detects every attack.
A real request still requires your own key and explicit free-plan confirmation.
