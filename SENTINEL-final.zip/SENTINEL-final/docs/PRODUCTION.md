# Production controls and deployment

This edition adds operational safeguards; it is **not a certification of detection
accuracy or a completed production deployment**. Review `EVALUATION.md` and
`TESTING.md` before deciding whether a particular application is protected well
enough. Deploy one instance/security domain per organization. This is not a
multi-tenant SaaS with tenant-level row security.

## Identity and permissions

Set `AUTH_MODE=oidc` with `OIDC_ISSUER` and a distinct `OIDC_AUDIENCE`. The verifier
fetches discovery/JWKS only from the configured trusted issuer, accepts RS256
(RSA >=2048 bits) or ES256/P-256, and checks signature, issuer, audience, subject,
expiry, issuance time and optional not-before time. Unknown-key refreshes are
bounded to prevent kid-driven network amplification. JWT jku/x5u headers are not
used to choose a key source.

Roles come from `OIDC_ROLES_CLAIM` (default `realm_access.roles`). A complete claim
key, including an Auth0-style namespaced key, is supported; otherwise dot-separated
components select a nested claim. Unknown roles get no permissions.

| Role | Permissions |
|---|---|
| viewer | Reports, executions, audit verification, masked target metadata, policy reads |
| analyst | Viewer permissions plus proxy use, assessment submission, feedback and quarantine resolution |
| admin | Analyst permissions plus target/policy management and operational metrics/jobs |
| service | Proxy use only; appropriate for application service accounts |
| monitor | Metrics/job monitoring only; cannot inspect reports, change policy or dispatch prompts |

Every sealed operator action includes the verified subject, issuer, role set and
authentication method. OIDC callers cannot spoof an actor with `labeler` JSON.
Quarantine resolution requires a nonempty reason in production.

### Browser SSO

Configure `OIDC_CLIENT_ID`, `OIDC_REDIRECT_URI` (the exact HTTPS origin followed by
`/auth/callback`) and, for a confidential client, `OIDC_CLIENT_SECRET`. A public
client using Authorization Code + PKCE is also supported. Implicit/password grants
are not used. The API audience must be distinct from the browser client ID.

- Login state, nonce, PKCE verifier and browser binding are encrypted server-side.
- Access/ID tokens are not returned to browser JavaScript or placed in URLs.
- The browser receives an opaque Secure, HttpOnly, SameSite=Lax session cookie.
- Encrypted Redis sessions are bound to that cookie's random identifier.
- Mutating cookie-authenticated requests require an exact configured Origin and a
  session-bound `X-CSRF-Token`. Bearer clients do not use ambient-cookie authority.
- Login state is single-use; callbacks check the ID-token nonce and matching
  access/ID-token subjects. Login replaces/revokes any prior browser session.
- Logout revokes the SENTINEL session, not the identity provider's global session
  or already-issued bearer tokens. Use short access-token lifetimes, IdP MFA and
  appropriate account revocation policy. Role changes apply on token renewal.
- No refresh token is retained. Users sign in again after access-token expiry.

For Auth0/resource-specific authorization parameters, set
`OIDC_AUTHORIZATION_PARAMS` to the JSON object required by your provider. Core
state/nonce/redirect/PKCE parameters cannot be overridden by it. The API access
token must contain the configured API audience and mapped roles; an opaque access
token is not accepted as a JWT.

Generate a Keycloak realm for your actual public origin:

```bash
python scripts/keycloak_realm.py --public-origin "$SENTINEL_PUBLIC_ORIGIN" --output realm.json
```

Import it into your Keycloak installation, create users through your IdP, assign
roles, and enforce MFA for administrators. The generated realm contains no users
or passwords, restricts redirects to your exact callback, uses PKCE S256 and puts
`sentinel-api` in access-token audiences but not ID tokens. For service/monitoring
accounts, create separate confidential clients with only the necessary role and
API audience. Test against your actual IdP before rollout.

## Mandatory production settings

`PRODUCTION=true` fails configuration/startup rather than silently accepting:

- API-key-only control-plane authentication or a SQLite store.
- Optional Redis, embedded/non-durable worker execution, disabled quotas or
  missing idempotency requirements.
- A heuristic/mixed jury, fewer than two required votes, or a configured live jury
  with fewer than two provider families.
- Missing, short or reused audit/encryption secrets, a weak optional machine key,
  wildcard CORS, or automatic embedder fallback.

Set `REQUIRE_REDIS=true`, `WORKER_MODE=external`, `REQUIRE_LIVE_JURY=true`,
`JURY_MIN_VOTES=2`, `REQUIRE_IDEMPOTENCY_KEY=true`, and explicitly choose an embedder
mode. `EMBEDDER=offline` is a deterministic character-ngram representation, **not**
a neural semantic model. The provided lightweight image uses that representation.
To use `st`, install sentence-transformers in your deployment image, provision its
model cache, validate the loaded model, and rebuild corpus embeddings/baselines.
Do not mix embedding configurations across replicas or reuse incompatible vectors.

Only supported provider models with configured credentials may form the live
jury. Keys existing in configuration do not prove provider authorization or
availability: readiness does not make paid probe calls. Every actual response
still requires the configured valid-vote quorum; insufficient votes withhold it.
Recent quorum failure makes readiness fail temporarily.

**The repository's `.env` is tracked and deliberately contains the public demo
key. Never put real credentials in that file and push it.** Use environment
injection or a secret manager. `.env.production`, `.env.staging` and `.env.identity`
are ignored local conveniences, not automatically loaded by `Settings`; load them
into the process environment explicitly or use Compose's `--env-file`.

Generate separate high-entropy values for encryption, audit authentication,
optional machine proxy authentication, and database/cache credentials. Generate an
installation-specific `SENTINEL_SALT` as well. PBKDF2 remains exactly 100,000
iterations; derived Fernet keys are cached in-process for repeated envelopes using
the same secret/salt. Credentials and operational receipts still have randomized
authenticated ciphertexts.

## Durable operations and concurrent conversations

The API commits assessment jobs to SQL **before** responding. The queue is a
native transactional PostgreSQL queue (SKIP LOCKED), not a Redis/SQL dual-write
outbox or an in-memory `asyncio` task queue. SQLite and an embedded worker provide
the same mechanics for a single-process lab.

Run production workers separately:

```bash
python -m app.worker
```

All API/worker instances share PostgreSQL, Redis, the namespace, and the original
audit/encryption secrets. Job payloads are authenticated; actors and request
policy/rule snapshots are retained. Worker leases renew independently, and old
owners cannot finalize a job after takeover. Final execution insertion and run
counter updates commit atomically.

Completed per-effect receipts allow recovery without repeating target/jury work.
If a worker dies after an effect starts but before its durable receipt, SENTINEL
marks the effect **indeterminate** instead of blindly resending it. Earlier
completed evidence remains. This is not an exactly-once guarantee about a remote
provider or external tool. A new assessment/request is an explicit new operation.
Inspect `/admin/jobs` and the run's inconclusive/error evidence before deciding
whether to resubmit.

The live proxy uses a renewable distributed session lease around history read,
inspection, dispatch and history update. A competing JSON request receives 409;
a streaming request reports a terminal error if rejection occurs after headers.
Lease loss cancels the owner and withholds its reply. Durable SQL transcripts have
authenticated, encrypted payloads, monotonic versions and compare-and-set writes;
request windows can be rebuilt after transient Redis loss. Session ownership is
scoped by authenticated identity, target and session ID.

REVIEW snapshots bind the original history version, owner and policy fingerprint.
Changing conversation state or policy invalidates an old approval. Block-and-log
never dispatches. Redacting an output cannot undo a tool effect already executed
inside an external target; enforce tool authorization in that target too.

Supply `Idempotency-Key` on proxy calls and assessment submissions. The console
automatically generates one per new operation. Retrying the same key and body
replays the original result without redispatch; changing the body returns 409.
Completed receipts expire after `IDEMPOTENCY_TTL_S` (24 hours by default). Uncertain
outcomes retain tombstones/results and do not silently become retryable. Plan
retention/archiving for operational receipts and audit evidence according to your
organization's data policy.

## Deployment topology

`deploy/compose.production.yml` is a single-host deployment definition, not an
executed cloud deployment. It uses non-root, read-only API/worker containers;
private database/cache services; authenticated Redis with AOF/noeviction; resource
limits; and readiness checks. Required values use fail-fast Compose interpolation.
Use URL-safe generated database/cache passwords, or provide appropriately encoded
connection URLs in your deployment's secret injection.

```bash
docker compose --env-file .env.production -f deploy/compose.production.yml up -d --build
```

Put an HTTPS ingress in front of the loopback-bound API port. Containers themselves
listen on 0.0.0.0; no browser code calls sandbox localhost. Set the exact callback
origin, sanitize forwarding headers and configure only the ingress peer CIDRs in
`SENTINEL_TRUSTED_PROXIES`. Keep Uvicorn proxy-header rewriting disabled.
Production CSP rejects framing; lab mode retains hosted-preview embedding.
Disable/sanitize ingress access logs for OAuth codes, tokens and sensitive queries;
`run.py` and the supplied image disable Uvicorn's raw access log.

For multi-host deployments, use managed/private PostgreSQL and Redis with TLS,
backup/availability policies, and explicit outbound network restrictions. Pin
container/dependency/model versions appropriate for your rollout and run the real
integration matrix against them. The Compose definition itself has not been built
in this Docker-less workspace.

## Readiness, monitoring and recovery

- `/healthz`: diagnostic liveness/configuration view; not proof of dependency health.
- `/readyz`: database, required cache, external-worker heartbeats and jury state;
  returns 503 if not ready. Missing Redis never silently downgrades a production
  conversation to memory.
- `/metrics`: authenticated Prometheus text with bounded route/status labels,
  latency, decisions, job outcomes, queue/worker gauges and process metrics.
- `/admin/jobs` and `/admin/jobs/{id}`: operational state without raw job payloads.

Audit verification uses bounded pages from a consistent database snapshot.
Retain independently trusted audit heads outside the mutable database to detect
rollback/tail deletion; HMAC alone cannot detect restoration of an older valid
snapshot. Back up audit/encryption secrets separately. Restore into an isolated
instance, verify history using the original audit key, then test credential
readability and service readiness before switching traffic. Never re-sign old
unkeyed history to manufacture authenticity.

SQL transcripts survive API/cache restarts; semantic trajectory statistics are
finite-window cache state and may reset if Redis data is lost. Configure retention
and Redis persistence accordingly. Native locks cannot recall an already-sent
network request or prove that a client received its response; treat ambiguous
remote side effects explicitly, not as successful or safely retried operations.


## Optional free-plan adapter

The Groq integration and `scripts/run_free_ai.py` are documented in
[FREE_AI.md](FREE_AI.md). The launcher is an explicitly single-process,
single-Groq-judge lab with private access keys, not a relaxation of production's
OIDC, shared-backend or multi-provider requirements. Do not claim billing has been
verified by the presence of an API key or assume a free quota is production capacity.
