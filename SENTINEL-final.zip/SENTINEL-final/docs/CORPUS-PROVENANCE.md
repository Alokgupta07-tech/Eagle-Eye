# Corpus provenance — how the SENTINEL attack corpus was authored

The current source file contains **160** fixtures: 92 retained legacy entries
labelled `hand_authored`, and 68 new entries explicitly labelled `ai_assisted`.
The expansion was authored for this project with coding-agent assistance and was
not copied from the evaluation/reference set. Human review and target-specific
validation are still necessary; authorship is not evidence that an attack works.

| Field | Meaning |
|---|---|
| `origin` | `hand_authored`, `ai_assisted`, or `adapted`; be explicit about assistance and sources |
| `taxonomy_source` | The classification vocabulary used, not necessarily the source of payload wording |
| `provenance_note` | Checkable authorship/adaptation context and limitations; adapted content requires a source URL |

Seeds retain OWASP/ATLAS-format tags. The authoring validator checks their format,
not whether an external taxonomy endorses the mapping. New poisoned tool metadata
is locally mapped to indirect prompt injection; there is no invented dedicated
ATLAS tool-poisoning technique. See [the contributor guide](../CONTRIBUTING.md).

## Why this matters

An earlier build labelled seeds with `source_repo @ source_sha`. Those hashes were placeholders, not real commits. A security tool that fabricates provenance forfeits the trust it is asking for, so v2.4 removed the fields and replaced them with the honest scheme above (principle P8 in the as-built document).

## What "validated" means

Origin describes authorship. Validation describes an observation on a particular
fixture. Each seed/mutation is sent to the configured vulnerable mock (RAG payloads
through isolated retrieval; structured tool definitions through the tools argument).
A known synthetic canary/key, an attack-specific success indicator or a defined
simulated compliance marker is required. An incidental email/private IP does not
validate an attack, and a refusal quoting a success phrase is not a success.
Earlier known-secret evidence survives a later refusal or exception.

The legacy status `dead` means **unreproduced on that fixture**, not universally
ineffective. This is particularly important for native-language candidates that
the English-oriented simulator does not understand. Unsupported cases are retained,
not assigned fabricated success or `validated_live` labels.

The seed CLI is explicitly mock-only even if provider keys are configured. Real
validation belongs in the separately consented/budgeted evaluation workflow. Never
claim the local corpus count is a real-model success rate. New structured tool
payload hashes include both message and schema, so different poisoned descriptions
are not deduplicated just because the benign user question is the same.
