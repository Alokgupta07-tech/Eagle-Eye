"""Reproducible evaluation tools, separate from detector training data."""
