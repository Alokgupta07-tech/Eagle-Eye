"""Versioned, bounded JSONL evaluation cases; never added to the training corpus."""

from __future__ import annotations

import hashlib
import json
import re
from pathlib import Path
from typing import Literal

from pydantic import BaseModel, ConfigDict, Field, model_validator


class Case(BaseModel):
    model_config = ConfigDict(extra="forbid", hide_input_in_errors=True)
    id: str = Field(min_length=1, max_length=80, pattern=r"^[A-Za-z0-9_.:-]+$")
    family: str = Field(min_length=1, max_length=100)
    split: Literal["dev", "test"]
    label: Literal["benign", "attack"]
    category: str = Field(min_length=1, max_length=80)
    turns: list[str] = Field(min_length=1, max_length=20)
    documents: list[str] = Field(default_factory=list, max_length=8)
    tools: list[dict] = Field(default_factory=list, max_length=64)
    allowed_tools: list[str] = Field(
        default_factory=lambda: ["lookup_policy"], max_length=32
    )
    source: str = Field(min_length=1, max_length=300)

    @model_validator(mode="after")
    def sizes(self):
        if any(not turn.strip() or len(turn) > 16000 for turn in self.turns):
            raise ValueError("turns must contain 1-16000 characters")
        if len(json.dumps(self.tools, ensure_ascii=False).encode()) > 65536:
            raise ValueError("tool schemas exceed the proxy limit")
        if any(len(message) > 16000 for message in self.messages()):
            raise ValueError(
                "combined request and retrieved context exceed the proxy limit"
            )
        for message in self.messages():
            message.encode("utf-8")
        return self

    def messages(self):
        context = (
            "\n\nUNTRUSTED RETRIEVED DOCUMENTS:\n" + "\n---\n".join(self.documents)
            if self.documents
            else ""
        )
        return [turn + context for turn in self.turns]

    def input_hash(self):
        value = {
            "turns": [
                re.sub(r"\s+", " ", text).strip().lower() for text in self.messages()
            ],
            "tools": self.tools,
        }
        return hashlib.sha256(json.dumps(value, sort_keys=True).encode()).hexdigest()


def load_dataset(path: str | Path, *, compare_with: str | Path | None = None):
    path = Path(path)
    if path.stat().st_size > 64 * 1024 * 1024:
        raise ValueError(
            "dataset exceeds 64 MiB; split it into bounded evaluation campaigns"
        )
    cases = []
    for line_no, line in enumerate(path.read_text().splitlines(), 1):
        if not line.strip():
            continue
        if len(cases) >= 10000:
            raise ValueError("dataset exceeds 10000 cases")
        try:
            cases.append(Case.model_validate_json(line))
        except ValueError as exc:
            raise ValueError(f"invalid evaluation case at line {line_no}") from exc
    if not cases:
        raise ValueError("dataset is empty")
    ids, families, inputs = set(), {}, {}
    all_cases = cases + (load_dataset(compare_with)[0] if compare_with else [])
    for case in all_cases:
        if case.id in ids:
            raise ValueError("duplicate evaluation case ID")
        ids.add(case.id)
        for key, table in ((case.family, families), (case.input_hash(), inputs)):
            if key in table and table[key] != case.split:
                raise ValueError(
                    "development/test leakage: an input or attack family crosses splits"
                )
            table[key] = case.split
    digest = hashlib.sha256(path.read_bytes()).hexdigest()
    return cases, digest
