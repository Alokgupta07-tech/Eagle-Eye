"use strict";
/* Same-origin API access. Production SSO uses an HttpOnly cookie and CSRF token;
   access/ID tokens are never delivered to or stored by this browser code. */
window.SentinelAPI = (() => {
  const storage = {
    get(key) {
      try {
        return sessionStorage.getItem(key);
      } catch {
        return null;
      }
    },
    set(key, value) {
      try {
        sessionStorage.setItem(key, value);
      } catch {
        /* storage may be disabled */
      }
    },
  };
  let adminKey = storage.get("sentinel_admin_key") ?? "sentinel-admin-demo-key";
  let proxyKey = storage.get("sentinel_proxy_key") ?? "";
  let mode = "api_key",
    user = null,
    configuration = null;

  async function refreshIdentity() {
    if (mode !== "oidc") return null;
    const response = await fetch("/auth/me", {
      credentials: "same-origin",
      cache: "no-store",
    });
    user = response.ok ? await response.json() : null;
    renderIdentity();
    return user;
  }
  async function initialize() {
    const response = await fetch("/auth/config", {
      credentials: "same-origin",
      cache: "no-store",
    });
    if (!response.ok)
      throw new Error("Authentication configuration is unavailable.");
    configuration = await response.json();
    mode = configuration.mode;
    if (!["api_key", "oidc"].includes(mode))
      throw new Error("Unsupported authentication configuration.");
    if (mode === "oidc") await refreshIdentity();
    renderIdentity();
  }
  const ready = initialize();
  // The caller still receives initialization failures; avoid a detached promise warning.
  ready.catch(() => {});

  function renderIdentity() {
    const panel = document.querySelector("#identityPanel");
    if (!panel) return;
    const sso = mode === "oidc";
    panel.hidden = !sso;
    for (const id of ["#credentials", "#reportKeyForm"]) {
      const element = document.querySelector(id);
      if (element) element.hidden = sso;
    }
    const subject = document.querySelector("#identitySubject");
    subject.textContent = user ? user.subject : "Not signed in";
    subject.title = subject.textContent;
    document.querySelector("#identityRoles").textContent = user
      ? user.roles.join(" / ")
      : "OIDC";
    const login = document.querySelector("#ssoLogin");
    login.hidden = Boolean(user) || !configuration?.browser_sso;
    const destination =
      location.pathname === "/report.html"
        ? location.pathname + location.search
        : "/";
    login.href = "/auth/login?return_to=" + encodeURIComponent(destination);
    document.querySelector("#ssoLogout").hidden = !user;
    window.dispatchEvent(
      new CustomEvent("sentinel:identity", { detail: user }),
    );
  }
  document.addEventListener("DOMContentLoaded", renderIdentity);
  document.addEventListener("click", async (event) => {
    if (!event.target.closest("#ssoLogout")) return;
    const button = document.querySelector("#ssoLogout");
    button.disabled = true;
    try {
      await json("/auth/logout", { method: "POST" });
      user = null;
      location.assign("/");
    } catch (error) {
      button.disabled = false;
      button.title = error.message;
    }
  });

  async function request(path, options = {}) {
    await ready;
    const url = new URL(path, location.origin);
    if (url.origin !== location.origin)
      throw new Error("Credentials may only be sent to this origin.");
    const headers = new Headers(options.headers || {});
    const method = (options.method || "GET").toUpperCase();
    if (mode === "api_key") {
      if (
        /^\/(admin(?:\/|$)|v1\/(?:runs|reports)(?:\/|$)|audit\/verify|metrics|auth\/me)/.test(
          url.pathname,
        )
      )
        headers.set("X-Sentinel-Admin-Key", adminKey);
      if (/^\/v1\/proxy\//.test(url.pathname) && proxyKey)
        headers.set("X-Sentinel-Proxy-Key", proxyKey);
    } else if (
      !["GET", "HEAD", "OPTIONS"].includes(method) &&
      user?.csrf_token
    ) {
      headers.set("X-CSRF-Token", user.csrf_token);
    }
    if (
      method === "POST" &&
      (/^\/v1\/proxy\//.test(url.pathname) || url.pathname === "/v1/runs") &&
      !headers.has("Idempotency-Key")
    )
      headers.set("Idempotency-Key", crypto.randomUUID());
    const response = await fetch(url, {
      ...options,
      method,
      headers,
      credentials: "same-origin",
      cache: "no-store",
    });
    if (response.status === 401) {
      if (mode === "oidc") {
        user = null;
        renderIdentity();
      }
      window.dispatchEvent(
        new CustomEvent("sentinel:locked", { detail: url.pathname }),
      );
    }
    return response;
  }
  async function json(path, options = {}) {
    const response = await request(path, options);
    let value;
    try {
      value = await response.json();
    } catch {
      throw new Error(`Invalid API response (HTTP ${response.status}).`);
    }
    if (!response.ok) {
      const error = new Error(
        typeof value.detail === "string"
          ? value.detail
          : `Request failed (HTTP ${response.status}).`,
      );
      error.status = response.status;
      throw error;
    }
    if (value.error) throw new Error(value.error);
    return value;
  }
  async function download(path, filename) {
    const response = await request(path);
    if (!response.ok)
      throw new Error(
        `Download failed (HTTP ${response.status}). Check your access.`,
      );
    const href = URL.createObjectURL(await response.blob());
    const link = document.createElement("a");
    link.href = href;
    link.download = filename;
    document.body.append(link);
    link.click();
    link.remove();
    setTimeout(() => URL.revokeObjectURL(href), 1000);
  }
  return {
    request,
    json,
    download,
    storage,
    ready,
    refreshIdentity,
    can(permission) {
      return (
        mode === "api_key" || Boolean(user?.permissions?.includes(permission))
      );
    },
    get mode() {
      return mode;
    },
    get production() {
      return Boolean(configuration?.production);
    },
    get adminKey() {
      return adminKey;
    },
    get proxyKey() {
      return proxyKey;
    },
    setKeys(admin, proxy = proxyKey) {
      adminKey = admin.trim();
      proxyKey = proxy.trim();
      storage.set("sentinel_admin_key", adminKey);
      storage.set("sentinel_proxy_key", proxyKey);
    },
  };
})();
