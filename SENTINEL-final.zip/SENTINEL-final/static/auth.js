"use strict";
/* Shared, same-origin credentials for the console, reports and blob downloads.
   The demo key is public by design. Deployments must set a private server key;
   a 401 opens the credential controls instead of starting a retry loop. */
window.SentinelAPI = (() => {
  const storage = {
    get(key) {
      try {
        return sessionStorage.getItem(key);
      } catch {
        return null;
      }
    },
    set(key, value) {
      try {
        sessionStorage.setItem(key, value);
      } catch {
        /* Private browsing may disable storage. */
      }
    },
  };
  let adminKey = storage.get("sentinel_admin_key") ?? "sentinel-admin-demo-key";
  let proxyKey = storage.get("sentinel_proxy_key") ?? "";

  async function request(path, options = {}) {
    const url = new URL(path, location.origin);
    if (url.origin !== location.origin)
      throw new Error("Credentials may only be sent to this origin.");
    const headers = new Headers(options.headers || {});
    if (
      /^\/(admin(?:\/|$)|v1\/(?:runs|reports)(?:\/|$)|audit\/verify)/.test(
        url.pathname,
      )
    ) {
      headers.set("X-Sentinel-Admin-Key", adminKey);
    }
    if (/^\/v1\/proxy\//.test(url.pathname) && proxyKey)
      headers.set("X-Sentinel-Proxy-Key", proxyKey);
    const response = await fetch(url, {
      ...options,
      headers,
      credentials: "same-origin",
      cache: "no-store",
    });
    if (response.status === 401)
      window.dispatchEvent(
        new CustomEvent("sentinel:locked", { detail: url.pathname }),
      );
    return response;
  }
  async function json(path, options = {}) {
    const response = await request(path, options);
    let value;
    try {
      value = await response.json();
    } catch {
      throw new Error(`Invalid API response (HTTP ${response.status}).`);
    }
    if (!response.ok) {
      const detail =
        typeof value.detail === "string"
          ? value.detail
          : `Request failed (HTTP ${response.status}).`;
      const error = new Error(detail);
      error.status = response.status;
      throw error;
    }
    if (value.error) throw new Error(value.error);
    return value;
  }
  async function download(path, filename) {
    const response = await request(path);
    if (!response.ok)
      throw new Error(
        `Download failed (HTTP ${response.status}). Check your admin key.`,
      );
    const href = URL.createObjectURL(await response.blob());
    const link = document.createElement("a");
    link.href = href;
    link.download = filename;
    document.body.append(link);
    link.click();
    link.remove();
    setTimeout(() => URL.revokeObjectURL(href), 1000);
  }
  return {
    request,
    json,
    download,
    storage,
    get adminKey() {
      return adminKey;
    },
    get proxyKey() {
      return proxyKey;
    },
    setKeys(admin, proxy = proxyKey) {
      adminKey = admin.trim();
      proxyKey = proxy.trim();
      storage.set("sentinel_admin_key", adminKey);
      storage.set("sentinel_proxy_key", proxyKey);
    },
  };
})();
