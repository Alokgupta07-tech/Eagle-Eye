"""Exercise the real SOC UI against a running, default-policy offline demo.

Setup: pip install -r requirements-dev.txt && playwright install chromium
Run: python scripts/demo_setup.py; python run.py (another terminal), then this file.
CHROMIUM_EXECUTABLE can select an existing browser. SENTINEL_ADMIN_KEY supplies
custom credentials without putting a secret on the command line. No live-provider
or external target is ever selected by this smoke test.
"""

from __future__ import annotations

import argparse
import json
import os
import re
import sys
from pathlib import Path

import httpx
from playwright.sync_api import expect, sync_playwright

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from app.config import Settings


def main(url: str, executable: str | None = None):
    key = Settings().admin_key
    with httpx.Client(base_url=url, headers={"X-Sentinel-Admin-Key": key}) as client:
        health = client.get("/healthz")
        health.raise_for_status()
        if health.json().get("jury_mode") != "heuristic":
            raise SystemExit(
                "Browser smoke requires an offline heuristic jury; do not consume live/free provider quotas with this test"
            )
        response = client.get("/admin/targets")
        response.raise_for_status()
        target = next(
            (
                item
                for item in response.json()["targets"]
                if item["endpoint_url"] == "internal://mock"
            ),
            None,
        )
    if target is None:
        raise SystemExit(
            "Run scripts/demo_setup.py first: a built-in vulnerable mock is required."
        )
    init = (
        f"sessionStorage.setItem('sentinel_admin_key', {json.dumps(key)});"
        f"sessionStorage.setItem('sentinel_target', {json.dumps(target['id'])});"
    )
    errors, unauthorized = [], []

    def observe(page):
        page.on("pageerror", lambda error: errors.append(str(error)))
        page.on(
            "response",
            lambda response: (
                unauthorized.append(response.url) if response.status == 401 else None
            ),
        )

    def clear_hold(page):
        if page.locator("#quarantineBar").is_visible():
            expect(page.locator("#blockLog")).to_be_enabled()
            page.locator("#blockLog").click()
            expect(page.locator("#quarantineBar")).to_be_hidden(timeout=20000)

    with sync_playwright() as playwright:
        browser = playwright.chromium.launch(
            executable_path=executable,
            headless=True,
            args=[
                "--no-sandbox",
                "--disable-dev-shm-usage",
                "--use-gl=angle",
                "--use-angle=swiftshader",
            ],
        )
        try:
            context = browser.new_context(
                viewport={"width": 1440, "height": 1100}, accept_downloads=True
            )
            context.add_init_script(init)
            page = context.new_page()
            observe(page)
            page.goto(url, wait_until="networkidle")
            expect(page.locator("#sendButton")).to_be_enabled()
            assert page.locator("#stages .stage").count() == 7
            page.locator("#freeAiPanel summary").click()
            expect(page.locator("#freeAiStatus")).to_contain_text("GROQ_API_KEY")
            expect(page.locator("#connectFreeAi")).to_be_disabled()
            assert page.locator("#freeAiModel option").count() == 2
            page.locator("#freeAiPanel summary").click()
            print(
                "PASS: unconfigured free-model panel stays disabled and explains private setup"
            )
            page.locator("[data-sc=benign]").click()
            expect(page.locator("#pipelineState")).to_have_text(
                "INSPECTION COMPLETE", timeout=20000
            )
            expect(page.locator("#band")).to_have_text("ALLOW")
            assert page.locator("#driftPoints circle").count() == 1
            print("PASS: benign request, seven pipeline nodes and calibrated drift")

            page.locator("#newSession").click()
            page.locator("[data-sc=canary]").click()
            expect(page.locator("#quarantineBar")).to_be_visible(timeout=20000)
            expect(page.locator("#allowOnce")).to_be_enabled()
            page.locator("#allowOnce").click()
            expect(page.locator("#quarantineBar")).to_be_hidden(timeout=20000)
            expect(page.locator("#pipelineState")).to_have_text(
                "INSPECTION COMPLETE", timeout=20000
            )
            expect(page.locator("#rsp")).to_contain_text("REDACT")
            assert "CANARY-" not in page.locator(".message.bot").last.inner_text()
            print("PASS: authenticated ALLOW ONCE and response redaction")

            page.locator("#newSession").click()
            page.locator("[data-sc=canary]").click()
            expect(page.locator("#quarantineBar")).to_be_visible(timeout=20000)
            clear_hold(page)
            expect(page.locator("#rsp")).to_have_text("OPERATOR BLOCKED")
            print("PASS: BLOCK & LOG without target dispatch")

            page.locator("#newSession").click()
            page.locator("[data-sc=tools]").click()
            expect(page.locator("#countRequests")).to_have_text("4", timeout=20000)
            page.locator("#toolsTab").click()
            expect(page.locator("#toolObserved")).to_contain_text("export_user_data")
            assert page.locator("#band").inner_text() in {"REVIEW", "BLOCK"}
            clear_hold(page)
            page.locator("#toolsInput").fill("[]")
            page.locator("#applyTools").click()
            print("PASS: intercepted MCP schemas and tool-poisoning gate")

            page.locator("#newSession").click()
            page.locator("#chatTab").click()
            page.locator("#inp").fill('<img src=x onerror="window.__sentinelXss=1">')
            page.locator("#sendButton").click()
            expect(page.locator("#countRequests")).to_have_text("5", timeout=20000)
            assert page.evaluate("window.__sentinelXss") is None
            assert page.locator("#term img").count() == 0
            clear_hold(page)
            page.locator("#verifyChain").click()
            expect(page.locator("#fChain")).to_contain_text(
                "HMAC VERIFIED", timeout=10000
            )
            print("PASS: safe text rendering and HMAC verification")

            page.goto(url.rstrip("/") + "/report.html", wait_until="networkidle")
            expect(page.locator("#verifyBtn")).to_be_visible(timeout=15000)
            for extension in ("md", "json"):
                with page.expect_download() as download:
                    page.locator(
                        f'[data-download][data-filename$=".{extension}"]'
                    ).first.click()
                assert download.value.suggested_filename.endswith("." + extension)
                body = Path(download.value.path()).read_text()
                assert (
                    "# SENTINEL" in body
                    if extension == "md"
                    else json.loads(body)["run"]["id"]
                )
            print("PASS: authenticated report and Markdown/JSON downloads")

            # Isolate expected 401s from the happy-path unauthorized-fetch check.
            recovery_context = browser.new_context(
                viewport={"width": 1440, "height": 1100}
            )
            recovery_context.add_init_script(
                "if (!sessionStorage.getItem('sentinel_admin_key')) {" + init + "}"
            )
            recovery = recovery_context.new_page()
            recovery.on("pageerror", lambda error: errors.append(str(error)))
            recovery.goto(url, wait_until="networkidle")
            recovery.evaluate("SentinelAPI.setKeys('invalid-smoke-test-key')")
            recovery.reload(wait_until="networkidle")
            expect(recovery.locator("#keyForm")).to_be_visible()
            expect(recovery.locator("#sendButton")).to_be_disabled()
            recovery.locator("#adminkey").fill(key)
            recovery.locator("#adminkey").press("Enter")
            expect(recovery.locator("#keyForm")).to_be_hidden(timeout=10000)
            expect(recovery.locator("#sendButton")).to_be_enabled()
            recovery.locator("#inp").fill("Hi")
            recovery.locator("#inp").press("Shift+Enter")
            assert recovery.locator("#countRequests").inner_text() == "0"
            recovery.locator("#inp").press("Enter")
            expect(recovery.locator("#pipelineState")).to_have_text(
                "INSPECTION COMPLETE", timeout=20000
            )
            expect(recovery.locator("[data-stage=FUSION] .ms")).to_have_text(
                re.compile(r"\d+ms")
            )
            print("PASS: keyboard controls, console unlock and retained FUSION timing")
            recovery.locator("#newSession").click()
            recovery.locator("[data-sc=canary]").click()
            expect(recovery.locator("#allowOnce")).to_be_enabled(timeout=20000)
            original = recovery.locator(
                ".message.user .message-content"
            ).last.inner_text()
            recovery.reload(wait_until="networkidle")
            expect(recovery.locator("#quarantineBar")).to_be_visible(timeout=20000)
            expect(
                recovery.locator(".message.user .message-content").last
            ).to_have_text(original)
            expect(recovery.locator("#band")).to_have_text("REVIEW")
            recovery.locator("#allowOnce").click()
            expect(recovery.locator("#quarantineBar")).to_be_hidden(timeout=20000)
            expect(recovery.locator("#pipelineState")).to_have_text(
                "INSPECTION COMPLETE", timeout=20000
            )
            expect(recovery.locator("#rsp")).to_contain_text("REDACT")
            print(
                "PASS: signed quarantine restoration and one-time approval after reload"
            )
            recovery.evaluate("SentinelAPI.setKeys('invalid-smoke-test-key')")
            recovery.goto(url.rstrip("/") + "/report.html", wait_until="networkidle")
            expect(recovery.locator("#root")).to_contain_text(
                "Assessment access is locked"
            )
            recovery.locator("#reportAdminKey").fill(key)
            recovery.locator("#reportAdminKey").press("Enter")
            expect(recovery.locator("#verifyBtn")).to_be_visible(timeout=15000)
            print("PASS: report unlock form")
            recovery_context.close()

            # Isolated browser-only contract: registration must select the new
            # target without invoking a provider. All mocked routes are confined
            # to this context and never modify the real application's configuration.
            free_context = browser.new_context(viewport={"width": 1440, "height": 1100})
            free_context.add_init_script(init)
            free_page = free_context.new_page()
            observe(free_page)
            fake_target = {
                "id": "browser-groq-fixture",
                "name": "Groq UI fixture",
                "endpoint_url": "internal://groq",
                "capabilities": {"model": "openai/gpt-oss-120b"},
                "baseline_status": "none",
                "baseline_version": None,
            }
            registered, dispatched = [], []
            free_page.route(
                "**/admin/providers/groq",
                lambda route: route.fulfill(
                    json={
                        "model": "openai/gpt-oss-120b",
                        "configured": True,
                        "key_configured": True,
                        "free_plan_confirmed": True,
                        "jury_members_total": 1,
                        "live_jury_members": 1,
                        "jury_mode": "live",
                    }
                ),
            )

            def target_routes(route):
                if route.request.method == "POST":
                    assert (
                        route.request.post_data_json["endpoint_url"]
                        == "internal://groq"
                    )
                    registered.append(True)
                    route.fulfill(
                        json={
                            "target": fake_target,
                            "baselining": "not_started",
                            "job_id": None,
                        }
                    )
                else:
                    original = route.fetch()
                    payload = original.json()
                    if registered:
                        payload["targets"].append(fake_target)
                    route.fulfill(response=original, json=payload)

            free_page.route("**/admin/targets", target_routes)

            def unexpected_dispatch(route):
                dispatched.append(route.request.url)
                route.abort()

            free_page.route("**/v1/proxy/browser-groq-fixture/**", unexpected_dispatch)
            free_page.goto(url, wait_until="networkidle")
            free_page.locator("#freeAiPanel summary").click()
            expect(free_page.locator("#connectFreeAi")).to_be_enabled()
            free_page.locator("#connectFreeAi").click()
            expect(free_page.locator("#targetSelect")).to_have_value(
                "browser-groq-fixture"
            )
            expect(free_page.locator("#freeAiStatus")).to_contain_text(
                "Target selected"
            )
            assert registered == [True] and dispatched == []
            free_context.close()
            print("PASS: free-model registration/select UI contract; no provider call")

            for width in (390, 820, 1440):
                responsive = context.new_page()
                observe(responsive)
                responsive.set_viewport_size({"width": width, "height": 844})
                for route in ("/", "/report.html"):
                    responsive.goto(url.rstrip("/") + route, wait_until="networkidle")
                    expect(
                        responsive.locator(
                            "#sendButton" if route == "/" else "#verifyBtn"
                        )
                    ).to_be_visible()
                    if route == "/":
                        responsive.locator("#freeAiPanel summary").click()
                    assert not responsive.evaluate(
                        "document.documentElement.scrollWidth > innerWidth"
                    )
                responsive.close()
            assert not errors, errors
            assert not unauthorized, unauthorized
            print(
                "PASS: desktop/tablet/mobile layouts; no JavaScript errors or unauthorized fetches"
            )
        finally:
            browser.close()


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--url", default="http://127.0.0.1:8000")
    parser.add_argument("--executable", default=os.environ.get("CHROMIUM_EXECUTABLE"))
    arguments = parser.parse_args()
    main(arguments.url, arguments.executable)
