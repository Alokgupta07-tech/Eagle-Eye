"""Generate a Keycloak realm without users, passwords or permissive redirects."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
from urllib.parse import urlsplit


def realm_for(public_origin: str, development_http=False):
    url = urlsplit(public_origin)
    if (
        not url.hostname
        or url.username
        or url.password
        or url.query
        or url.fragment
        or url.path not in {"", "/"}
        or url.scheme not in ({"http", "https"} if development_http else {"https"})
    ):
        raise ValueError(
            "provide an HTTPS origin without credentials, a path, query or fragment"
        )
    origin = public_origin.rstrip("/")
    return {
        "realm": "sentinel",
        "enabled": True,
        "registrationAllowed": False,
        "bruteForceProtected": True,
        "sslRequired": "external",
        "accessTokenLifespan": 300,
        "ssoSessionIdleTimeout": 1800,
        "ssoSessionMaxLifespan": 28800,
        "roles": {
            "realm": [
                {"name": name}
                for name in ("viewer", "analyst", "admin", "service", "monitor")
            ]
        },
        "clients": [
            {
                "clientId": "sentinel-console",
                "name": "SENTINEL operator console",
                "enabled": True,
                "protocol": "openid-connect",
                "publicClient": True,
                "standardFlowEnabled": True,
                "implicitFlowEnabled": False,
                "directAccessGrantsEnabled": False,
                "serviceAccountsEnabled": False,
                "redirectUris": [origin + "/auth/callback"],
                "webOrigins": [origin],
                "attributes": {"pkce.code.challenge.method": "S256"},
                "defaultClientScopes": ["profile", "roles"],
                "protocolMappers": [
                    {
                        "name": "sentinel-api-audience",
                        "protocol": "openid-connect",
                        "protocolMapper": "oidc-audience-mapper",
                        "consentRequired": False,
                        "config": {
                            "included.custom.audience": "sentinel-api",
                            "access.token.claim": "true",
                            "id.token.claim": "false",
                            "introspection.token.claim": "true",
                        },
                    }
                ],
            },
            {
                "clientId": "sentinel-api",
                "enabled": True,
                "protocol": "openid-connect",
                "bearerOnly": True,
                "standardFlowEnabled": False,
                "directAccessGrantsEnabled": False,
            },
        ],
    }


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--public-origin", required=True)
    parser.add_argument("--output", type=Path)
    parser.add_argument(
        "--development-http",
        action="store_true",
        help="Allow HTTP only for a private local test realm",
    )
    args = parser.parse_args()
    try:
        content = (
            json.dumps(realm_for(args.public_origin, args.development_http), indent=2)
            + "\n"
        )
    except ValueError as exc:
        parser.error(str(exc))
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(content)
    else:
        print(content, end="")
