"""Start a private, single-process Groq Free-plan lab; never creates provider accounts.

Credentials are read only from environment or a Git-ignored local file. --check
validates local configuration without sending any text or probing the provider.
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from app.config import Settings
from app.groq_provider import GROQ_MODELS, validate_groq


def build_settings(env_file=None, model=None):
    file = Path(env_file) if env_file else ROOT / ".env.groq"
    files = [ROOT / ".env.example"]
    if file.is_file():
        files.append(file)
    source = Settings(
        _env_file=tuple(files),
        PRODUCTION=False,
        AUTH_MODE="api_key",
        WORKER_MODE="embedded",
        REQUIRE_REDIS=False,
        REQUIRE_LIVE_JURY=False,
        JURY_MIN_VOTES=1,
        REQUIRE_IDEMPOTENCY_KEY=True,
        EMBEDDER="offline",
        OPENAI_API_KEY="",
        ANTHROPIC_API_KEY="",
        GOOGLE_API_KEY="",
        CORPUS_VALIDATION_TARGET="internal://mock",
    )
    chosen = validate_groq(source, model or source.GROQ_MODEL)
    access_keys = [source.SENTINEL_ADMIN_KEY, source.SENTINEL_PROXY_KEY]
    if (
        any(len(key) < 32 for key in access_keys)
        or len(set(access_keys)) != 2
        or source.GROQ_API_KEY in access_keys
    ):
        raise ValueError(
            "Set distinct private SENTINEL_ADMIN_KEY and SENTINEL_PROXY_KEY values of at least 32 characters; never reuse the Groq key"
        )
    return source.model_copy(
        update={
            "GROQ_MODEL": chosen,
            "JURY_MODELS": "groq/" + chosen,
            "BASELINE_PROBES": source.GROQ_BASELINE_PROBES,
            "GROQ_JUDGE_ALL_REQUESTS": True,
        }
    )


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--env-file", type=Path, default=ROOT / ".env.groq")
    parser.add_argument("--model", choices=GROQ_MODELS)
    parser.add_argument("--port", type=int, default=8000)
    parser.add_argument("--check", action="store_true")
    args = parser.parse_args()
    if not 1 <= args.port <= 65535:
        parser.error("port must be between 1 and 65535")
    try:
        settings = build_settings(args.env_file, args.model)
    except ValueError as exc:
        parser.error(str(exc))
    if args.check:
        print(
            json.dumps(
                {
                    "configuration_valid": True,
                    "provider": "groq",
                    "model": settings.GROQ_MODEL,
                    "jury_members": 1,
                    "billing_verified": False,
                    "network_calls": 0,
                    "note": "Single-model lab, not a three-provider production jury. Confirm the account's Free plan yourself.",
                },
                indent=2,
            )
        )
        return 0
    import uvicorn

    from app.main import create_app

    print(
        "Starting private Groq lab. Use your SENTINEL access keys in the console; provider keys never belong in browser fields."
    )
    uvicorn.run(
        create_app(settings),
        host="0.0.0.0",
        port=args.port,
        proxy_headers=False,
        access_log=False,
        limit_concurrency=100,
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
