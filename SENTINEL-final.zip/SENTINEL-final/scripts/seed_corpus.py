"""Check or seed curated attacks using local, explicitly simulated validation.

No live provider calls are made by this CLI, even if keys exist in the environment.
Use the budgeted evals.runner separately for authorized real-model evidence.
"""

from __future__ import annotations

import argparse
import asyncio
import json
import sys
from collections import Counter
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from app.config import Settings
from app.corpus import TRANSFORMS, load_seeds, seed_corpus
from app.corpus_schema import CATEGORIES, Seed
from app.deps import Deps


def schema():
    value = Seed.model_json_schema()
    value["properties"]["category"]["enum"] = sorted(CATEGORIES)
    value["properties"]["allowed_mutations"]["items"] = {
        "type": "string",
        "enum": sorted(TRANSFORMS),
    }
    return {
        "$schema": "https://json-schema.org/draft/2020-12/schema",
        "type": "array",
        "minItems": 1,
        "maxItems": 5000,
        "items": value,
    }


async def main(limit=None, *, path=None, revalidate=False):
    seeds = load_seeds(str(path or ROOT / "seeds/attacks.json"), limit=limit)
    # A seeding command should not unexpectedly bill live jurors, execute queued
    # assessments or call CORPUS_VALIDATION_TARGET inherited from a deployment.
    settings = Settings(
        PRODUCTION=False,
        AUTH_MODE="api_key",
        WORKER_MODE="disabled",
        REQUIRE_LIVE_JURY=False,
        ANTHROPIC_API_KEY="",
        OPENAI_API_KEY="",
        GOOGLE_API_KEY="",
        GROQ_API_KEY="",
        GROQ_FREE_PLAN_CONFIRMED=False,
        CORPUS_VALIDATION_TARGET="internal://mock",
    )
    deps = Deps(settings)
    try:
        await deps.start()
        print(
            f"[corpus] {len(seeds)} checked seeds; mock-canary validation only (not real-model evidence)"
        )
        stats = await seed_corpus(deps, seeds, revalidate=revalidate)
        await deps.audit.seal(
            {
                "type": "corpus_seed",
                "validation": "mock-only",
                "revalidate": revalidate,
                "stats": stats,
            }
        )
        print(json.dumps({**stats, "embeddings_indexed": len(deps.sim.ids)}, indent=2))
        return stats
    finally:
        await deps.stop()


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--path", type=Path, default=ROOT / "seeds/attacks.json")
    parser.add_argument(
        "--limit",
        type=int,
        help="Approximate per-category-balanced limit; small values retain at least one seed/category",
    )
    parser.add_argument(
        "--check",
        action="store_true",
        help="Validate schema, tags, mutations and duplicates without opening a database",
    )
    parser.add_argument(
        "--schema",
        action="store_true",
        help="Print the authoring JSON Schema without accessing a database",
    )
    parser.add_argument(
        "--revalidate",
        action="store_true",
        help="Explicitly rerun previously stored candidates; does not rewrite historic executions",
    )
    args = parser.parse_args()
    if args.limit is not None and args.limit < 1:
        parser.error("--limit must be positive")
    try:
        if args.schema:
            print(json.dumps(schema(), indent=2))
        elif args.check:
            seeds = load_seeds(str(args.path))
            print(
                json.dumps(
                    {
                        "valid": True,
                        "seeds": len(seeds),
                        "categories": dict(
                            sorted(Counter(seed["category"] for seed in seeds).items())
                        ),
                        "origins": dict(Counter(seed["origin"] for seed in seeds)),
                        "structured_tool_seeds": sum(
                            bool(seed.get("tools")) for seed in seeds
                        ),
                        "mutations": sorted(TRANSFORMS),
                    },
                    indent=2,
                )
            )
        else:
            asyncio.run(main(args.limit, path=args.path, revalidate=args.revalidate))
    except (ValueError, OSError) as exc:
        parser.error(str(exc))
