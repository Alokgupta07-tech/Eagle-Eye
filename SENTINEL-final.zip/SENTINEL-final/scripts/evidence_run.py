"""Legacy reporting API; the CLI delegates to the budgeted paired evaluator.

Programmatic live use requires allow_paid=True and an explicit Budget. New
campaigns should use python -m evals.runner for held-out/benign data and observable
oracles. No-key legacy calls retain their harmless offline no-op behavior.
"""

from __future__ import annotations

import asyncio
import json
import pathlib
import sys
import uuid
from datetime import date

ROOT = pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from app.baseline import baseline_target  # noqa: E402
from app.budget import Budget, active_budget
from app.config import Settings  # noqa: E402
from app.corpus import load_seeds, seed_corpus  # noqa: E402
from app.deps import Deps  # noqa: E402
from app.jury import HTTPJudge, JuryPanel
from app.report import (  # noqa: E402
    build_report,
    render_leaderboard_markdown,
    render_markdown,
)
from app.routers import leaderboard_for  # noqa: E402
from app.runner import run_batch  # noqa: E402


def pick_provider(s: Settings) -> tuple[str, str] | None:
    if s.ANTHROPIC_API_KEY:
        return "anthropic", "internal://anthropic"
    if s.OPENAI_API_KEY:
        return "openai", "internal://openai"
    return None


async def main(
    out_root: pathlib.Path | None = None,
    settings: Settings | None = None,
    limit: int | None = None,
    *,
    allow_paid: bool = False,
    budget: Budget | None = None,
) -> int:
    s = settings or Settings()
    prov = pick_provider(s)
    if not prov:
        print(
            "[evidence] no ANTHROPIC_API_KEY / OPENAI_API_KEY set — nothing to prove "
            "against a live model. Offline mock mode is unaffected. Exit 0."
        )
        return 0
    if not allow_paid or budget is None:
        raise ValueError(
            "Live evidence requires explicit consent and a Budget; prefer python -m evals.runner"
        )
    name, url = prov
    target_model = s.ANTHROPIC_MODEL if name == "anthropic" else s.OPENAI_MODEL
    budget.require_models(
        [f"{name}/{target_model}"]
        + [
            member.name
            for member in JuryPanel(s).members
            if isinstance(member, HTTPJudge)
        ]
    )
    budget_token = active_budget.set(budget)
    deps = Deps(s)
    try:
        await deps.start()
        store = deps.store
        await seed_corpus(deps, load_seeds(str(ROOT / "seeds" / "attacks.json")))
        targets = [
            await store.create_target(f"{name.title()} LIVE", url, capabilities={}),
            await store.create_target(
                "MockTarget VULNERABLE",
                "internal://mock",
                capabilities={"RAG": True},
                canary_token=s.MOCK_CANARY,
                seeded=True,
            ),
            await store.create_target(
                "MockTarget HARDENED",
                "internal://mock-hardened",
                capabilities={},
                canary_token=s.MOCK_CANARY,
                seeded=True,
            ),
        ]
        for t in targets:
            await baseline_target(deps, t)
        campaign = date.today().isoformat() + "-" + uuid.uuid4().hex[:10]
        cid = "evidence-" + campaign
        runs = []
        for t in targets:
            b = await store.latest_baseline(t["id"])
            rid = await store.create_run(
                t["id"], b["version"] if b else None, comparison_id=cid
            )
            await run_batch(deps, rid, t, limit=limit)
            runs.append((t, rid))
        out = (out_root or ROOT / "docs" / "evidence") / f"{campaign}-{name}"
        out.mkdir(parents=True, exist_ok=True)
        live_t, live_rid = runs[0]
        rep = await build_report(deps, live_rid)
        audit = await deps.audit.verify(run_id=live_rid)
        (out / "report.json").write_text(json.dumps(rep, indent=1, default=str))
        (out / "report.md").write_text(render_markdown(rep, audit))
        board = await leaderboard_for(deps, cid)
        (out / "leaderboard.json").write_text(json.dumps(board, indent=1, default=str))
        sm = rep["summary"]
        model = s.ANTHROPIC_MODEL if name == "anthropic" else s.OPENAI_MODEL
        summary = "\n".join(
            [
                f"# Evidence run — {name} ({model}) — {date.today().isoformat()}",
                "",
                f"Command: `{'ANTHROPIC_API_KEY' if name == 'anthropic' else 'OPENAI_API_KEY'}=… "
                f"python scripts/evidence_run.py`",
                "",
                f"- jury mode: **{sm['jury_mode']}**",
                f"- attacks executed against the live model: **{rep['run']['total']}**",
                f"- resisted / compromised / inconclusive: **{sm['resisted']} / {sm['successful']} / "
                f"{sm['inconclusive']}**",
                f"- resistance rate: **{sm['resistance_rate']}**",
                f"- gate-flagged: {sm.get('gate_would_block', sm.get('blocked_at_gate'))} · redacted: {sm['redacted']}",
                f"- top failing categories: {sm['top_failing_categories'] or 'none'}",
                f"- audit chain valid: {audit['valid']} ({audit['run_records']} records)",
                "",
                "Leaderboard:",
                "",
                render_leaderboard_markdown(board),
            ]
        )
        (out / "SUMMARY.md").write_text(summary)
        print(f"[evidence] wrote {out}")
        return 0
    finally:
        await deps.stop()
        active_budget.reset(budget_token)


if __name__ == "__main__":
    # The command-line entry point now uses the independent, budgeted evaluator.
    from evals.runner import main as evaluation_cli

    raise SystemExit(evaluation_cli())
