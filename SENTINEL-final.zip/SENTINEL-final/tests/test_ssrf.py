"""Public-address policy, DNS revalidation, TLS/Host preservation and redirect denial."""

from unittest.mock import AsyncMock, Mock

import httpx
import pytest

from app.ssrf import UnsafeEndpoint, validate_endpoint_url
from app.target_client import call_target


@pytest.mark.parametrize(
    "url",
    [
        "http://10.0.0.1/chat",
        "http://172.16.0.1/chat",
        "http://172.31.255.254/chat",
        "http://192.168.1.10/chat",
        "http://127.0.0.1/chat",
        "http://127.9.8.7/chat",
        "http://0.0.0.0/",
        "http://169.254.169.254/latest/meta-data/",
        "http://169.254.1.1/",
        "http://100.64.0.1/",
        "http://224.0.0.1/",
        "http://[::1]/chat",
        "http://[::]/",
        "http://[fd00::1]/",
        "http://[fe80::1]/",
        "http://[::ffff:127.0.0.1]/",
        "http://[::ffff:192.168.1.1]/",
        "http://[64:ff9b::a9fe:a9fe]/",
        "http://localhost/",
        "http://sub.localhost/",
        "http://service.local/",
        "file:///etc/passwd",
        "gopher://127.0.0.1/",
        "ftp://example.com/",
        "internal://mock-evil",
        "internal://mock/extra",
        "https://user:pass@example.com/",
        "https://example.com/#fragment",
        "http://[fe80::1%25eth0]/",
        "http://example.com\\@127.0.0.1/",
        "https://example.com/\npath",
        "https://example.com:65536/",
    ],
)
async def test_ssrf_targets_rejected_before_storage_or_baselining(
    api_client, deps, admin_hdr, url
):
    response = await api_client.post(
        "/admin/targets",
        headers=admin_hdr,
        json={"name": "blocked", "endpoint_url": url},
    )
    assert response.status_code == 422, response.text
    assert not await deps.store.list_targets()
    assert not deps.baseline_tasks


@pytest.mark.parametrize(
    "hostname", ["metadata.example", "2130706433", "0x7f000001", "0177.0.0.1"]
)
async def test_alternative_hosts_cannot_resolve_into_private_space(
    monkeypatch, hostname
):
    monkeypatch.setattr("app.ssrf.resolve_host", AsyncMock(return_value=["127.0.0.1"]))
    with pytest.raises(UnsafeEndpoint):
        await validate_endpoint_url(f"http://{hostname}/chat")


async def test_mixed_public_private_dns_is_rejected(monkeypatch):
    monkeypatch.setattr(
        "app.ssrf.resolve_host", AsyncMock(return_value=["93.184.216.34", "10.0.0.4"])
    )
    with pytest.raises(UnsafeEndpoint):
        await validate_endpoint_url("https://api.example/chat")


async def test_unresolvable_dns_fails_closed(monkeypatch):
    monkeypatch.setattr(
        "app.ssrf.resolve_host", AsyncMock(side_effect=UnsafeEndpoint("unresolvable"))
    )
    with pytest.raises(UnsafeEndpoint):
        await validate_endpoint_url("https://missing.invalid/chat")


async def test_public_target_and_known_internal_aliases_are_accepted(
    api_client, deps, admin_hdr, monkeypatch
):
    monkeypatch.setattr(
        "app.ssrf.resolve_host", AsyncMock(return_value=["93.184.216.34"])
    )
    monkeypatch.setattr(
        deps, "start_baseline", AsyncMock(return_value="test-baseline-job")
    )
    response = await api_client.post(
        "/admin/targets",
        headers=admin_hdr,
        json={"name": "public", "endpoint_url": "https://api.example/v1/chat"},
    )
    assert (
        response.status_code == 200
        and response.json()["target"]["endpoint_url"] == "https://api.example/v1/chat"
    )
    for url in (
        "internal://mock",
        "internal://mock-hardened",
        "internal://mock-rag",
        "internal://mock-rag-hardened",
        "internal://openai",
        "internal://anthropic",
    ):
        assert (await validate_endpoint_url(url)).url == url


async def test_rebinding_is_rechecked_at_dispatch(deps, monkeypatch):
    resolver = AsyncMock(side_effect=[["93.184.216.34"], ["169.254.169.254"]])
    monkeypatch.setattr("app.ssrf.resolve_host", resolver)
    endpoint = await validate_endpoint_url("https://api.example/chat")
    target = {"name": "t", "endpoint_url": endpoint.url}
    with pytest.raises(UnsafeEndpoint):
        await call_target(
            target, [{"role": "user", "content": "Hi"}], "test", deps.settings
        )
    assert resolver.await_count == 2


async def test_dispatch_pins_ip_and_preserves_host_and_tls_identity(deps, monkeypatch):
    resolver = AsyncMock(return_value=["93.184.216.34"])
    monkeypatch.setattr("app.ssrf.resolve_host", resolver)
    observed, options = [], []
    real_client = httpx.AsyncClient

    async def handle(request):
        observed.append(request)
        return httpx.Response(
            200, json={"choices": [{"message": {"content": "Hello"}}]}
        )

    def client(**kwargs):
        options.append(kwargs)
        return real_client(**kwargs, transport=httpx.MockTransport(handle))

    monkeypatch.setattr("app.target_client.httpx.AsyncClient", client)
    reply = await call_target(
        {"name": "public", "endpoint_url": "https://api.example:8443/v1/chat"},
        [{"role": "user", "content": "hello"}],
        "sid",
        deps.settings,
    )
    assert reply == "Hello" and len(observed) == 1
    assert observed[0].url.host == "93.184.216.34"
    assert observed[0].headers["Host"] == "api.example:8443"
    assert observed[0].extensions["sni_hostname"] == "api.example"
    assert options[0]["follow_redirects"] is False and options[0]["trust_env"] is False
    assert resolver.await_count == 1  # there is no second, unvalidated DNS lookup


async def test_redirect_is_not_followed(deps, monkeypatch):
    monkeypatch.setattr(
        "app.ssrf.resolve_host", AsyncMock(return_value=["93.184.216.34"])
    )
    real_client = httpx.AsyncClient
    requests = []

    async def handle(request):
        requests.append(request)
        return httpx.Response(
            302, headers={"Location": "http://169.254.169.254/latest/meta-data"}
        )

    monkeypatch.setattr(
        "app.target_client.httpx.AsyncClient",
        lambda **kwargs: real_client(**kwargs, transport=httpx.MockTransport(handle)),
    )
    with pytest.raises(httpx.HTTPStatusError):
        await call_target(
            {"name": "p", "endpoint_url": "https://api.example/chat"},
            [{"role": "user", "content": "hello"}],
            "sid",
            deps.settings,
        )
    assert len(requests) == 1
