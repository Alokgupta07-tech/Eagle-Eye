"""Whole-artifact redaction, strict address syntax and negative controls."""

import base64
import json

import jwt
import pytest

from app.pipeline import leakage_spans, redact_spans


def synthetic_jwt():
    return jwt.encode(
        {"sub": "test-only-account", "scope": "read"},
        "synthetic-signing-material-not-used-anywhere",
        algorithm="HS256",
    )


def test_jwt_is_redacted_as_one_complete_artifact():
    token = synthetic_jwt()
    text = "Authorization: Bearer " + token + ". End."
    spans = leakage_spans(text, None)
    assert len(spans) == 1 and spans[0]["type"] == "jwt"
    assert text[spans[0]["start"] : spans[0]["end"]] == token
    assert redact_spans(text, spans) == "Authorization: Bearer [REDACTED:jwt]. End."


def test_non_json_dot_sequences_are_not_jwt_evidence():
    fake = "eyJnotarealheader.abcdefghijklmnop.abcdefghijklmnopqrstuv"
    assert not any(span["type"] == "jwt" for span in leakage_spans(fake, None))


@pytest.mark.parametrize("kind", ["", "RSA ", "EC ", "OPENSSH ", "DSA ", "ENCRYPTED "])
def test_whole_private_key_blocks_are_redacted(kind):
    body = "QUJDREVGR0hJSktMTU5PUFFSU1RVVldYWVo="
    key = f"-----BEGIN {kind}PRIVATE KEY-----\n{body}\n-----END {kind}PRIVATE KEY-----"
    text = "Before.\n" + key + "\nAfter."
    spans = leakage_spans(text, None)
    assert spans == [{"start": 8, "end": 8 + len(key), "type": "private_key"}]
    assert redact_spans(text, spans) == "Before.\n[REDACTED:private_key]\nAfter."


def test_truncated_private_key_does_not_leave_the_body_exposed():
    text = "key: -----BEGIN PRIVATE KEY-----\n" + "a" * 5000
    safe = redact_spans(text, leakage_spans(text, None))
    assert safe == "key: [REDACTED:private_key]"


def test_repeated_begin_markers_do_not_expose_nested_key_material():
    text = (
        "-----BEGIN RSA PRIVATE KEY-----\n" * 100
    ) + "body\n-----END RSA PRIVATE KEY-----"
    assert redact_spans(text, leakage_spans(text, None)) == "[REDACTED:private_key]"


def test_public_key_headers_are_not_private_key_findings():
    text = "-----BEGIN PUBLIC KEY-----\nQUJD\n-----END PUBLIC KEY-----"
    assert not any(span["type"] == "private_key" for span in leakage_spans(text, None))


@pytest.mark.parametrize("prefix", ["AQOD", "AQoD", "IQoJ"])
def test_aws_session_shapes_are_redacted(prefix):
    token = prefix + base64.b64encode(b"synthetic-session-material-" * 4).decode()
    text = "session=" + token
    spans = leakage_spans(text, None)
    assert any(span["type"] == "aws_session" for span in spans)
    assert token not in redact_spans(text, spans)


@pytest.mark.parametrize("prefix", ["AKIA", "ASIA"])
def test_aws_access_ids_do_not_require_a_dash(prefix):
    token = prefix + "A1B2C3D4E5F6G7H8"
    spans = leakage_spans("access_id=" + token, None)
    assert any(span["type"] == "api_key" for span in spans)
    assert token not in redact_spans("access_id=" + token, spans)


@pytest.mark.parametrize(
    "value",
    ["correct horse battery", 'Abc"Def987!', r"Abc\Def987!", "LongSecret123!" * 500],
)
def test_quoted_password_value_is_fully_redacted(value):
    text = json.dumps({"password": value})
    safe = redact_spans(text, leakage_spans(text, None))
    assert json.loads(safe)["password"] == "[REDACTED:password_disclosure]"


def test_truncated_quoted_password_is_still_withheld():
    text = 'password: "abcdef123456'
    assert (
        redact_spans(text, leakage_spans(text, None))
        == 'password: "[REDACTED:password_disclosure]'
    )


@pytest.mark.parametrize(
    "text",
    [
        'password="******"',
        'password="[REDACTED:password_disclosure]"',
        'password="${DB_PASSWORD}"',
        "Please choose a strong password.",
    ],
)
def test_masked_or_instructional_password_text_is_quiet(text):
    assert leakage_spans(text, None) == []


@pytest.mark.parametrize(
    "address", ["10.4.2.1", "172.16.0.1", "172.31.255.255", "192.168.2.10"]
)
def test_rfc1918_hosts_are_validated_and_redacted(address):
    text = "Internal host: " + address + "."
    spans = leakage_spans(text, None)
    assert any(span["type"] == "internal_ip" for span in spans)
    assert address not in redact_spans(text, spans)
    assert leakage_spans(text, None, redact_internal_ips=False) == []


@pytest.mark.parametrize(
    "text",
    [
        "192.0.2.1",
        "198.51.100.9",
        "203.0.113.8",
        "172.32.0.1",
        "10.999.1.2",
        "192.168.1.999",
        "110.1.2.3",
        "10.1.2.3.4",
        "Ranges: 10.0.0.0/8, 172.16.0.0/12 and 192.168.0.0/16.",
    ],
)
def test_public_documentation_ranges_and_malformed_ips_are_not_private_hosts(text):
    assert not any(span["type"] == "internal_ip" for span in leakage_spans(text, None))


def test_jwt_in_percent_encoded_url_is_redacted_at_original_offsets():
    token = synthetic_jwt()
    encoded = "".join(f"%{ord(char):02X}" for char in token)
    text = f"[link](https://collector.invalid/?token={encoded}&mode=test)"
    safe = redact_spans(text, leakage_spans(text, None))
    assert encoded not in safe and "[REDACTED:jwt]" in safe and "mode=test" in safe


async def test_internal_ip_policy_is_configurable_in_the_response_gate(deps):
    target = {"id": "test-only", "canary_token": None}
    kwargs = dict(
        pattern=None,
        request_text="networking documentation",
        response_text="Connect to 10.44.3.2.",
        target=target,
        baseline=None,
    )
    assert (await deps.engine.inspect_response(**kwargs))["action"] == "REDACT"
    deps.settings.REDACT_INTERNAL_IPS = False
    assert (await deps.engine.inspect_response(**kwargs))["action"] == "NONE"
