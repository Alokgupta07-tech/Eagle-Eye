"""Constant-time validation, trusted ingress identity and versioned key derivation."""
import base64
import hashlib
from types import SimpleNamespace
from unittest.mock import Mock

import pytest
from cryptography.fernet import Fernet, InvalidToken
from fastapi import HTTPException
from starlette.requests import Request

from app.deps import client_ip, require_admin, require_proxy_key
from app.secrets import protect, reveal


def request_for(deps, peer="198.51.100.2", headers=None):
    return Request({"type": "http", "method": "GET", "path": "/", "client": (peer, 1234),
                    "headers": [(key.lower().encode(), value.encode()) for key, value in (headers or {}).items()],
                    "app": SimpleNamespace(state=SimpleNamespace(deps=deps))})


@pytest.mark.parametrize("gate,expected", [(require_admin, "test-admin-key"), (require_proxy_key, "proxy-secret")])
@pytest.mark.parametrize("provided", [None, "", "wrong", "κλειδί", "valid"])
async def test_keys_use_compare_digest_even_when_missing(deps, monkeypatch, gate, expected, provided):
    import secrets
    original = secrets.compare_digest
    compare = Mock(wraps=original)
    deps.settings.SENTINEL_PROXY_KEY = "proxy-secret"
    monkeypatch.setattr("app.deps.secrets.compare_digest", compare)
    supplied = expected if provided == "valid" else provided
    if provided == "valid":
        await gate(request_for(deps), supplied)
    else:
        with pytest.raises(HTTPException) as error:
            await gate(request_for(deps), supplied)
        assert error.value.status_code == 401
    compare.assert_called_once_with((supplied or "").encode("utf-8"), expected.encode("utf-8"))


async def test_proxy_can_be_deliberately_open(deps):
    deps.settings.SENTINEL_PROXY_KEY = ""
    await require_proxy_key(request_for(deps), None)


@pytest.mark.parametrize("peer,trust,headers,expected", [
    ("198.51.100.2", "", {"x-forwarded-for": "1.2.3.4"}, "198.51.100.2"),
    ("198.51.100.2", "10.0.0.0/8", {"x-real-ip": "1.2.3.4"}, "198.51.100.2"),
    ("10.0.0.5", "10.0.0.0/8", {"x-forwarded-for": "6.6.6.6, 198.51.100.8, 10.0.0.4"}, "198.51.100.8"),
    ("10.0.0.5", "10.0.0.0/8", {"x-real-ip": "198.51.100.9"}, "198.51.100.9"),
    ("10.0.0.5", "10.0.0.0/8", {"x-forwarded-for": "bad, 198.51.100.9"}, "10.0.0.5"),
    ("10.0.0.5", "10.0.0.0/8", {"x-real-ip": "127.0.0.1:8000"}, "10.0.0.5"),
    ("::1", "::1/128", {"x-forwarded-for": "2001:4860:4860::8888"}, "2001:4860:4860::8888"),
    ("10.0.0.5", "not-a-network", {"x-real-ip": "1.2.3.4"}, "10.0.0.5"),
])
def test_only_trusted_forwarding_hops_affect_client_ip(deps, peer, trust, headers, expected):
    deps.settings.SENTINEL_TRUSTED_PROXIES = trust
    assert client_ip(request_for(deps, peer, headers)) == expected


async def test_spoofed_xff_does_not_bypass_rate_limit(deps, api_client):
    deps.settings.RATE_LIMIT_PROXY_PER_MIN = 1
    # This client uses the already-built router's limit (30), so use the dependency directly.
    from app.deps import rate_limited
    check = rate_limited("xff-regression", 1)
    await check(request_for(deps, headers={"x-forwarded-for": "1.2.3.4"}))
    with pytest.raises(HTTPException) as error:
        await check(request_for(deps, headers={"x-forwarded-for": "5.6.7.8"}))
    assert error.value.status_code == 429


def test_pbkdf2_uses_configured_salt_and_100000_iterations(monkeypatch):
    original = hashlib.pbkdf2_hmac
    derive = Mock(wraps=original)
    monkeypatch.setattr("app.secrets.hashlib.pbkdf2_hmac", derive)
    monkeypatch.setenv("SENTINEL_SALT", "installation-salt-123456789")
    encrypted = protect("Bearer sensitive-token", "passphrase")
    assert encrypted.startswith("enc:v2:")
    derive.assert_called_once_with("sha256", b"passphrase", b"installation-salt-123456789", 100000, dklen=32)
    monkeypatch.setenv("SENTINEL_SALT", "rotated-salt")
    assert reveal(encrypted, "passphrase") == "Bearer sensitive-token"


def test_missing_salt_generates_independent_persisted_salts(monkeypatch):
    monkeypatch.delenv("SENTINEL_SALT", raising=False)
    first, second = protect("Bearer credential", "key"), protect("Bearer credential", "key")
    assert first.split(":")[2] != second.split(":")[2]
    assert reveal(first, "key") == reveal(second, "key") == "Bearer credential"
    with pytest.raises(InvalidToken):
        reveal(first, "wrong-key")


def test_legacy_credential_is_readable_and_rewritten_with_pbkdf2():
    key = base64.urlsafe_b64encode(hashlib.sha256(b"legacy-secret").digest())
    legacy = "enc:" + Fernet(key).encrypt(b"Bearer old-token").decode()
    assert reveal(legacy, "legacy-secret") == "Bearer old-token"
    upgraded = protect(legacy, "legacy-secret", "new-installation-salt")
    assert upgraded.startswith("enc:v2:") and reveal(upgraded, "legacy-secret") == "Bearer old-token"


@pytest.mark.parametrize("value", ["enc:v2:!:token", "enc:v2::token", "enc:v2:nodelimiter"])
def test_malformed_ciphertext_fails_closed(value):
    with pytest.raises(InvalidToken):
        reveal(value, "secret")
