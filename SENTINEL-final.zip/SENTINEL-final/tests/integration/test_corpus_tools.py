"""The new structured corpus field works on actual PostgreSQL, not only SQLite."""

from copy import deepcopy
from pathlib import Path

from app.corpus import load_seeds, seed_corpus
from app.runner import run_batch


async def test_structured_corpus_roundtrip_and_batch_gate_on_postgres(infrastructure):
    create, _, _ = infrastructure
    writer, reader = await create(), await create()
    path = Path(__file__).resolve().parents[2] / "seeds/attacks.json"
    seed = deepcopy(
        next(value for value in load_seeds(str(path)) if value.get("tools"))
    )
    seed["allowed_mutations"] = []
    stats = await seed_corpus(writer, [seed])
    assert stats["validated"] == 1
    stored = (await reader.store.list_patterns(statuses=None))[0]
    assert stored["tools"] == seed["tools"]
    await reader.sim.reload(reader.store)
    target = await reader.store.create_target(
        "MCP corpus integration",
        "internal://mock",
        canary_token=reader.settings.MOCK_CANARY,
    )
    run_id = await reader.store.create_run(target["id"], None)
    await run_batch(reader, run_id, target, enforce_request_block=False)
    execution = (await writer.store.list_executions(run_id))[0]
    assert execution["verdict"] == "SUCCESSFUL" and execution["action"] == "REDACT"
    assert "UNTRUSTED TOOL DEFINITIONS" in execution["variant_text"]
    assert "[REDACTED" in execution["response_excerpt"]
    assert (await writer.audit.verify())["valid"]
