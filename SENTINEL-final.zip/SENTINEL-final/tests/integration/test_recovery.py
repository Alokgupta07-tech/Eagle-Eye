"""Kill a real worker process, and verify restored evidence with the original key."""

import asyncio
import json
import os
import sys
from pathlib import Path

import pytest

from app.jobs import policy_snapshot
from app.textnorm import payload_id


async def eventually(check, timeout=20):
    async with asyncio.timeout(timeout):
        while True:
            value = await check()
            if value:
                return value
            await asyncio.sleep(0.03)


@pytest.mark.skipif(
    os.name != "posix", reason="process crash test requires POSIX signals"
)
async def test_killed_worker_does_not_repeat_an_uncertain_target_call(infrastructure):
    create, settings, _ = infrastructure
    api = await create()
    patterns = []
    for payload in ("hello first", "hello second"):
        await api.store.upsert_pattern(
            {
                "payload_hash": payload_id(payload),
                "payload": payload,
                "category": "test",
                "validation_status": "validated",
            }
        )
    patterns = await api.store.list_patterns(statuses=("validated",))
    target = await api.store.create_target("crash recovery", "internal://mock")
    run = {"id": "recovery-run", "target_id": target["id"], "status": "running"}
    job_id = await api.operations.enqueue(
        "assessment",
        target["id"],
        {
            "limit": 2,
            "categories": None,
            "enforce": False,
            "policy": policy_snapshot(settings),
            "rules": await api.store.list_rules(),
            "patterns": [
                {"id": pattern["id"], "hash": pattern["payload_hash"]}
                for pattern in patterns
            ],
        },
        run=run,
    )
    environment = os.environ.copy()
    for name, value in settings.model_dump().items():
        environment[name] = (
            json.dumps(value) if isinstance(value, (bool, dict, list)) else str(value)
        )
    environment["PYTHONUNBUFFERED"] = "1"
    environment["MOCK_LATENCY_MS"] = "2000"
    root = Path(__file__).resolve().parents[2]
    processes = []
    try:
        first = await asyncio.create_subprocess_exec(
            sys.executable,
            "-m",
            "app.worker",
            cwd=root,
            env=environment,
            stdout=asyncio.subprocess.DEVNULL,
            stderr=asyncio.subprocess.DEVNULL,
        )
        processes.append(first)

        async def started():
            return await api.store.query_one(
                "SELECT step FROM effect_receipts WHERE scope=? AND step LIKE ? AND status='started'",
                (run["id"], "%:target:1"),
            )

        uncertain = await eventually(started)
        first.kill()  # no finally block/lease release: exercise actual process failure
        await first.wait()
        environment["MOCK_LATENCY_MS"] = "0"
        second = await asyncio.create_subprocess_exec(
            sys.executable,
            "-m",
            "app.worker",
            cwd=root,
            env=environment,
            stdout=asyncio.subprocess.DEVNULL,
            stderr=asyncio.subprocess.DEVNULL,
        )
        processes.append(second)

        async def complete():
            row = await api.operations.get_job(job_id)
            return (
                row
                if row["status"] in {"completed", "failed", "indeterminate"}
                else None
            )

        finished = await eventually(complete)
        assert finished["status"] == "completed" and finished["attempts"] == 2, finished
        executions = await api.store.list_executions(run["id"])
        assert (
            len(executions) == 2 and (await api.store.get_run(run["id"]))["total"] == 2
        )
        errors = [row["response_scores"].get("error") for row in executions]
        assert errors.count("IndeterminateEffect") == 1
        receipt = await api.store.query_one(
            "SELECT status FROM effect_receipts WHERE scope=? AND step=?",
            (run["id"], uncertain["step"]),
        )
        assert (
            receipt["status"] == "started"
        )  # deliberately not dispatched again by the replacement worker
        assert (await api.audit.verify())["valid"]
    finally:
        for process in processes:
            if process.returncode is None:
                process.terminate()
                try:
                    await asyncio.wait_for(process.wait(), timeout=5)
                except TimeoutError:
                    process.kill()
                    await process.wait()


async def test_logical_audit_snapshot_restore_requires_matching_key(infrastructure):
    create, _, _ = infrastructure
    a = await create()
    for i in range(5):
        await a.audit.seal({"record": i})
    original = await a.audit.verify()
    snapshot = await a.store.query("SELECT * FROM audit_log ORDER BY seq")
    await a.store._write("TRUNCATE TABLE audit_log RESTART IDENTITY")
    await a.store.transaction(
        [
            (
                "INSERT INTO audit_log(seq,prev_hash,payload,hash,created_at) VALUES(?,?,?,?,?)",
                (
                    row["seq"],
                    row["prev_hash"],
                    row["payload"],
                    row["hash"],
                    row["created_at"],
                ),
            )
            for row in snapshot
        ]
    )
    await a.store.query(
        "SELECT setval(pg_get_serial_sequence('audit_log','seq'), (SELECT MAX(seq) FROM audit_log))"
    )
    b = await create()
    restored = await b.audit.verify()
    assert restored["valid"] and restored["verified_head"] == original["verified_head"]
    good_key = b.store.audit_key
    try:
        b.store.audit_key = b"wrong restoration key, not the original"
        assert not (await b.audit.verify())["valid"]
    finally:
        b.store.audit_key = good_key
    await b.audit.seal({"after_restore": True})
    assert (await a.audit.verify())["valid"]


async def test_history_survives_transient_redis_state_loss(infrastructure, monkeypatch):
    import httpx

    from app.main import create_app

    def client_for(deps):
        app = create_app(deps.settings)
        app.state.deps = deps
        return httpx.AsyncClient(
            transport=httpx.ASGITransport(app=app), base_url="http://integration"
        )

    create, settings, redis = infrastructure
    api = await create()
    target = await api.store.create_target("durable context", "internal://mock")
    seen = []

    async def target_call(target, messages, *args, **kwargs):
        seen.append(messages)
        return "Your project is Atlas."

    monkeypatch.setattr("app.routers.call_target", target_call)
    route = f"/v1/proxy/{target['id']}/chat"
    async with client_for(api) as client:
        assert (
            await client.post(
                route, json={"message": "My project is Atlas.", "session_id": "restore"}
            )
        ).status_code == 200
        keys = [
            key async for key in redis.scan_iter(match=settings.REDIS_NAMESPACE + ":*")
        ]
        if keys:
            await redis.delete(*keys)
        assert (
            await client.post(
                route, json={"message": "Which project?", "session_id": "restore"}
            )
        ).status_code == 200
    assert any(message["content"] == "My project is Atlas." for message in seen[-1])
    assert (await api.audit.verify())["valid"]
