"""Real services only. Each test owns an isolated SQL schema and Redis namespace."""

import asyncio
import os
import uuid
from urllib.parse import parse_qsl, urlencode, urlsplit, urlunsplit

import pytest
import pytest_asyncio

from app.config import Settings
from app.deps import Deps


@pytest_asyncio.fixture
async def infrastructure():
    import asyncpg
    import redis.asyncio as redis

    database, cache = (
        os.environ.get("TEST_DATABASE_URL"),
        os.environ.get("TEST_REDIS_URL"),
    )
    if not database or not cache:
        pytest.fail(
            "--integration requires TEST_DATABASE_URL and TEST_REDIS_URL; no fallback is permitted"
        )
    parsed = urlsplit(database)
    if not parsed.path.rstrip("/").endswith("_test"):
        pytest.fail(
            "Use a dedicated PostgreSQL database whose name ends in _test, never a production database"
        )
    schema = "sentinel_it_" + uuid.uuid4().hex
    connection = await asyncpg.connect(database, timeout=10)
    await connection.execute(f'CREATE SCHEMA "{schema}"')
    query = dict(parse_qsl(parsed.query))
    query["search_path"] = schema
    scoped_database = urlunsplit(
        (parsed.scheme, parsed.netloc, parsed.path, urlencode(query), parsed.fragment)
    )
    prefix = "it_" + uuid.uuid4().hex
    redis_client = redis.from_url(cache, socket_timeout=3, socket_connect_timeout=3)
    await redis_client.ping()  # fail, never silently skip or select memory
    settings = Settings(
        _env_file=None,
        DATABASE_URL=scoped_database,
        REDIS_URL=cache,
        REDIS_NAMESPACE=prefix,
        REQUIRE_REDIS=True,
        EMBEDDER="offline",
        SENTINEL_ADMIN_KEY="integration-admin-key",
        SENTINEL_AUDIT_SECRET="integration-audit-" + uuid.uuid4().hex,
        SENTINEL_SECRET="integration-encryption-" + uuid.uuid4().hex,
        ANTHROPIC_API_KEY="",
        OPENAI_API_KEY="",
        GOOGLE_API_KEY="",
        JURY_MODELS="openai/test,anthropic/test,google/test",
        BASELINE_PROBES=3,
        WORKER_MODE="external",
        JOB_LEASE_S=3,
        JOB_POLL_S=0.03,
        SESSION_LEASE_S=3,
        RULE_REFRESH_S=99999,
        RATE_LIMIT_PROXY_PER_MIN=100,
    )
    instances = []

    async def create(role="api"):
        deps = Deps(settings.model_copy(deep=True), role=role)
        instances.append(deps)
        await deps.start()
        assert deps.store.backend == "postgres" and deps.cache.mode == "redis"
        return deps

    try:
        yield create, settings, redis_client
    finally:
        await asyncio.gather(
            *(instance.stop() for instance in instances), return_exceptions=True
        )
        # Delete only this test's keys; never FLUSHDB/FLUSHALL a supplied server.
        keys = [key async for key in redis_client.scan_iter(match=prefix + ":*")]
        if keys:
            await redis_client.delete(*keys)
        await redis_client.aclose()
        await connection.execute(f'DROP SCHEMA "{schema}" CASCADE')
        await connection.close()
