"""Deployment cannot silently choose demonstration identity/storage/jury modes."""

import pytest

from app.config import Settings
from app.deps import Deps
from scripts.keycloak_realm import realm_for


def production(**overrides):
    values = dict(
        _env_file=None,
        PRODUCTION=True,
        AUTH_MODE="oidc",
        DATABASE_URL="postgresql://sentinel@database/sentinel",
        OIDC_ISSUER="https://identity.example/realm",
        OIDC_AUDIENCE="sentinel-api",
        OIDC_CLIENT_ID="sentinel-console",
        OIDC_REDIRECT_URI="https://console.example/auth/callback",
        SENTINEL_SECRET="test-independent-encryption-secret-32-bytes",
        SENTINEL_AUDIT_SECRET="test-independent-audit-secret-32-bytes",
        REQUIRE_REDIS=True,
        WORKER_MODE="external",
        REQUIRE_LIVE_JURY=True,
        JURY_MIN_VOTES=2,
        REQUIRE_IDEMPOTENCY_KEY=True,
        RATE_LIMIT_ENABLED=True,
        EMBEDDER="offline",
        CORS_ORIGINS="",
    )
    values.update(overrides)
    return Settings(**values)


def test_explicit_production_configuration_is_valid():
    assert production().PRODUCTION


@pytest.mark.parametrize(
    "change",
    [
        {"AUTH_MODE": "api_key"},
        {"DATABASE_URL": "sqlite:///local.db"},
        {"REQUIRE_REDIS": False},
        {"WORKER_MODE": "embedded"},
        {"WORKER_MODE": "disabled"},
        {"REQUIRE_LIVE_JURY": False},
        {"JURY_MIN_VOTES": 1},
        {"REQUIRE_IDEMPOTENCY_KEY": False},
        {"RATE_LIMIT_ENABLED": False},
        {"SENTINEL_SECRET": "short"},
        {"SENTINEL_PROXY_KEY": "demo"},
        {"SENTINEL_AUDIT_SECRET": "test-independent-encryption-secret-32-bytes"},
        {"CORS_ORIGINS": "*"},
        {"EMBEDDER": "auto"},
        {"OIDC_ISSUER": "http://identity.example/realm"},
        {"OIDC_REDIRECT_URI": "https://console.example/wrong-path"},
        {"OIDC_AUDIENCE": "sentinel-console"},
    ],
)
def test_insecure_production_changes_are_rejected(change):
    with pytest.raises(ValueError):
        production(**change)


async def test_required_redis_cannot_fall_back_to_memory(tmp_path):
    settings = Settings(
        _env_file=None,
        DATABASE_URL="sqlite:///" + str(tmp_path / "required.db"),
        SENTINEL_AUDIT_SECRET="fixture-audit-secret",
        REDIS_URL="redis://127.0.0.1:1/0",
        REQUIRE_REDIS=True,
        EMBEDDER="offline",
    )
    deps = Deps(settings)
    with pytest.raises(RuntimeError, match="Redis is required"):
        await deps.start()
    assert deps.store._conn is None


async def test_required_live_jury_rejects_mock_members(tmp_path):
    settings = Settings(
        _env_file=None,
        DATABASE_URL="sqlite:///" + str(tmp_path / "jury.db"),
        SENTINEL_AUDIT_SECRET="fixture-audit-secret",
        REDIS_URL="redis://127.0.0.1:1/0",
        REQUIRE_LIVE_JURY=True,
        EMBEDDER="offline",
        OPENAI_API_KEY="",
        ANTHROPIC_API_KEY="",
        GOOGLE_API_KEY="",
    )
    deps = Deps(settings)
    with pytest.raises(RuntimeError, match="live jury"):
        await deps.start()
    assert deps.store._conn is None


def test_empty_optional_authorization_parameters_are_valid():
    assert (
        Settings(_env_file=None, OIDC_AUTHORIZATION_PARAMS="").OIDC_AUTHORIZATION_PARAMS
        == {}
    )
    assert Settings(
        _env_file=None, OIDC_AUTHORIZATION_PARAMS='{"audience":"api"}'
    ).OIDC_AUTHORIZATION_PARAMS == {"audience": "api"}


def test_keycloak_export_has_no_users_or_wildcard_redirects():
    realm = realm_for("https://console.example")
    client = realm["clients"][0]
    assert "users" not in realm and "secret" not in client
    assert client["redirectUris"] == ["https://console.example/auth/callback"]
    assert client["attributes"]["pkce.code.challenge.method"] == "S256"
    assert client["protocolMappers"][0]["config"]["id.token.claim"] == "false"
    assert not client["implicitFlowEnabled"] and not client["directAccessGrantsEnabled"]
    with pytest.raises(ValueError):
        realm_for("http://insecure.example")
