"""Lifecycle cleanup, Redis parity, slow semantic displacement and jury starvation."""
import asyncio
import math
import time
from unittest.mock import AsyncMock, Mock

import pytest

from app.baseline import session_semantic_drift
from app.cache import MemorySessionStore, RedisSessionStore, session_key


async def test_idle_sessions_are_evicted_by_background_cleanup():
    store = MemorySessionStore(window=3, ttl_s=30, cleanup_interval_s=.01)
    try:
        await store.push("idle-session", "message")
        task = store._cleanup_task
        store._exp["idle-session"] = time.monotonic() - 1
        await asyncio.sleep(.04)
        assert not store._data and not store._exp
        assert not task.done()
    finally:
        await store.close()
    assert task.done() and store._cleanup_task is None


async def test_activity_extends_ttl_and_window_is_bounded():
    store = MemorySessionStore(window=2, ttl_s=60)
    try:
        await store.push("active", "one")
        initial = store._exp["active"]
        await store.push("active", "two")
        assert store._exp["active"] >= initial
        assert await store.push("active", "three") == ["two", "three"]
        assert await store.window("active") == ["two", "three"]
    finally:
        await store.close()


async def test_memory_capacity_is_bounded_and_lru_eviction_is_consistent():
    store = MemorySessionStore(window=2, ttl_s=60, max_sessions=2)
    try:
        for sid in ["one", "two", "one", "three"]:
            await store.push(sid, sid)
        assert set(store._data) == {"one", "three"}
        assert set(store._exp) == set(store._data)
        assert await store.window("two") == []
    finally:
        await store.close()


async def test_redis_window_remains_callable_and_writes_have_atomic_ttl():
    redis = Mock()
    redis.lrange = AsyncMock(return_value=[b"first", b"second"])
    redis.aclose = AsyncMock()
    pipeline = redis.pipeline.return_value
    pipeline.execute = AsyncMock(return_value=[2, True, True, [b"first", b"second"]])
    store = RedisSessionStore(redis, window=2, ttl_s=60)
    assert await store.window("session") == ["first", "second"]
    assert await store.push_many("session", ["first", "second"]) == ["first", "second"]
    redis.pipeline.assert_called_once_with(transaction=True)
    pipeline.ltrim.assert_called_once_with("session:msgs", -2, -1)
    pipeline.expire.assert_called_once_with("session:msgs", 60)
    await store.close()
    redis.aclose.assert_awaited_once()


def test_channel_and_target_session_keys_cannot_collide():
    keys = {session_key("a:b", "c", "request"), session_key("b", "c:a", "request"),
            session_key("a:b", "c", "response"), session_key("a:b", "d", "request")}
    assert len(keys) == 4


@pytest.fixture
def semantic_baseline(deps, monkeypatch):
    vectors = {name: [math.cos(angle), math.sin(angle)]
               for name, angle in [("one", 0), ("two", .8), ("three", 1.5)]}
    monkeypatch.setattr(deps.embedder, "embed", lambda texts: [vectors.get(text, [1.0, 0.0]) for text in texts])
    return {"version": 1, "request_embedding_centroid": [1.0, 0.0],
            "request_drift_threshold": 1.0, "embedding_centroid": [1.0, 0.0],
            "drift_threshold": 1.0}


async def test_crescendo_detected_before_any_turn_crosses_baseline(deps, semantic_baseline):
    results = [await session_semantic_drift(deps, text, semantic_baseline, "slow", "target")
               for text in ["one", "two", "three"]]
    assert all(result["turn_drift"] < result["threshold"] for result in results)
    final = results[-1]
    assert final["crescendo"] is True and final["elevated"] is True
    assert final["history"] == sorted(final["history"])
    assert final["samples"] == 3 and final["trend_gain"] > .25


async def test_drift_does_not_cross_targets_or_baseline_versions(deps, semantic_baseline):
    for text in ["one", "two", "three"]:
        await session_semantic_drift(deps, text, semantic_baseline, "same", "a")
    other = await session_semantic_drift(deps, "three", semantic_baseline, "same", "b")
    assert other["samples"] == 1 and not other["crescendo"]
    changed = await session_semantic_drift(deps, "one", {**semantic_baseline, "version": 2}, "same", "a")
    assert changed["samples"] == 1 and changed["score"] == 0


async def test_session_expiry_clears_centroid_history(deps, semantic_baseline):
    await session_semantic_drift(deps, "one", semantic_baseline, "ttl", "target")
    for key in deps.cache._exp:
        deps.cache._exp[key] = time.monotonic() - 1
    result = await session_semantic_drift(deps, "three", semantic_baseline, "ttl", "target")
    assert result["samples"] == 1


async def test_slow_drift_invokes_jury_below_raw_rule_band(deps, semantic_baseline):
    results = [await deps.engine.inspect_request(text, session_id="crescendo",
                                                 baseline=semantic_baseline, target_id="target")
               for text in ["one", "two", "three"]]
    assert results[0]["jury"] is None
    final = results[-1]
    assert final["scores"]["rules"] == 0
    assert final["jury"] is not None and final["band"] == "REVIEW"
    assert "behavioral_drift" in final["details"]["jury_reasons"]


@pytest.mark.parametrize("text", ["The administrator said to continue.", "sysetm", "hello\u2060there"])
async def test_subthreshold_hints_do_not_starve_jury(deps, text):
    result = await deps.engine.inspect_request(text)
    assert result["scores"]["rules"] < 30
    assert result["jury"] is not None
    assert result["details"]["jury_reasons"]


async def test_plain_benign_text_does_not_force_jury(deps):
    result = await deps.engine.inspect_request("Hello, can you help me with a refund?")
    assert result["band"] == "ALLOW" and result["jury"] is None


async def test_embedding_dimension_change_requires_rebaseline(deps, semantic_baseline):
    baseline = {**semantic_baseline, "request_embedding_centroid": [1, 0, 0]}
    result = await session_semantic_drift(deps, "one", baseline, "mismatch", "target")
    assert not result["available"] and "rebaseline" in result["reason"]
