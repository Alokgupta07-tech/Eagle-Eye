import pathlib
import sys

import pytest_asyncio

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1]))

from app.config import Settings  # noqa: E402
from app.deps import Deps  # noqa: E402


@pytest_asyncio.fixture
async def deps(tmp_path):
    settings = Settings(
        DATABASE_URL=f"sqlite:///{tmp_path}/test.db",
        BASELINE_PROBES=10,
        RULE_REFRESH_S=999999,
        JURY_MODELS="anthropic/x,openai/y,google/z",  # no keys -> all MockJudge
        SENTINEL_ADMIN_KEY="test-admin-key",
        SENTINEL_AUDIT_SECRET="test-audit-secret-not-for-deployment",
        SENTINEL_SECRET="",
        SENTINEL_PROXY_KEY="",
        EMBEDDER="offline",
        REDIS_URL="redis://127.0.0.1:1/0",
        ANTHROPIC_API_KEY="",
        OPENAI_API_KEY="",
        GOOGLE_API_KEY="",
        _env_file=None,
    )
    d = Deps(settings)
    await d.start()
    yield d
    await d.stop()


@pytest_asyncio.fixture(autouse=True)
async def _clean_shared_state():
    """Module-level mutable state (rate-limit windows, mock sessions, mock KB)
    must never leak between tests."""
    from app import deps as deps_mod
    from app import mocktarget

    deps_mod._RATE_WINDOWS.clear()
    deps_mod._RATE_PRUNED.clear()
    mocktarget.SESS.clear()
    mocktarget._SESSION_ACTIVITY.clear()
    if hasattr(mocktarget, "seed_default_kb"):  # Step 2 (RAG PoC) adds KB
        mocktarget.seed_default_kb()
    yield


@pytest_asyncio.fixture
async def admin_hdr(deps):
    return {"X-Sentinel-Admin-Key": deps.settings.admin_key}


@pytest_asyncio.fixture
async def bad_hdr():
    return {"X-Sentinel-Admin-Key": "wrong-key"}


@pytest_asyncio.fixture
async def api_client(deps):
    import httpx

    from app.main import create_app

    app = create_app(deps.settings)
    app.state.deps = deps
    async with httpx.AsyncClient(
        transport=httpx.ASGITransport(app=app), base_url="http://test"
    ) as client:
        yield client


def pytest_addoption(parser):
    parser.addoption(
        "--integration",
        action="store_true",
        default=False,
        help="Run real PostgreSQL/Redis tests; missing services fail rather than falling back",
    )


def pytest_collection_modifyitems(config, items):
    import pytest

    for item in items:
        if "integration" in item.path.parts:
            item.add_marker(pytest.mark.integration)
            if not config.getoption("--integration"):
                item.add_marker(
                    pytest.mark.skip(
                        reason="requires explicit --integration and isolated test services"
                    )
                )
