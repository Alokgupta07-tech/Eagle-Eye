"""Sealed audit chain: verification + tamper evidence (P6)."""


async def test_chain_appends_and_verifies(deps):
    for i in range(3):
        await deps.audit.seal({"run_id": "t", "i": i, "mode": "batch"})
    out = await deps.audit.verify()
    assert out["valid"] is True and out["checked"] == 3
    out2 = await deps.audit.verify(run_id="t")
    assert out2["run_records"] == 3


async def test_tamper_breaks_chain(deps):
    for i in range(4):
        await deps.audit.seal({"i": i})
    # silently alter one stored record
    await deps.store._write("UPDATE audit_log SET payload='{\"i\": 999}' WHERE seq=2")
    out = await deps.audit.verify()
    assert out["valid"] is False
    assert out["first_bad_seq"] == 2


async def test_malformed_json_reports_tampering_without_500(deps, api_client):
    for value in range(3):
        await deps.audit.seal({"run_id": "bad-json", "value": value})
    await deps.store._write(
        "UPDATE audit_log SET payload=? WHERE seq=2", ("not-json{",)
    )
    response = await api_client.get("/audit/verify", params={"run_id": "bad-json"})
    assert response.status_code == 200
    result = response.json()
    assert result["valid"] is False and result["first_bad_seq"] == 2
    assert result["reason"] == "malformed_payload"
    assert result["checked"] == 2 and result["run_records"] == 1


async def test_non_object_json_reports_tampering(deps):
    await deps.audit.seal({"run_id": "types"})
    for invalid in ("null", "[]", "42", '"string"', "true"):
        await deps.store._write(
            "UPDATE audit_log SET payload=? WHERE seq=1", (invalid,)
        )
        result = await deps.audit.verify(run_id="types")
        assert result["valid"] is False and result["first_bad_seq"] == 1
        assert result["reason"] == "invalid_payload_type"


async def test_invalid_payload_type_is_handled_without_json_crash(deps, monkeypatch):
    from unittest.mock import AsyncMock

    monkeypatch.setattr(
        deps.store,
        "query",
        AsyncMock(
            return_value=[
                {"seq": 1, "payload": None, "hash": "a" * 64, "prev_hash": "0" * 64}
            ]
        ),
    )
    result = await deps.audit.verify()
    assert result["first_bad_seq"] == 1 and result["reason"] == "malformed_payload"


async def test_database_writer_cannot_rehash_forward_with_sha256(deps):
    import json

    from app.textnorm import canonical_json, sha256_hex

    for index in range(4):
        await deps.audit.seal({"index": index})
    rows = await deps.store.query("SELECT * FROM audit_log ORDER BY seq")
    previous = rows[0]["hash"]
    for row in rows[1:]:
        payload = json.loads(row["payload"])
        payload["index"] = 999
        forged = sha256_hex(previous + canonical_json(payload))
        await deps.store._write(
            "UPDATE audit_log SET payload=?,prev_hash=?,hash=? WHERE seq=?",
            (canonical_json(payload), previous, forged, row["seq"]),
        )
        previous = forged
    assert (await deps.audit.verify())["first_bad_seq"] == 2


async def test_changing_hmac_key_invalidates_chain(deps):
    await deps.audit.seal({"operation": "test"})
    assert (await deps.audit.verify())["algorithm"] == "hmac-sha256-v1"
    deps.store.audit_key = b"different-audit-key"
    assert (await deps.audit.verify())["valid"] is False


async def test_fallback_key_survives_restart_and_is_private(tmp_path):
    import stat

    from app.config import Settings
    from app.db import Store

    settings = Settings(
        _env_file=None,
        DATABASE_URL=f"sqlite:///{tmp_path}/audit.db",
        SENTINEL_AUDIT_SECRET="",
    )
    first = Store(settings)
    await first.connect()
    await first.audit_append({"persisted": True})
    key = first.audit_key
    await first.close()
    keyfile = tmp_path / ".audit-secret.key"
    assert stat.S_IMODE(keyfile.stat().st_mode) == 0o600
    second = Store(settings)
    await second.connect()
    try:
        assert second.audit_key == key
        assert (await second.audit_verify())["valid"] is True
    finally:
        await second.close()


async def test_concurrent_stores_cannot_fork_sqlite_chain(deps):
    import asyncio

    from app.db import Store

    other = Store(deps.settings)
    await other.connect()
    try:
        seqs = await asyncio.gather(
            *[
                (deps.store if index % 2 else other).audit_append({"index": index})
                for index in range(40)
            ]
        )
        assert len(set(seqs)) == 40
        result = await deps.audit.verify()
        assert result["valid"] is True and result["checked"] == 40
    finally:
        await other.close()
