# Staging load and failure tests

`locustfile.py` accepts **only an existing `internal://mock` target**. It never
executes a real model or an external tool. This is intentional: load generation
must not create an uncontrolled provider bill or affect a production assistant.
Use the separately budgeted evaluator for low-volume real-provider latency.

## Prepare an isolated staging instance

1. Install `requirements-load.txt` and provision PostgreSQL/Redis as described in
   `docs/PRODUCTION.md`. Use a dedicated database and Redis namespace.
2. Configure `PRODUCTION=false`, `REQUIRE_REDIS=true`, `WORKER_MODE=external`,
   `EMBEDDER=offline`, and empty provider keys. Use a private staging admin key.
3. Run `python scripts/demo_setup.py`, then start an API process and an external
   worker (`python -m app.worker`) using the same configuration and audit secret.
4. For throughput measurement only, disable the staging quota with
   `RATE_LIMIT_ENABLED=false`. Production mode intentionally forbids this.
   Keep quotas enabled when testing the separate `quota` profile.
5. Set `SENTINEL_LOAD_TARGET_ID` to the vulnerable built-in target's ID. Omitting
   it selects the first `internal://mock` target returned by authenticated discovery.

Credentials are read from `SENTINEL_ADMIN_KEY` and `SENTINEL_PROXY_KEY`. For an
OIDC-enabled staging server, supply an analyst access token through
`SENTINEL_LOAD_ACCESS_TOKEN` instead. Never put credentials in command arguments,
URLs, committed `.env` files or benchmark artifacts.

## Run a bounded test

From the repository root, against your local staging instance:

```bash
pip install -r requirements-load.txt
mkdir -p reports/load
locust -f load/locustfile.py --host http://127.0.0.1:8000 \
  --headless --users 5 --spawn-rate 1 --run-time 2m --stop-timeout 20 \
  --csv reports/load/mixed --html reports/load/mixed.html
```

Increase users gradually (for example 5, 10, then 25), measuring each step. The
default `SENTINEL_LOAD_MAX_REQUESTS=2000` is a **per-load-generator** safety bound,
not a distributed global limit. Always specify `--run-time`. An unexpected HTTP
or application failure makes the headless run exit nonzero.

Profiles, selected with `SENTINEL_LOAD_PROFILE`:

- `mixed`: benign prompts, multi-turn conversations, known injection probes and
  nested tool poisoning. Every REVIEW is safely blocked and logged, not approved.
- `quota`: the same workload with 429s counted as intentional quota enforcement.
  It is not a throughput benchmark of the inspection engine.
- `contention`: multiple users deliberately share one session; 409 conflicts are
  expected and counted. Set `MOCK_LATENCY_MS=200` on the staging API to make the
  overlap observable. This setting affects only the mock adapters.

The final `SENTINEL_LOAD_COUNTERS` line separates completed requests, quota
responses, conflicts and quarantines. Locust CSV/HTML contains HTTP latency and
failure statistics; no raw prompts, provider keys or bearer tokens are exported.

## Measure and exercise failures

Scrape authenticated `/metrics` on every API replica. Use an OIDC service account
with the `monitor` role, which cannot change policy, run assessments or dispatch
prompts. Metrics expose bounded route labels, queue depth and worker heartbeats;
the database-wide queue/worker gauges should not be summed across API replicas.

Record throughput, p50/p95/p99 latency, unexpected 5xx/application failures,
process memory, database connections and job backlog. A reasonable acceptance
plan is zero cross-session mixing, zero duplicate dispatch on idempotent retries,
valid audit chains, bounded memory after expiration, and recovery within a
measured service-specific error/latency budget. These are targets, not claimed
results or universal industry thresholds.

While using mocks and synthetic data only:

- Kill a worker mid-assessment; completed receipts resume, uncertain calls must
  become INCONCLUSIVE rather than being dispatched again.
- Restart one API replica; retry an idempotent request through another.
- Interrupt Redis or PostgreSQL; readiness must fail and unsafe replies must not
  be served. Restore the service and verify recovery.
- Submit competing quarantine approvals; exactly one may consume the lease.
- Restore a database backup with the original audit/encryption secrets and verify
  integrity. Wrong keys must not authenticate the history.

Automated real-service cases are in `tests/integration/`, including a SIGKILL
worker recovery test. Those tests use isolated schemas and key prefixes, never
`FLUSHDB` or a production database. See `docs/TESTING.md` for CI and local commands.

A mock-only load run measures implementation overhead, not real-provider latency,
detection accuracy or production capacity. Publish the environment, duration,
concurrency and quota settings with every result.
