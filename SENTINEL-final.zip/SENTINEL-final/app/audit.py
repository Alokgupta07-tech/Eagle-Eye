"""Keyed, append-only audit chain. A database writer cannot forge new HMACs.

The installation key is separate from the database. Set SENTINEL_AUDIT_SECRET on
all workers, or retain the private, atomically-created fallback key file. Legacy
unkeyed records deliberately fail verification; they are never silently re-sealed.
Chain truncation requires an independently retained head/checkpoint to detect.
"""
from __future__ import annotations

import hashlib
import hmac
import os
import secrets
import stat
import tempfile
from pathlib import Path

from .textnorm import canonical_json

ALGORITHM = "hmac-sha256-v1"


def load_audit_key(settings) -> bytes:
    if settings.SENTINEL_AUDIT_SECRET:
        return settings.SENTINEL_AUDIT_SECRET.encode("utf-8")
    configured = settings.SENTINEL_AUDIT_KEY_FILE
    if configured:
        path = Path(configured)
    elif settings.is_postgres:
        path = Path("data/.audit-secret.key")
    else:
        database = Path(settings.DATABASE_URL.split("sqlite:///", 1)[-1])
        path = database.absolute().parent / ".audit-secret.key"
    path.parent.mkdir(parents=True, exist_ok=True)
    if not path.exists():
        # Link a fully flushed private file without replacing another worker's key.
        fd, temporary = tempfile.mkstemp(prefix=".audit-secret-", dir=path.parent)
        try:
            with os.fdopen(fd, "wb") as out:
                out.write(secrets.token_bytes(32))
                out.flush()
                os.fsync(out.fileno())
            try:
                os.link(temporary, path)
            except FileExistsError:
                pass  # another worker published the installation key first
        finally:
            os.unlink(temporary)
    if os.name == "posix":
        # Persist the directory entry too: flushing only the key's contents does
        # not make a newly published key survive a filesystem/power failure.
        directory = os.open(path.parent, os.O_RDONLY | getattr(os, "O_DIRECTORY", 0))
        try:
            os.fsync(directory)
        finally:
            os.close(directory)
    fd = os.open(path, os.O_RDONLY | getattr(os, "O_NOFOLLOW", 0))
    with os.fdopen(fd, "rb") as source:
        info = os.fstat(source.fileno())
        if not stat.S_ISREG(info.st_mode) or info.st_mode & 0o077:
            raise RuntimeError("audit fallback key must be a regular private file (chmod 600)")
        key = source.read(4097)
    if len(key) < 32 or len(key) > 4096:
        raise RuntimeError("invalid audit fallback key; restore the original installation key")
    return key


def chain_hmac(key: bytes, previous: str, payload: dict) -> str:
    message = f"SENTINEL:{ALGORITHM}\0{previous}\0{canonical_json(payload)}"
    return hmac.new(key, message.encode("utf-8"), hashlib.sha256).hexdigest()


def valid_mac(actual, expected: str) -> bool:
    # Byte comparison also safely rejects non-ASCII / malformed database values.
    return isinstance(actual, str) and secrets.compare_digest(
        actual.encode("utf-8"), expected.encode("ascii"))


class Audit:
    def __init__(self, store):
        self.store = store

    async def seal(self, payload: dict) -> int:
        return await self.store.audit_append(payload)

    async def verify(self, run_id: str | None = None) -> dict:
        return await self.store.audit_verify(run_id=run_id)
