"""Distributed leases, versioned conversations, ephemeral SSO state and quotas.

Redis mutations are atomic Lua operations. Lease loss cancels the owner; a fenced
compare-and-set still prevents stale history writes if cancellation arrives late.
The bounded memory implementation is for a single-process offline demo only.
"""

from __future__ import annotations

import asyncio
import hashlib
import json
import secrets
import time
from collections import OrderedDict
from contextlib import asynccontextmanager, suppress


class SessionBusy(Exception):
    """A concurrent request already owns this conversation."""


class LeaseLost(Exception):
    """The request no longer owns its dispatch/history lease."""


class CapacityExceeded(Exception):
    """Refuse work rather than silently discarding active coordination state."""


def key_for(*parts: str) -> str:
    digest = hashlib.sha256(json.dumps(parts, ensure_ascii=True).encode()).hexdigest()
    return "sentinel:{coord}:" + digest


class Lease:
    def __init__(self, backend, key, token, seconds):
        self.backend, self.key, self.token, self.seconds = backend, key, token, seconds
        self.lost = False
        self.owner = asyncio.current_task()
        self.task = None

    async def check(self):
        if self.lost or not await self.backend.owns(self.key, self.token):
            self.lost = True
            raise LeaseLost("conversation lease lost")

    async def renew(self):
        while True:
            await asyncio.sleep(self.seconds / 3)
            try:
                if await self.backend.renew(self.key, self.token, self.seconds):
                    continue
            except Exception:
                pass
            self.lost = True
            self.owner.cancel("conversation lease lost")
            return


class Coordinator:
    @asynccontextmanager
    async def lease(self, key: str, seconds: float):
        token = secrets.token_hex(24)
        if not await self.acquire(key, token, seconds):
            raise SessionBusy("conversation is already processing a request")
        lease = Lease(self, key, token, seconds)
        lease.task = asyncio.create_task(lease.renew(), name="conversation-lease")
        try:
            yield lease
            await lease.check()
        except asyncio.CancelledError:
            if lease.lost:
                raise LeaseLost("conversation lease lost") from None
            raise
        finally:
            lease.task.cancel()
            with suppress(asyncio.CancelledError):
                await lease.task
            # A failed unlock cannot authorize another write; the lease expires.
            with suppress(Exception):
                await self.release(key, token)

    async def conversation(self, key):
        value = await self.get(key)
        return value if value is not None else {"version": 0, "history": []}


class MemoryCoordinator(Coordinator):
    mode = "memory"

    def __init__(self, max_bytes=64 * 1024 * 1024, max_entries=8192):
        self.values = OrderedDict()
        self.leases = {}
        self.max_bytes, self.max_entries = max_bytes, max_entries
        self.size = 0

    def cleanup(self):
        now = time.monotonic()
        for key, (raw, expiry) in list(self.values.items()):
            if expiry <= now:
                self.size -= len(raw)
                del self.values[key]
        self.leases = {
            key: value for key, value in self.leases.items() if value[1] > now
        }

    async def get(self, key):
        self.cleanup()
        item = self.values.get(key)
        return json.loads(item[0]) if item else None

    async def set(self, key, value, ttl, *, only_if_absent=False):
        self.cleanup()
        if only_if_absent and key in self.values:
            return False
        raw = json.dumps(value, separators=(",", ":"), ensure_ascii=True).encode()
        previous_size = len(self.values[key][0]) if key in self.values else 0
        if self.size - previous_size + len(raw) > self.max_bytes or (
            key not in self.values and len(self.values) >= self.max_entries
        ):
            raise CapacityExceeded("coordination capacity reached")
        self.size += len(raw) - previous_size
        self.values[key] = (raw, time.monotonic() + ttl)
        return True

    async def take(self, key):
        self.cleanup()
        item = self.values.pop(key, None)
        if item:
            self.size -= len(item[0])
            return json.loads(item[0])
        return None

    async def acquire(self, key, token, seconds):
        self.cleanup()
        if key in self.leases:
            return False
        if len(self.leases) >= self.max_entries:
            raise CapacityExceeded("too many active conversations")
        self.leases[key] = (token, time.monotonic() + seconds)
        return True

    async def owns(self, key, token):
        self.cleanup()
        return key in self.leases and secrets.compare_digest(self.leases[key][0], token)

    async def renew(self, key, token, seconds):
        if not await self.owns(key, token):
            return False
        self.leases[key] = (token, time.monotonic() + seconds)
        return True

    async def release(self, key, token):
        if await self.owns(key, token):
            del self.leases[key]

    async def save_conversation(
        self, key, history, version, lease, ttl, signature=None
    ):
        # No await below yields to another owner in this in-process implementation.
        await lease.check()
        current = await self.conversation(key)
        if current["version"] != version:
            raise LeaseLost("conversation version changed")
        await self.set(
            key, {"version": version + 1, "history": history, "mac": signature}, ttl
        )

    async def close(self):
        self.values.clear()
        self.leases.clear()
        self.size = 0


_RENEW = """
if redis.call('GET', KEYS[1]) ~= ARGV[1] then return 0 end
return redis.call('PEXPIRE', KEYS[1], ARGV[2])
"""
_RELEASE = """
if redis.call('GET', KEYS[1]) ~= ARGV[1] then return 0 end
return redis.call('DEL', KEYS[1])
"""
_TAKE = """
local value = redis.call('GET', KEYS[1])
if value then redis.call('DEL', KEYS[1]) end
return value
"""
_SAVE = """
if redis.call('GET', KEYS[1]) ~= ARGV[1] then return 0 end
local current = redis.call('GET', KEYS[2])
local version = 0
if current then version = cjson.decode(current)['version'] end
if version ~= tonumber(ARGV[2]) then return 0 end
redis.call('SET', KEYS[2], ARGV[3], 'EX', ARGV[4])
return 1
"""
_RATE = """
local clock = redis.call('TIME')
local now = tonumber(clock[1]) * 1000 + math.floor(tonumber(clock[2]) / 1000)
local retry = 0
for i,key in ipairs(KEYS) do
    redis.call('ZREMRANGEBYSCORE', key, '-inf', now - 60000)
    if redis.call('ZCARD', key) >= tonumber(ARGV[i + 1]) then
        local oldest = redis.call('ZRANGE', key, 0, 0, 'WITHSCORES')
        retry = math.max(retry, tonumber(oldest[2]) + 60000 - now)
    end
end
if retry > 0 then return math.ceil(retry / 1000) end
for _,key in ipairs(KEYS) do
    redis.call('ZADD', key, now, ARGV[1])
    redis.call('EXPIRE', key, 61)
end
return 0
"""


class RedisCoordinator(Coordinator):
    mode = "redis"

    def __init__(self, client, namespace=""):
        self.r = client
        self.prefix = namespace + ":" if namespace else ""

    async def get(self, key):
        raw = await self.r.get(self.prefix + key)
        return json.loads(raw) if raw is not None else None

    async def set(self, key, value, ttl, *, only_if_absent=False):
        return bool(
            await self.r.set(
                self.prefix + key,
                json.dumps(value, separators=(",", ":")),
                ex=max(1, int(ttl)),
                nx=only_if_absent,
            )
        )

    async def take(self, key):
        raw = await self.r.eval(_TAKE, 1, self.prefix + key)
        return json.loads(raw) if raw is not None else None

    async def acquire(self, key, token, seconds):
        return bool(
            await self.r.set(
                self.prefix + key, token, nx=True, px=max(1, int(seconds * 1000))
            )
        )

    async def owns(self, key, token):
        value = await self.r.get(self.prefix + key)
        if isinstance(value, bytes):
            value = value.decode()
        return isinstance(value, str) and secrets.compare_digest(value, token)

    async def renew(self, key, token, seconds):
        return bool(
            await self.r.eval(_RENEW, 1, self.prefix + key, token, int(seconds * 1000))
        )

    async def release(self, key, token):
        await self.r.eval(_RELEASE, 1, self.prefix + key, token)

    async def save_conversation(
        self, key, history, version, lease, ttl, signature=None
    ):
        value = json.dumps(
            {"version": version + 1, "history": history, "mac": signature},
            separators=(",", ":"),
        )
        if not await self.r.eval(
            _SAVE,
            2,
            self.prefix + lease.key,
            self.prefix + key,
            lease.token,
            version,
            value,
            ttl,
        ):
            lease.lost = True
            raise LeaseLost("conversation changed or lease was lost")

    async def rate_limit(self, keys_and_limits):
        keys, limits = zip(*keys_and_limits)
        return int(
            await self.r.eval(
                _RATE,
                len(keys),
                *(self.prefix + key for key in keys),
                secrets.token_hex(16),
                *limits,
            )
        )

    async def close(self):
        # The session store owns this shared Redis connection pool.
        return None
