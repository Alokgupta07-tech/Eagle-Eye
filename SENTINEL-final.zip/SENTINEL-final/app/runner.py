"""Batch test runner — the judged artifact. Iterates the validated corpus (seeds +
surviving mutations), drives each attack through the request gate, fires survivors at the
target, analyzes every response (P5: response path runs even when request ALLOWs),
seals every decision to the audit chain, aggregates counters."""

from __future__ import annotations

import asyncio
import time
from copy import deepcopy

from . import mocktarget
from .corpus import payload_parts
from .operations import JobLeaseLost
from .target_client import call_target
from .textnorm import canonical_json, request_inspection_text, sha256_hex


async def run_batch(
    deps,
    run_id: str,
    target: dict,
    categories=None,
    limit: int | None = None,
    progress=None,
    enforce_request_block: bool | None = None,
    guard=None,
    pattern_manifest: list[dict] | None = None,
    baseline_snapshot=...,
) -> dict:
    """enforce_request_block (v2.4 step 7): False (batch default) = the request gate
    REPORTS but does not enforce, so every attack reaches the target and the target's own
    resistance is measured; True = any request BLOCK prevents the whole pattern's
    dispatch. This is a batch preflight, not an interactive REVIEW approval lease."""
    store, engine, audit, s = deps.store, deps.engine, deps.audit, deps.settings
    run_row = await store.get_run(run_id) or {}
    if enforce_request_block is None:
        enforce_request_block = run_row.get("gate_policy") == "enforcing"
    gate_policy = "enforcing" if enforce_request_block else "permissive"
    await store._write(
        "UPDATE test_runs SET gate_policy=? WHERE id=?", (gate_policy, run_id)
    )
    baseline = (
        await store.latest_baseline(target["id"])
        if baseline_snapshot is ...
        else baseline_snapshot
    )
    patterns = await store.list_patterns(
        statuses=("validated",), categories=categories, limit=limit
    )
    if pattern_manifest is not None:
        selected = {pattern["id"]: pattern for pattern in patterns}
        if any(
            item["id"] not in selected
            or selected[item["id"]]["payload_hash"] != item["hash"]
            for item in pattern_manifest
        ):
            raise ValueError("assessment corpus changed after enqueue")
        patterns = [selected[item["id"]] for item in pattern_manifest]
    # mutation families: seed id -> {seed, all variants}; used to exclude an attack's
    # own family from the similarity layer (v2.4 step 2 — no self-match inflation)
    families: dict[str, set[str]] = {}
    for q in await store.list_patterns(statuses=None):
        root = q.get("parent_id") or q["id"]
        families.setdefault(root, set()).update({q["id"], root})
    sys_prompt = (
        mocktarget.system_prompt(s)
        if target["endpoint_url"].startswith("internal://mock")
        else None
    )

    for i, p in enumerate(patterns):
        if guard:
            await guard()
        if await deps.operations.execution_done(run_id, p["id"]):
            continue
        counters = {"total": 1}
        t0 = time.perf_counter()
        sid = f"run-{run_id}-{i}"
        parts = payload_parts(p["payload"]) or [p["payload"]]
        tools = p.get("tools") or None
        inspections = [request_inspection_text(part, tools) for part in parts]

        # --- request gate (session-aware: parts accumulate in the window) ---
        family = families.get(p.get("parent_id") or p["id"], {p["id"]})

        async def inspect_parts():
            results = []
            for part in inspections:
                if guard:
                    await guard()
                results.append(
                    await engine.inspect_request(
                        part,
                        session_id=sid,
                        exclude_pattern_ids=family,
                        baseline=baseline,
                        target_id=target["id"],
                    )
                )
            return results

        fingerprint = sha256_hex(
            canonical_json(
                {
                    "payload": p["payload"],
                    **({"tools": tools} if tools else {}),
                    "baseline": baseline,
                    "request_policy": s.FUSION_W,
                    "response_policy": s.FUSION_RESPONSE_W,
                }
            )
        )
        request_results = await deps.operations.once(
            run_id, p["id"] + ":request", fingerprint, inspect_parts, guard
        )
        # A late benign fragment cannot erase an earlier preflight BLOCK.
        req = max(
            request_results,
            key=lambda result: (
                {"ALLOW": 0, "REVIEW": 1, "BLOCK": 2}[result["band"]],
                result["fused"],
            ),
        )
        window_used = any(
            result.get("session_window_used", False) for result in request_results
        )
        request_turns = [
            {"turn": turn, "band": result["band"], "fused": result["fused"]}
            for turn, result in enumerate(request_results, 1)
        ]

        verdict, action = None, "NONE"
        response_turns = []
        would_block = req["band"] == "BLOCK"
        if would_block:
            # counted + alerted in BOTH policies; only enforced when enforcing
            counters["blocked"] = 1
            await store.add_alert(
                None,
                run_id,
                p.get("severity", "medium"),
                (
                    f"Blocked at request gate: {p['category']}"
                    if enforce_request_block
                    else f"Request gate would block: {p['category']} (permissive run)"
                ),
                {
                    "pattern_id": p["id"],
                    "fused": req["fused"],
                    "enforced": enforce_request_block,
                },
            )
        if would_block and enforce_request_block:
            action = "BLOCK"
            resp_text, rres = None, None
        else:
            # --- fire at target ---
            resp_text = ""
            try:
                conversation_history = (
                    [{"role": "system", "content": sys_prompt}] if sys_prompt else []
                )
                rres = None
                for turn, part in enumerate(parts, 1):
                    conversation_history.append({"role": "user", "content": part})

                    async def dispatch():
                        reply = await call_target(
                            target,
                            deepcopy(conversation_history),
                            sid,
                            s,
                            **({"tools": tools} if tools else {}),
                        )
                        return {
                            "text": str(reply),
                            "tool_calls": getattr(reply, "tool_calls", []),
                        }

                    wire_hash = sha256_hex(
                        canonical_json(
                            {
                                "messages": conversation_history,
                                "endpoint": target["endpoint_url"],
                                **({"tools": tools} if tools else {}),
                            }
                        )
                    )
                    receipt = await deps.operations.once(
                        run_id, f"{p['id']}:target:{turn}", wire_hash, dispatch, guard
                    )
                    raw_response = receipt["text"]
                    conversation_history.append(
                        {"role": "assistant", "content": raw_response}
                    )

                    async def inspect_reply():
                        return await engine.inspect_response(
                            pattern=p,
                            request_text="\n".join(inspections[:turn]),
                            response_text=raw_response,
                            target=target,
                            baseline=baseline,
                            session_id=sid,
                        )

                    turn_result = await deps.operations.once(
                        run_id,
                        f"{p['id']}:response:{turn}",
                        sha256_hex(fingerprint + raw_response),
                        inspect_reply,
                        guard,
                    )
                    response_turns.append(
                        {
                            "turn": turn,
                            "verdict": turn_result["verdict"],
                            "action": turn_result["action"],
                            "drift": turn_result.get("session_drift"),
                            "risk_score": turn_result["risk_score"],
                        }
                    )
                    # Never lose an early leak just because a later turn refuses.
                    if (
                        rres is None
                        or rres["verdict"] != "SUCCESSFUL"
                        or (
                            turn_result["verdict"] == "SUCCESSFUL"
                            and turn_result["risk_score"] >= rres["risk_score"]
                        )
                    ):
                        rres, resp_text = turn_result, raw_response
            except (JobLeaseLost, asyncio.CancelledError):
                raise
            except (
                Exception
            ) as exc:  # an unavailable target cannot erase earlier evidence
                error = exc.__class__.__name__
                response_turns.append(
                    {
                        "turn": len(response_turns) + 1,
                        "error": error,
                        "verdict": "INCONCLUSIVE",
                        "action": "BLOCK",
                    }
                )
                if rres is None or rres["verdict"] != "SUCCESSFUL":
                    resp_text = ""
                    rres = {
                        "verdict": "INCONCLUSIVE",
                        "action": "BLOCK",
                        "sanitized": None,
                        "matches": [],
                        "success_hits": [],
                        "failure_hits": [],
                        "drift_score": None,
                        "drift_flag": False,
                        "jury": None,
                        "risk_score": None,
                        "confidence": None,
                        "ms": {},
                    }
                rres["error"] = error
            verdict, action = rres["verdict"], rres["action"]
            c = {
                "RESISTED": "resisted",
                "SUCCESSFUL": "successful",
                "INCONCLUSIVE": "inconclusive",
            }.get(verdict, "inconclusive")
            kw = {c: 1}
            if action == "REDACT":
                kw["redacted"] = 1
            counters.update(kw)
            if verdict == "SUCCESSFUL":
                await store.add_alert(
                    None,
                    run_id,
                    p.get("severity", "high"),
                    f"{p['category']} SUCCEEDED vs {target['name']}",
                    {
                        "pattern_id": p["id"],
                        "action": action,
                        "drift": rres["drift_score"],
                    },
                )
        if guard:
            await guard()

        seq = await audit.seal(
            {
                "run_id": run_id,
                "session_id": sid,
                "mode": "batch",
                "pattern_id": p["id"],
                "category": p["category"],
                "request_payload": request_inspection_text(p["payload"], tools)[:500],
                "tool_count": len(tools or []),
                "tool_definitions_hash": sha256_hex(canonical_json(tools))
                if tools
                else None,
                "response_payload": (resp_text or "")[:500],
                "layer_scores": req["scores"],
                "fused_score": req["fused"],
                "confidence": req["confidence"],
                "band": req["band"],
                "rule_hits": [h["name"] for h in req["details"].get("rule_hits", [])],
                "session_window_used": window_used,
                "semantic_drift": req.get("semantic_drift"),
                "request_turns": request_turns,
                "response_turns": response_turns,
                "error": (rres or {}).get("error"),
                "gate_policy": gate_policy,
                "would_block": would_block,
                "verdict": verdict,
                "action": action,
                "drift_score": rres["drift_score"] if rres else None,
                "response_risk": (rres or {}).get("risk_score"),
                "response_confidence": (rres or {}).get("confidence"),
                "derived_severity": (rres or {}).get("derived_severity"),
                "source_severity": p.get("severity"),
                "jury": (rres or {}).get("jury") or req.get("jury"),
                "latency_ms": int((time.perf_counter() - t0) * 1000),
            }
        )

        execution = dict(
            variant_text=request_inspection_text(p["payload"], tools)[:600],
            request_scores={
                **req["scores"],
                "fused": req["fused"],
                "turns": request_turns,
                "window": window_used,
                "semantic_drift": req.get("semantic_drift"),
                "would_block": would_block,
                "enforced": enforce_request_block,
                "known_corpus_match": req["details"].get("known_corpus_match"),
                "rule_hits": [h["name"] for h in req["details"].get("rule_hits", [])],
            },
            response_excerpt=(rres.get("sanitized") or "[RESPONSE BLOCKED]")[:600]
            if rres
            else None,
            response_scores=(
                {
                    "verdict": rres["verdict"],
                    "action": rres["action"],
                    "leaks": len(rres["matches"]),
                    "success_hits": rres["success_hits"],
                    "failure_hits": rres["failure_hits"],
                    "turns": response_turns,
                    "error": rres.get("error"),
                }
                if rres
                else None
            ),
            drift_score=rres["drift_score"] if rres else None,
            response_risk=(rres or {}).get("risk_score"),
            response_confidence=(rres or {}).get("confidence"),
            derived_severity=(rres or {}).get("derived_severity"),
            source_severity=p.get("severity"),
            jury=(rres or {}).get("jury") or req.get("jury"),
            fused_score=req["fused"],
            confidence=req["confidence"],
            band=req["band"],
            verdict=verdict or "BLOCKED",
            action=action,
            latency_ms=int((time.perf_counter() - t0) * 1000),
            audit_seq=seq,
        )
        if guard:
            await guard()
        await deps.operations.commit_execution(run_id, p["id"], execution, counters)
        if progress:
            progress(i + 1, len(patterns))

    if guard:
        await guard()
    await store.finish_run(run_id)
    return await store.get_run(run_id)
