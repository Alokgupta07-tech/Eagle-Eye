"""Bounded-label operational metrics. No prompts, subjects, tokens or raw URLs."""

from prometheus_client import (
    CollectorRegistry,
    Counter,
    Gauge,
    Histogram,
    ProcessCollector,
    generate_latest,
)


class Telemetry:
    def __init__(self):
        self.registry = CollectorRegistry()
        ProcessCollector(registry=self.registry)
        self.requests = Counter(
            "sentinel_http_requests_total",
            "HTTP responses",
            ["method", "route", "status"],
            registry=self.registry,
        )
        self.http_seconds = Histogram(
            "sentinel_http_seconds",
            "Whole HTTP response duration (includes SSE)",
            ["method", "route"],
            buckets=(0.01, 0.05, 0.1, 0.25, 0.5, 1, 2, 5, 10, 30, 60, 180),
            registry=self.registry,
        )
        self.decisions = Counter(
            "sentinel_decisions_total",
            "Inspected request dispositions",
            ["band", "action"],
            registry=self.registry,
        )
        self.failures = Counter(
            "sentinel_failures_total",
            "Operational failures (exception class only)",
            ["component", "kind"],
            registry=self.registry,
        )
        self.jobs = Counter(
            "sentinel_jobs_total",
            "Worker job outcomes",
            ["kind", "status"],
            registry=self.registry,
        )
        self.job_seconds = Histogram(
            "sentinel_job_seconds",
            "Durable job processing duration",
            ["kind"],
            buckets=(1, 5, 15, 30, 60, 120, 300, 900, 3600),
            registry=self.registry,
        )
        self.queue_depth = Gauge(
            "sentinel_queue_jobs",
            "Database-wide jobs (do not sum across API replicas)",
            ["status"],
            registry=self.registry,
        )
        self.workers = Gauge(
            "sentinel_active_workers",
            "Database-wide live workers",
            registry=self.registry,
        )
        self.cache_bytes = Gauge(
            "sentinel_memory_session_bytes",
            "In-process session window bytes",
            registry=self.registry,
        )

    def render(self, queue, cache):
        for status in ("pending", "running", "completed", "failed", "indeterminate"):
            self.queue_depth.labels(status).set(queue["jobs"].get(status, 0))
        self.workers.set(queue["active_workers"])
        self.cache_bytes.set(getattr(cache, "bytes_used", 0))
        return generate_latest(self.registry)
