"""OIDC access-token verification, server-side browser SSO and least-privilege roles.

Authorization Code + PKCE keeps tokens out of URLs and browser storage. Sessions
contain encrypted access tokens in shared Redis; the cookie is an opaque random
identifier. Bearer API clients use the same issuer/audience/role checks.
"""

from __future__ import annotations

import asyncio
import base64
import hashlib
import json
import math
import secrets
import time
from contextvars import ContextVar
from dataclasses import dataclass
from urllib.parse import urlencode, urlsplit

import httpx
import jwt
from fastapi import APIRouter, Depends, HTTPException, Request
from fastapi.responses import JSONResponse, RedirectResponse

from .coordination import key_for
from .secrets import protect, reveal

ROLE_PERMISSIONS = {
    "viewer": frozenset({"reports:read", "targets:read", "policy:read"}),
    "analyst": frozenset(
        {
            "reports:read",
            "targets:read",
            "policy:read",
            "proxy:chat",
            "runs:write",
            "quarantine:resolve",
            "feedback:write",
        }
    ),
    "admin": frozenset(
        {
            "reports:read",
            "targets:read",
            "policy:read",
            "proxy:chat",
            "runs:write",
            "quarantine:resolve",
            "feedback:write",
            "targets:write",
            "policy:write",
            "operations:read",
        }
    ),
    "service": frozenset({"proxy:chat"}),
    "monitor": frozenset({"operations:read"}),
}
actor_context: ContextVar[dict | None] = ContextVar("sentinel_actor", default=None)


@dataclass(frozen=True)
class Principal:
    subject: str
    issuer: str
    roles: frozenset[str]
    method: str

    @property
    def permissions(self):
        return frozenset().union(
            *(ROLE_PERMISSIONS.get(role, frozenset()) for role in self.roles)
        )

    @property
    def identity_key(self):
        return hashlib.sha256(
            json.dumps([self.issuer, self.subject]).encode()
        ).hexdigest()

    def audit_actor(self):
        return {
            "subject": self.subject,
            "issuer": self.issuer,
            "roles": sorted(self.roles),
            "method": self.method,
        }


def attach_principal(request, principal):
    request.state.principal = principal
    actor_context.set(principal.audit_actor())
    return principal


def equal(left, right):
    try:
        return (
            isinstance(left, str)
            and isinstance(right, str)
            and secrets.compare_digest(left.encode(), right.encode())
        )
    except UnicodeError:
        return False


def anonymous():
    return Principal("anonymous-demo", "sentinel", frozenset({"service"}), "anonymous")


def _claim(data, path):
    if path in data:
        return data[path]
    for component in path.split("."):
        if not isinstance(data, dict):
            return None
        data = data.get(component)
    return data


class Identity:
    def __init__(self, settings, coordination):
        self.s, self.coordination = settings, coordination
        self.client = httpx.AsyncClient(
            timeout=10, follow_redirects=False, trust_env=False
        )
        self.metadata = {}
        self.keys = {}
        self.keys_updated = 0.0
        self.lock = asyncio.Lock()

    def trusted_url(self, value):
        parts = urlsplit(value)
        if (
            not parts.hostname
            or parts.username
            or parts.password
            or parts.fragment
            or parts.scheme
            not in ({"https"} if self.s.PRODUCTION else {"http", "https"})
        ):
            raise ValueError("invalid identity-provider endpoint")
        return value

    async def _json(self, method, url, **kwargs):
        async with asyncio.timeout(12):
            async with self.client.stream(
                method, self.trusted_url(url), **kwargs
            ) as response:
                response.raise_for_status()
                content = bytearray()
                async for part in response.aiter_bytes():
                    content.extend(part)
                    if len(content) > 256 * 1024:
                        raise ValueError("identity response too large")
                data = json.loads(content)
                if not isinstance(data, dict):
                    raise ValueError("invalid identity response")
                return data

    async def start(self):
        if self.s.AUTH_MODE != "oidc":
            return
        metadata = await self._json(
            "GET", self.s.OIDC_ISSUER.rstrip("/") + "/.well-known/openid-configuration"
        )
        if metadata.get("issuer") != self.s.OIDC_ISSUER:
            raise ValueError("OIDC discovery issuer mismatch")
        self.trusted_url(metadata["jwks_uri"])
        if self.s.OIDC_CLIENT_ID:
            self.trusted_url(metadata["authorization_endpoint"])
            self.trusted_url(metadata["token_endpoint"])
            if "S256" not in metadata.get("code_challenge_methods_supported", []):
                raise ValueError("Identity provider must support PKCE S256")
        self.metadata = metadata
        await self.refresh_keys()

    async def refresh_keys(self):
        async with self.lock:
            now = time.monotonic()
            # Unknown kids cannot force an unbounded stream of network lookups.
            if self.keys and now - self.keys_updated < 30:
                return
            data = await self._json("GET", self.metadata["jwks_uri"])
            keys = data.get("keys")
            if not isinstance(keys, list) or not 1 <= len(keys) <= 64:
                raise ValueError("invalid JWKS")
            accepted = {}
            for item in keys:
                if not isinstance(item, dict) or item.get("use", "sig") != "sig":
                    continue
                if item.get("kty") not in {"RSA", "EC"} or any(
                    name in item for name in ("d", "p", "q")
                ):
                    continue
                kid = item.get("kid")
                if (
                    not isinstance(kid, str)
                    or not kid
                    or len(kid) > 256
                    or kid in accepted
                ):
                    raise ValueError("JWKS requires unique key identifiers")
                accepted[kid] = item
            if not accepted:
                raise ValueError("JWKS has no supported public signing key")
            self.keys, self.keys_updated = accepted, now

    async def decode(self, token, audience):
        if not isinstance(token, str) or not 1 <= len(token) <= 16384:
            raise ValueError("invalid token size")
        header = jwt.get_unverified_header(token)
        algorithm, kid = header.get("alg"), header.get("kid")
        if (
            algorithm not in {"RS256", "ES256"}
            or not isinstance(kid, str)
            or len(kid) > 256
        ):
            raise ValueError("unsupported signing algorithm or key")
        if (
            kid not in self.keys
            or time.monotonic() - self.keys_updated > self.s.OIDC_JWKS_TTL_S
        ):
            await self.refresh_keys()
        raw_key = self.keys.get(kid)
        if not raw_key or raw_key.get("alg", algorithm) != algorithm:
            raise ValueError("unknown signing key")
        key = jwt.PyJWK.from_dict(raw_key, algorithm=algorithm).key
        if algorithm == "RS256" and key.key_size < 2048:
            raise ValueError("RSA signing keys must be at least 2048 bits")
        if algorithm == "ES256" and key.curve.name != "secp256r1":
            raise ValueError("ES256 requires P-256")
        claims = jwt.decode(
            token,
            key,
            algorithms=[algorithm],
            audience=audience,
            issuer=self.s.OIDC_ISSUER,
            leeway=self.s.OIDC_CLOCK_SKEW_S,
            options={"require": ["iss", "sub", "aud", "exp", "iat"]},
        )
        for name in ("iat", "exp", "nbf"):
            value = claims.get(name)
            if value is not None and (
                isinstance(value, bool)
                or not isinstance(value, (int, float))
                or not math.isfinite(value)
            ):
                raise ValueError("invalid token clock")
        if (
            claims["exp"] <= claims["iat"]
            or claims["exp"] - claims["iat"] > self.s.OIDC_MAX_TOKEN_LIFETIME_S
        ):
            raise ValueError("invalid token lifetime")
        if not isinstance(claims["sub"], str) or not 1 <= len(claims["sub"]) <= 256:
            raise ValueError("invalid subject")
        return claims

    async def principal(self, token):
        claims = await self.decode(token, self.s.OIDC_AUDIENCE)
        roles = _claim(claims, self.s.OIDC_ROLES_CLAIM) or []
        if (
            not isinstance(roles, list)
            or len(roles) > 100
            or not all(isinstance(role, str) for role in roles)
        ):
            raise ValueError("invalid roles claim")
        return Principal(
            claims["sub"],
            claims["iss"],
            frozenset(roles) & ROLE_PERMISSIONS.keys(),
            "oidc",
        )

    async def authenticate(self, request):
        authorization = request.headers.get("authorization", "")
        try:
            if authorization:
                scheme, separator, token = authorization.partition(" ")
                if not separator or scheme.lower() != "bearer":
                    raise ValueError("bearer token required")
                return attach_principal(request, await self.principal(token))
            sid = request.cookies.get("sentinel_session")
            if not sid or len(sid) > 128:
                raise ValueError("no browser session")
            session = await self.coordination.get(key_for("oidc-session", sid))
            if not session:
                raise ValueError("expired browser session")
            session = json.loads(reveal(session["sealed"], self.s.SENTINEL_SECRET))
            if not equal(session["sid"], sid):
                raise ValueError("browser session binding mismatch")
            if request.method not in {"GET", "HEAD", "OPTIONS"}:
                expected_origin = self.s.OIDC_REDIRECT_URI.rsplit("/auth/callback", 1)[
                    0
                ]
                if request.headers.get("origin") != expected_origin or not equal(
                    request.headers.get("x-csrf-token", ""), session["csrf"]
                ):
                    raise HTTPException(
                        status_code=403, detail="invalid origin or CSRF token"
                    )
            token = session["token"]
            principal = await self.principal(token)
            request.state.csrf = session["csrf"]
            return attach_principal(request, principal)
        except HTTPException:
            raise
        except (ValueError, jwt.PyJWTError):
            raise HTTPException(
                status_code=401,
                detail="invalid or expired identity token",
                headers={"WWW-Authenticate": "Bearer"},
            ) from None
        except Exception:
            raise HTTPException(
                status_code=503, detail="identity service unavailable"
            ) from None

    async def close(self):
        await self.client.aclose()


def build_auth_router():
    from .deps import rate_limited

    router = APIRouter()

    @router.get("/auth/config")
    async def config(request: Request):
        s = request.app.state.deps.settings
        return {
            "mode": s.AUTH_MODE,
            "browser_sso": bool(s.AUTH_MODE == "oidc" and s.OIDC_CLIENT_ID),
            "login_url": "/auth/login",
            "production": s.PRODUCTION,
        }

    @router.get("/auth/me")
    async def me(request: Request):
        from .deps import require_admin

        d = request.app.state.deps
        if d.settings.AUTH_MODE == "oidc":
            user = await d.identity.authenticate(request)
        else:
            user = await require_admin(
                request, request.headers.get("x-sentinel-admin-key")
            )
        return {
            "subject": user.subject,
            "roles": sorted(user.roles),
            "permissions": sorted(user.permissions),
            "csrf_token": getattr(request.state, "csrf", None),
        }

    @router.get("/auth/login", dependencies=[Depends(rate_limited("login", 20))])
    async def login(request: Request, return_to: str = "/"):
        d, s = request.app.state.deps, request.app.state.deps.settings
        if s.AUTH_MODE != "oidc" or not s.OIDC_CLIENT_ID:
            raise HTTPException(status_code=404, detail="Browser SSO is not configured")
        destination = urlsplit(return_to)
        if (
            len(return_to) > 2048
            or destination.scheme
            or destination.netloc
            or destination.path not in {"/", "/report.html"}
        ):
            raise HTTPException(status_code=400, detail="invalid return location")
        state, verifier, nonce, binding = (secrets.token_urlsafe(32) for _ in range(4))
        challenge = (
            base64.urlsafe_b64encode(hashlib.sha256(verifier.encode()).digest())
            .decode()
            .rstrip("=")
        )
        sealed = protect(
            json.dumps(
                {
                    "state": state,
                    "verifier": verifier,
                    "nonce": nonce,
                    "binding": binding,
                    "return_to": return_to,
                }
            ),
            s.SENTINEL_SECRET,
            s.SENTINEL_SALT,
        )
        await d.coordination.set(key_for("oidc-state", state), {"sealed": sealed}, 300)
        query = urlencode(
            {
                **s.OIDC_AUTHORIZATION_PARAMS,
                "response_type": "code",
                "client_id": s.OIDC_CLIENT_ID,
                "redirect_uri": s.OIDC_REDIRECT_URI,
                "scope": s.OIDC_SCOPES,
                "state": state,
                "nonce": nonce,
                "code_challenge": challenge,
                "code_challenge_method": "S256",
            }
        )
        response = RedirectResponse(
            d.identity.metadata["authorization_endpoint"] + "?" + query, status_code=302
        )
        response.set_cookie(
            "sentinel_login",
            binding,
            max_age=300,
            httponly=True,
            secure=s.OIDC_REDIRECT_URI.startswith("https:"),
            samesite="lax",
            path="/auth",
        )
        return response

    @router.get(
        "/auth/callback", dependencies=[Depends(rate_limited("login-callback", 20))]
    )
    async def callback(request: Request, state: str = "", code: str = ""):
        d, s = request.app.state.deps, request.app.state.deps.settings
        if s.AUTH_MODE != "oidc" or not s.OIDC_CLIENT_ID:
            raise HTTPException(status_code=404, detail="Browser SSO is not configured")
        if not state or len(state) > 128 or not code or len(code) > 4096:
            raise HTTPException(
                status_code=400, detail="invalid authorization response"
            )
        saved = await d.coordination.take(key_for("oidc-state", state))
        try:
            saved = (
                json.loads(reveal(saved["sealed"], s.SENTINEL_SECRET))
                if saved
                else None
            )
        except Exception:
            saved = None
        if (
            not saved
            or not equal(saved["state"], state)
            or not equal(saved["binding"], request.cookies.get("sentinel_login", ""))
        ):
            raise HTTPException(
                status_code=400, detail="invalid or expired login state"
            )
        try:
            params = {
                "grant_type": "authorization_code",
                "client_id": s.OIDC_CLIENT_ID,
                "code": code,
                "redirect_uri": s.OIDC_REDIRECT_URI,
                "code_verifier": saved["verifier"],
            }
            authentication = (
                httpx.BasicAuth(s.OIDC_CLIENT_ID, s.OIDC_CLIENT_SECRET)
                if s.OIDC_CLIENT_SECRET
                else None
            )
            tokens = await d.identity._json(
                "POST",
                d.identity.metadata["token_endpoint"],
                data=params,
                auth=authentication,
            )
            identity = await d.identity.decode(tokens["id_token"], s.OIDC_CLIENT_ID)
            if not isinstance(identity.get("nonce"), str) or not equal(
                identity["nonce"], saved["nonce"]
            ):
                raise ValueError("nonce mismatch")
            user = await d.identity.principal(tokens["access_token"])
            if user.subject != identity["sub"]:
                raise ValueError("token subjects differ")
            claims = await d.identity.decode(tokens["access_token"], s.OIDC_AUDIENCE)
            ttl = min(s.OIDC_SESSION_TTL_S, int(claims["exp"] - time.time()))
            if ttl <= 0:
                raise ValueError("expired access token")
        except Exception:
            raise HTTPException(
                status_code=401, detail="identity exchange failed"
            ) from None
        # Session fixation defense: replace (and revoke) any pre-login session.
        old = request.cookies.get("sentinel_session")
        if old and len(old) <= 128:
            await d.coordination.take(key_for("oidc-session", old))
        sid = secrets.token_urlsafe(32)
        session = json.dumps(
            {
                "sid": sid,
                "token": tokens["access_token"],
                "csrf": secrets.token_urlsafe(32),
            }
        )
        await d.coordination.set(
            key_for("oidc-session", sid),
            {"sealed": protect(session, s.SENTINEL_SECRET, s.SENTINEL_SALT)},
            ttl,
        )
        response = RedirectResponse(saved["return_to"], status_code=303)
        response.set_cookie(
            "sentinel_session",
            sid,
            max_age=ttl,
            httponly=True,
            secure=s.OIDC_REDIRECT_URI.startswith("https:"),
            samesite="lax",
            path="/",
        )
        response.delete_cookie("sentinel_login", path="/auth")
        actor_context.set(user.audit_actor())
        await d.audit.seal({"type": "login"})
        return response

    @router.post("/auth/logout")
    async def logout(request: Request):
        d = request.app.state.deps
        if d.settings.AUTH_MODE != "oidc":
            raise HTTPException(status_code=404, detail="Browser SSO is not configured")
        await d.identity.authenticate(request)
        sid = request.cookies.get("sentinel_session")
        if sid:
            await d.coordination.take(key_for("oidc-session", sid))
        await d.audit.seal({"type": "logout"})
        response = JSONResponse({"ok": True})
        response.delete_cookie("sentinel_session", path="/")
        return response

    return router
