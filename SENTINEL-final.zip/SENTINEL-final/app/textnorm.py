"""Text normalization + obfuscation decode chain + canonical hashing helpers."""
from __future__ import annotations

import base64
import binascii
import hashlib
import json
import re
import unicodedata

# --- small homoglyph folding table (common Cyrillic/Greek lookalikes) ---
HOMOGLYPHS = str.maketrans({
    "\u0430": "a", "\u0435": "e", "\u043e": "o", "\u0440": "p", "\u0441": "c",
    "\u0443": "y", "\u0445": "x", "\u0456": "i", "\u0458": "j", "\u0455": "s",
    "\u0501": "d", "\u04bb": "h", "\u03bd": "v", "\u03c1": "p", "\u03c4": "t",
    "\u043a": "k", "\u043c": "m", "\u0442": "t", "\u043d": "h", "\u0410": "A",
    "\u0412": "B", "\u0415": "E", "\u041a": "K", "\u041c": "M", "\u041d": "H",
    "\u041e": "O", "\u0420": "P", "\u0421": "C", "\u0422": "T", "\u0425": "X",
})

LEETSPEAK = str.maketrans({
    "4": "a", "@": "a", "3": "e", "1": "i", "!": "i", "0": "o",
    "5": "s", "$": "s", "7": "t", "8": "b", "+": "t", "9": "g",
})

# Unicode format controls, combining grapheme joiner and invisible fillers.
# Include the ENTIRE Tags block, including unassigned code points, not only Cf.
_ZERO_WIDTH = re.compile(
    "[\u00ad\u034f\u061c\u115f\u1160\u17b4\u17b5\u180b-\u180f"
    "\u200b-\u200f\u202a-\u202e\u2060-\u206f\u3164\uffa0\ufe00-\ufe0f\ufeff"
    "\U000e0000-\U000e007f\U000e0100-\U000e01ef]")
_UNICODE_TAGS = re.compile("[\U000e0000-\U000e007f]")
_HIDDEN_MD = re.compile(r"<!--(.*?)-->|```[a-z]*\n?(.*?)```|\[\^\d+\]:\s*([^\n]+)", re.S)


def strip_zero_width(text: str) -> str:
    return "".join(c for c in _ZERO_WIDTH.sub("", text)
                   if unicodedata.category(c) != "Cf"
                   and (unicodedata.category(c) != "Cc" or c in "\n\r\t"))


def reveal_hidden_markup(text: str) -> str:
    """Pull instruction text out of HTML comments, code fences and footnotes so the
    rule/similarity layers see it inline (v2.4 step 9, markdown_hidden_instruction)."""
    found = [next((g for g in m.groups() if g), "") for m in _HIDDEN_MD.finditer(text)]
    return " ".join(f.strip() for f in found if f and f.strip())


_B64_RE = re.compile(r"[A-Za-z0-9+/_-]{16,}={0,2}")
_HEX_RE = re.compile(r"(?:0[xX])?[0-9a-fA-F]{16,}")
_ENCODED_TOKEN = re.compile(
    r"(?<![A-Za-z0-9+/_-])(?:0[xX][0-9a-fA-F]{16,}|[A-Za-z0-9+/_-]{16,}={0,2})"
    r"(?![A-Za-z0-9+/_=-])")
_KEYWORDS = ("ignore", "system", "prompt", "bypass", "token", "reveal", "override",
             "instructions", "instruction", "previous", "disregard", "developer",
             "credentials", "password", "secrets")


def _signature(word: str) -> tuple:
    return (len(word), word[0], word[-1], "".join(sorted(word[1:-1])))


_TYPO_SIGNATURES = {_signature(word): word for word in _KEYWORDS}


def fold_typoglycemia(text: str) -> str:
    """Fold only exact interior anagrams with unchanged first/last letters.

    This intentionally avoids broad edit-distance matching that would rewrite
    ordinary vocabulary. Case and surrounding punctuation remain intact.
    """
    def replace(match):
        word = match.group(0)
        canonical = _TYPO_SIGNATURES.get(_signature(word.lower()))
        if canonical is None or canonical == word.lower():
            return word
        return canonical.upper() if word.isupper() else (
            canonical.capitalize() if word.istitle() else canonical)
    return re.sub(r"\b[A-Za-z]{5,12}\b", replace, text)


def _mostly_printable(text: str) -> bool:
    return bool(text) and sum(c.isprintable() or c.isspace() for c in text) / len(text) >= 0.9


def _try_token_decodes(text: str) -> tuple[str, list[str]]:
    """Decode punctuation/newline-delimited hex and standard/URL-safe base64.

    Substitution preserves exact surrounding punctuation. Hex is tried first
    because its alphabet is a subset of base64. Unpadded base64 is supported.
    """
    notes: list[str] = []

    def replace(match):
        token = match.group(0)
        candidates = []
        if _HEX_RE.fullmatch(token):
            raw = token[2:] if token.lower().startswith("0x") else token
            if len(raw) % 2 == 0:
                candidates.append(("hex", lambda: bytes.fromhex(raw)))
        if _B64_RE.fullmatch(token) and len(token.rstrip("=")) % 4 != 1:
            candidates.append(("base64", lambda: base64.b64decode(
                token + "=" * (-len(token) % 4), altchars=b"-_", validate=True)))
        for kind, decode in candidates:
            try:
                decoded = decode().decode("utf-8", "strict")
            except (binascii.Error, UnicodeDecodeError, ValueError):
                continue
            clean = strip_zero_width(decoded)
            if _mostly_printable(decoded) or _mostly_printable(clean) or not clean:
                notes.append(f"{kind}:{token[:18]}…")
                return decoded
        return token

    return _ENCODED_TOKEN.sub(replace, text), notes


def decode_chain(text: str) -> dict:
    """Full obfuscation pipeline. Token-level base64/hex decode happens BEFORE any
    leetspeak fold (folding digits would corrupt encoded blobs). Returns variants."""
    variants: dict[str, str] = {"original": text}
    transforms: list[str] = []

    if _UNICODE_TAGS.search(text):
        transforms.append("unicode_tags")
    nfkc = unicodedata.normalize("NFKC", text)
    if nfkc != text:
        transforms.append("nfkc")
        variants["nfkc"] = nfkc
    zw = strip_zero_width(nfkc)
    if zw != nfkc:
        transforms.append("zero_width")
        variants["zero_width"] = zw
        nfkc = zw
    hidden = reveal_hidden_markup(nfkc)
    if hidden and hidden != nfkc.strip():
        transforms.append("hidden_markup")
        variants["hidden_markup"] = hidden

    base = nfkc
    for _ in range(2):  # nested encodings: decode up to two rounds
        decoded, notes = _try_token_decodes(base)
        if decoded == base:
            break
        transforms.extend(notes)
        variants["decoded"] = decoded
        if _UNICODE_TAGS.search(decoded) and "unicode_tags" not in transforms:
            transforms.append("unicode_tags")
        base = strip_zero_width(unicodedata.normalize("NFKC", decoded))
        if base != decoded:
            transforms.append("decoded_format_controls")
            variants["decoded_clean"] = base

    homo = base.translate(HOMOGLYPHS)
    if homo != base:
        transforms.append("homoglyph")
        variants["homoglyph"] = homo

    typo = fold_typoglycemia(homo)
    if typo != homo:
        transforms.append("typoglycemia")
        variants["typoglycemia"] = typo
    leet = typo.translate(LEETSPEAK)
    if leet != typo:
        transforms.append("leetspeak")
        variants["leetspeak"] = leet

    final = fold_typoglycemia(leet)
    if final != leet:
        if "typoglycemia" not in transforms:
            transforms.append("typoglycemia")
        variants["typoglycemia_leet"] = final
    return {"variants": variants, "transforms": transforms}


def canonical_json(obj) -> str:
    return json.dumps(obj, sort_keys=True, separators=(",", ":"), default=str)


def sha256_hex(s: str) -> str:
    return hashlib.sha256(s.encode("utf-8")).hexdigest()


def payload_id(text: str) -> str:
    return hashlib.sha1(text.encode("utf-8")).hexdigest()
