"""Fail-closed endpoint validation and DNS pinning for administrator-created targets.

Validate every resolved address at registration AND immediately before dispatch.
The HTTP client connects to that validated IP, retaining the original Host and TLS
SNI, so a second DNS lookup cannot rebind the request into the private network.
Redirects and environment proxies are intentionally disabled by target_client.
"""
from __future__ import annotations

import asyncio
import ipaddress
import re
import socket
from dataclasses import dataclass
from urllib.parse import urlsplit

import httpx

INTERNAL_ENDPOINTS = frozenset({
    "internal://mock", "internal://mock-hardened", "internal://mock-rag",
    "internal://mock-rag-hardened", "internal://openai", "internal://anthropic",
})


class UnsafeEndpoint(ValueError):
    """The destination cannot be established as a public HTTP endpoint."""


@dataclass(frozen=True)
class Endpoint:
    url: str
    hostname: str
    addresses: tuple[str, ...]

    @property
    def pinned_url(self) -> httpx.URL:
        if not self.addresses:
            raise UnsafeEndpoint("internal endpoints do not have a network address")
        return httpx.URL(self.url).copy_with(host=self.addresses[0])

    @property
    def host_header(self) -> str:
        return httpx.URL(self.url).netloc.decode("ascii")


def _public_address(raw: str) -> str:
    try:
        address = ipaddress.ip_address(raw)
    except ValueError as exc:
        raise UnsafeEndpoint("endpoint resolved to an invalid address") from exc
    mapped = getattr(address, "ipv4_mapped", None)
    effective = mapped or address
    if (not effective.is_global or effective.is_multicast or effective.is_reserved
            or getattr(address, "sixtofour", None) or getattr(address, "teredo", None)
            or address in ipaddress.ip_network("64:ff9b::/96")
            or address in ipaddress.ip_network("64:ff9b:1::/48")):
        raise UnsafeEndpoint("private, loopback, link-local, reserved and metadata destinations are blocked")
    return address.compressed


async def resolve_host(hostname: str, port: int) -> list[str]:
    try:
        records = await asyncio.wait_for(
            asyncio.get_running_loop().getaddrinfo(hostname, port, type=socket.SOCK_STREAM),
            timeout=5.0)
    except (OSError, TimeoutError) as exc:
        raise UnsafeEndpoint("endpoint hostname could not be resolved safely") from exc
    return [record[4][0] for record in records]


async def validate_endpoint_url(url: str) -> Endpoint:
    if url in INTERNAL_ENDPOINTS:
        return Endpoint(url, "", ())
    if (len(url) > 2048 or re.search(r"[\x00-\x20\x7f\\]", url)
            or not url.startswith(("https://", "http://"))):
        raise UnsafeEndpoint("endpoint must be an explicit http(s) URL or a supported internal target")
    try:
        parsed = urlsplit(url)
        if not parsed.hostname or parsed.username is not None or parsed.password is not None:
            raise ValueError("userinfo or missing host")
        if parsed.fragment or "%" in parsed.netloc:
            raise ValueError("fragment, zone identifier or encoded host")
        hostname = parsed.hostname.rstrip(".").encode("idna").decode("ascii").lower()
        port = parsed.port if parsed.port is not None else (443 if parsed.scheme == "https" else 80)
        if not 1 <= port <= 65535:
            raise ValueError("invalid port")
        httpx.URL(url)  # ensure the HTTP client's parser agrees with our parser
    except (ValueError, UnicodeError, httpx.InvalidURL) as exc:
        raise UnsafeEndpoint("invalid endpoint URL; credentials, fragments and encoded hosts are forbidden") from exc
    if hostname == "localhost" or hostname.endswith((".localhost", ".local", ".internal")):
        raise UnsafeEndpoint("local hostnames are blocked")
    try:
        literal = ipaddress.ip_address(hostname)
    except ValueError:
        raw_addresses = await resolve_host(hostname, port)
    else:
        raw_addresses = [str(literal)]
    addresses = tuple(dict.fromkeys(_public_address(address) for address in raw_addresses))
    if not addresses:
        raise UnsafeEndpoint("endpoint hostname has no usable addresses")
    # Normalizing the host eliminates IDNA and trailing-dot differences in SNI.
    normalized = str(httpx.URL(url).copy_with(host=hostname))
    return Endpoint(normalized, hostname, addresses)
