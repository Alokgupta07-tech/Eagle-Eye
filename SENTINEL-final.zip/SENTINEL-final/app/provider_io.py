"""One bounded, DNS-pinned JSON transport for paid model requests."""

from __future__ import annotations

import asyncio
import json
import math

import httpx

from .budget import active_budget
from .ssrf import validate_endpoint_url


class ProviderRateLimitError(RuntimeError):
    """Public-safe quota signal, without upstream URLs, response bodies or keys."""

    def __init__(self, retry_after=60):
        try:
            seconds = float(retry_after)
            self.retry_after = (
                max(1, min(3600, math.ceil(seconds))) if math.isfinite(seconds) else 60
            )
        except (ValueError, TypeError):
            self.retry_after = 60
        super().__init__(
            "Provider quota reached; wait before retrying. No fallback was used."
        )


def usage_from(data, provider):
    if provider == "google":
        raw = data.get("usageMetadata", {})
        return {
            "input_tokens": raw.get("promptTokenCount"),
            "output_tokens": raw.get("candidatesTokenCount"),
        }
    raw = data.get("usage", {})
    return {
        "input_tokens": raw.get("input_tokens", raw.get("prompt_tokens")),
        "output_tokens": raw.get("output_tokens", raw.get("completion_tokens")),
    }


async def model_json(
    url, headers, payload, *, provider, model, output_tokens, timeout=45
):
    budget = active_budget.get()
    ticket = (
        await budget.reserve(f"{provider}/{model}", payload, output_tokens)
        if budget
        else None
    )
    usage = None
    try:
        async with asyncio.timeout(timeout):
            endpoint = await validate_endpoint_url(url)
            headers = {
                **headers,
                "Host": endpoint.host_header,
                "Accept-Encoding": "identity",
            }
            async with httpx.AsyncClient(
                timeout=timeout, follow_redirects=False, trust_env=False
            ) as client:
                async with client.stream(
                    "POST",
                    endpoint.pinned_url,
                    json=payload,
                    headers=headers,
                    extensions={"sni_hostname": endpoint.hostname},
                ) as response:
                    if provider == "groq" and response.status_code == 429:
                        raise ProviderRateLimitError(
                            response.headers.get("retry-after", "60")
                        )
                    response.raise_for_status()
                    # Never decompress an untrusted zip bomb before enforcing a
                    # size limit. Providers are explicitly asked for identity.
                    if response.headers.get(
                        "content-encoding", "identity"
                    ).lower() not in {"", "identity"}:
                        raise ValueError("compressed provider response rejected")
                    body = bytearray()
                    if response.is_stream_consumed:
                        body.extend(response.content)
                    else:
                        async for part in response.aiter_raw():
                            if len(body) + len(part) > 2 * 1024 * 1024:
                                raise ValueError(
                                    "target response exceeds the 2 MiB inspection limit"
                                )
                            body.extend(part)
                    if len(body) > 2 * 1024 * 1024:
                        raise ValueError(
                            "target response exceeds the 2 MiB inspection limit"
                        )
                    data = json.loads(body)
                    if not isinstance(data, dict):
                        raise ValueError("provider response must be a JSON object")
                    usage = usage_from(data, provider)
                    return data
    finally:
        if budget and ticket:
            await budget.settle(ticket, usage)
