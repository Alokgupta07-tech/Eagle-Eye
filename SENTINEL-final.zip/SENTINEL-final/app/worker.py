"""Run the external durable worker: python -m app.worker."""

from __future__ import annotations

import asyncio
import signal

from .config import Settings
from .deps import Deps


async def main():
    deps = Deps(Settings(), role="worker")
    stopped = asyncio.Event()
    loop = asyncio.get_running_loop()
    for sig in (signal.SIGTERM, signal.SIGINT):
        loop.add_signal_handler(sig, stopped.set)
    try:
        await deps.start()
        print("SENTINEL durable worker ready", flush=True)
        await stopped.wait()
    finally:
        await deps.stop()


if __name__ == "__main__":
    asyncio.run(main())
