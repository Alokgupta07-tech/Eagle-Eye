"""Opt-in evaluation spending guard covering BOTH target and HTTP-jury calls.

Reservations use a conservative text-byte token estimate plus protocol allowance.
This is an application guard using operator-supplied prices, not a provider billing
limit. Configure provider-side spending limits as well. Unknown outcomes keep the
full reservation, and no request is retried automatically.
"""

from __future__ import annotations

import asyncio
import json
from contextvars import ContextVar
from decimal import Decimal, InvalidOperation

active_budget: ContextVar["Budget | FreeTierBudget | None"] = ContextVar(
    "sentinel_model_budget", default=None
)


class BudgetExceeded(Exception):
    """The request was stopped before provider dispatch."""


def money(value):
    try:
        result = Decimal(str(value))
    except InvalidOperation as exc:
        raise ValueError("invalid monetary value") from exc
    if not result.is_finite() or result < 0:
        raise ValueError("prices and budgets must be finite and nonnegative")
    return result


class Budget:
    def __init__(self, *, max_calls: int, max_tokens: int, max_usd, prices: dict):
        if max_calls < 1 or max_tokens < 1 or money(max_usd) <= 0:
            raise ValueError(
                "explicit positive call, token and cost limits are required"
            )
        self.max_calls, self.max_tokens, self.max_usd = (
            max_calls,
            max_tokens,
            money(max_usd),
        )
        self.prices = {}
        for model, value in prices.items():
            if not isinstance(value, dict) or set(value) != {
                "input_per_million",
                "output_per_million",
            }:
                raise ValueError(
                    "each model price needs input_per_million and output_per_million"
                )
            self.prices[model] = (
                money(value["input_per_million"]),
                money(value["output_per_million"]),
            )
        self.calls, self.tokens, self.charged = 0, 0, Decimal(0)
        self.receipts = []
        self.exhausted = False
        self.lock = asyncio.Lock()

    def require_models(self, models):
        missing = set(models) - self.prices.keys()
        if missing:
            raise ValueError(
                "Missing explicit prices for: " + ", ".join(sorted(missing))
            )

    async def reserve(self, model, payload, output_tokens):
        self.require_models([model])
        # Text/tools only: byte count deliberately overestimates common tokenizer
        # counts. The allowance also accounts for provider message framing.
        incoming = len(json.dumps(payload, ensure_ascii=False).encode()) + 4096
        tokens = incoming + output_tokens
        in_rate, out_rate = self.prices[model]
        cost = (incoming * in_rate + output_tokens * out_rate) / Decimal(1000000)
        async with self.lock:
            if (
                self.calls + 1 > self.max_calls
                or self.tokens + tokens > self.max_tokens
                or self.charged + cost > self.max_usd
            ):
                self.exhausted = True
                raise BudgetExceeded("evaluation budget exhausted before dispatch")
            self.calls += 1
            self.tokens += tokens
            self.charged += cost
            ticket = {
                "model": model,
                "reserved_tokens": tokens,
                "reserved_usd": cost,
                "status": "reserved",
                "input_tokens": None,
                "output_tokens": None,
            }
            self.receipts.append(ticket)
            return ticket

    async def settle(self, ticket, usage=None):
        async with self.lock:
            if ticket["status"] != "reserved":
                return
            if usage is None:
                ticket["status"] = "unknown_usage"
                return
            incoming, outgoing = usage.get("input_tokens"), usage.get("output_tokens")
            if any(
                isinstance(value, bool) or not isinstance(value, int) or value < 0
                for value in (incoming, outgoing)
            ):
                ticket["status"] = "unknown_usage"
                return
            in_rate, out_rate = self.prices[ticket["model"]]
            actual = (incoming * in_rate + outgoing * out_rate) / Decimal(1000000)
            self.tokens += incoming + outgoing - ticket["reserved_tokens"]
            self.charged += actual - ticket["reserved_usd"]
            ticket.update(
                status="reported_usage",
                input_tokens=incoming,
                output_tokens=outgoing,
                reported_usd=actual,
            )
            if self.tokens > self.max_tokens or self.charged > self.max_usd:
                ticket["status"] = "provider_usage_exceeded_reservation"

    def report(self):
        return {
            "calls": self.calls,
            "accounted_tokens": self.tokens,
            "accounted_usd": float(self.charged),
            "limits": {
                "calls": self.max_calls,
                "tokens": self.max_tokens,
                "usd": float(self.max_usd),
            },
            "prices": {
                model: {
                    "input_per_million": float(rates[0]),
                    "output_per_million": float(rates[1]),
                }
                for model, rates in self.prices.items()
            },
            "receipts": [
                {
                    key: float(value) if isinstance(value, Decimal) else value
                    for key, value in receipt.items()
                }
                for receipt in self.receipts
            ],
            "note": "Operator-supplied prices; estimates/reservations are not a provider-enforced billing cap.",
        }


class FreeTierBudget:
    """Request/token guard for an operator-confirmed Groq Free-plan campaign.

    Only declared Groq models can dispatch. No USD figure is invented because the
    API key does not expose its account's actual billing plan to this application.
    """

    def __init__(self, *, max_calls: int, max_tokens: int, models):
        from .groq_provider import GROQ_MODELS

        if (
            isinstance(max_calls, bool)
            or not isinstance(max_calls, int)
            or max_calls < 1
        ):
            raise ValueError("a positive free-tier request limit is required")
        if (
            isinstance(max_tokens, bool)
            or not isinstance(max_tokens, int)
            or max_tokens < 1
        ):
            raise ValueError("a positive free-tier token limit is required")
        allowed = {"groq/" + model for model in GROQ_MODELS}
        if not models or not set(models) <= allowed:
            raise ValueError(
                "free-tier evaluation permits only the supported Groq models"
            )
        self.models = frozenset(models)
        self.max_calls, self.max_tokens = max_calls, max_tokens
        self.calls, self.tokens, self.exhausted = 0, 0, False
        self.receipts = []
        self.lock = asyncio.Lock()

    async def reserve(self, model, payload, output_tokens):
        if model not in self.models:
            self.exhausted = True
            raise BudgetExceeded(
                "free-tier campaign forbids this provider/model; no fallback was dispatched"
            )
        estimate = (
            len(json.dumps(payload, ensure_ascii=False).encode()) + 4096 + output_tokens
        )
        async with self.lock:
            if (
                self.calls + 1 > self.max_calls
                or self.tokens + estimate > self.max_tokens
            ):
                self.exhausted = True
                raise BudgetExceeded(
                    "free-tier request/token budget exhausted before dispatch"
                )
            self.calls += 1
            self.tokens += estimate
            ticket = {
                "model": model,
                "reserved_tokens": estimate,
                "status": "reserved",
                "input_tokens": None,
                "output_tokens": None,
            }
            self.receipts.append(ticket)
            return ticket

    async def settle(self, ticket, usage=None):
        async with self.lock:
            if ticket["status"] != "reserved":
                return
            incoming, outgoing = (
                (usage or {}).get("input_tokens"),
                (usage or {}).get("output_tokens"),
            )
            if any(
                isinstance(value, bool) or not isinstance(value, int) or value < 0
                for value in (incoming, outgoing)
            ):
                ticket["status"] = "unknown_usage"
                return
            self.tokens += incoming + outgoing - ticket["reserved_tokens"]
            ticket.update(
                status="reported_usage", input_tokens=incoming, output_tokens=outgoing
            )
            if self.tokens > self.max_tokens:
                self.exhausted = True
                ticket["status"] = "provider_usage_exceeded_reservation"

    def report(self):
        return {
            "mode": "operator_confirmed_free_plan",
            "billing_verified": False,
            "calls": self.calls,
            "accounted_tokens": self.tokens,
            "accounted_usd": None,
            "limits": {"calls": self.max_calls, "tokens": self.max_tokens},
            "receipts": self.receipts,
            "note": "No paid provider/model fallback. Account owner must verify Free-plan eligibility; provider quotas/billing policy remain authoritative.",
        }
