"""SENTINEL configuration. Every field maps 1:1 to an env var (see .env.example)."""

from __future__ import annotations

import json
import secrets
from functools import lru_cache
from typing import Annotated, Literal
from urllib.parse import urlsplit

from pydantic import Field, field_validator, model_validator
from pydantic_settings import BaseSettings, NoDecode, SettingsConfigDict

_GENERATED_ADMIN_KEY = secrets.token_urlsafe(24)  # per-boot random when not pinned


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=".env", extra="ignore", hide_input_in_errors=True
    )

    PRODUCTION: bool = False
    AUTH_MODE: Literal["api_key", "oidc"] = "api_key"
    OIDC_ISSUER: str = ""
    OIDC_AUDIENCE: str = ""
    OIDC_CLIENT_ID: str = ""
    OIDC_CLIENT_SECRET: str = ""
    OIDC_REDIRECT_URI: str = ""
    OIDC_ROLES_CLAIM: str = "realm_access.roles"
    OIDC_SCOPES: str = "openid profile"
    OIDC_AUTHORIZATION_PARAMS: Annotated[dict[str, str], NoDecode] = Field(
        default_factory=dict
    )
    OIDC_JWKS_TTL_S: int = Field(default=300, ge=30, le=3600)
    OIDC_SESSION_TTL_S: int = Field(default=3600, ge=60, le=86400)
    OIDC_CLOCK_SKEW_S: int = Field(default=15, ge=0, le=120)
    OIDC_MAX_TOKEN_LIFETIME_S: int = Field(default=86400, ge=60, le=604800)
    REDIS_NAMESPACE: str = Field(
        default="sentinel", min_length=1, max_length=64, pattern=r"^[A-Za-z0-9:_-]+$"
    )
    REQUIRE_REDIS: bool = False
    REQUIRE_LIVE_JURY: bool = False
    JURY_MIN_VOTES: int = Field(default=1, ge=1, le=3)
    JURY_TIMEOUT_S: float = Field(default=20, gt=0, le=60)
    WORKER_MODE: Literal["embedded", "external", "disabled"] = "embedded"
    WORKER_CONCURRENCY: int = Field(default=2, ge=1, le=32)
    JOB_LEASE_S: int = Field(default=45, ge=3, le=600)
    JOB_POLL_S: float = Field(default=0.25, gt=0, le=30)
    JOB_MAX_ATTEMPTS: int = Field(default=3, ge=1, le=10)
    SESSION_LEASE_S: int = Field(default=30, ge=3, le=300)
    TARGET_TIMEOUT_S: float = Field(default=45, gt=0, le=180)
    MAX_TARGET_OUTPUT_TOKENS: int = Field(default=300, ge=16, le=8192)
    CACHE_MAX_BYTES: int = Field(default=64 * 1024 * 1024, ge=1048576)
    SESSION_MAX_BYTES: int = Field(default=8 * 1024 * 1024, ge=65536)
    IDEMPOTENCY_TTL_S: int = Field(default=86400, ge=60, le=604800)
    REQUIRE_IDEMPOTENCY_KEY: bool = False
    BODY_READ_TIMEOUT_S: float = Field(default=15, gt=0, le=120)
    MAX_REQUEST_BODY_BYTES: int = Field(default=1048576, ge=65536, le=16777216)
    RATE_LIMIT_IP_MULTIPLIER: int = Field(default=10, ge=1, le=1000)

    DATABASE_URL: str = "sqlite:///./data/sentinel-secure.db"
    REDIS_URL: str = "redis://localhost:6379/0"

    EMBEDDER: str = "auto"  # auto | st | offline

    JURY_MODELS: str = (
        "anthropic/claude-sonnet-4-20250514,openai/gpt-4o,google/gemini-2.0-flash"
    )
    ANTHROPIC_API_KEY: str = ""
    OPENAI_API_KEY: str = ""
    GOOGLE_API_KEY: str = ""

    SESSION_WINDOW: int = Field(default=20, ge=2, le=100)
    SESSION_TTL_S: int = Field(default=1800, ge=1, le=86400)
    SESSION_MAX_COUNT: int = Field(default=4096, ge=1, le=100000)
    SESSION_CLEANUP_S: float = Field(default=30.0, gt=0, le=300)
    QUARANTINE_TTL_S: int = Field(default=300, ge=10, le=3600)
    SIMILARITY_STRONG: float = 0.85
    BAND_REVIEW_LO: float = 30.0
    BAND_BLOCK_HI: float = 70.0
    CONF_MIN_BLOCK: float = 0.4
    FUSION_W: str = "rules:0.35,similarity:0.30,obfuscation:0.10,judge:0.25"
    FUSION_RESPONSE_W: str = "leakage:0.45,indicators:0.25,drift:0.10,judge:0.20"
    OBFUSCATION_BONUS: float = 15.0
    DRIFT_K: float = 2.5
    BASELINE_PROBES: int = 50
    RULE_REFRESH_S: int = 300

    CORPUS_VALIDATION_TARGET: str = (
        "internal://mock"  # optionally a live provider target
    )
    CORS_ORIGINS: str = ""  # v2.4: same-origin only unless listed ("*" = opt in)
    SENTINEL_AUDIT_SECRET: str = ""  # set separately from the database and admin key
    SENTINEL_AUDIT_KEY_FILE: str = (
        ""  # empty -> private key beside SQLite / data for PG
    )
    SENTINEL_SALT: str = Field(default="", max_length=4096)
    SENTINEL_TRUSTED_PROXIES: str = ""  # explicit IPs/CIDRs; never trust arbitrary XFF
    SENTINEL_SECRET: str = ""  # v2.4: Fernet key material for auth_header at rest
    SENTINEL_PROXY_KEY: str = (
        ""  # v2.4: when set, proxy chat needs X-Sentinel-Proxy-Key
    )
    SENTINEL_ADMIN_KEY: str = ""  # empty -> random per boot (printed at startup)
    ENTROPY_THRESHOLD: float = 4.0  # Shannon bits/char for generic secret detection
    ENTROPY_MIN_LEN: int = 20
    RATE_LIMIT_ENABLED: bool = True
    RATE_LIMIT_PROXY_PER_MIN: int = 30  # per client IP, sliding 60s window
    RATE_LIMIT_RUNS_PER_MIN: int = 6
    ANTHROPIC_MODEL: str = "claude-sonnet-4-20250514"
    OPENAI_MODEL: str = "gpt-4o-mini"

    MOCK_LATENCY_MS: int = Field(default=0, ge=0, le=10000)
    VULN_EXTRACTION: bool = True
    VULN_ROLEPLAY: bool = True
    VULN_DELIMITER: bool = True
    VULN_LEAK_KEYS: bool = True
    VULN_DECODE: bool = True
    VULN_TOOL_POISON: bool = True  # v2.3: MCP-style tool-definition poisoning knob
    VULN_HIDDEN: bool = True  # v2.4: obey instructions hidden in markup/zero-width
    VULN_FEWSHOT: bool = True  # v2.4: continue fabricated few-shot compliance
    MOCK_CANARY: str = "CANARY-9F2A41C8"
    MOCK_API_KEY: str = "SK-DEMO-9F27KQZ41LX8M3H7T2V5B6N1"

    @field_validator("OIDC_AUTHORIZATION_PARAMS", mode="before")
    @classmethod
    def authorization_parameters(cls, value):
        return json.loads(value or "{}") if isinstance(value, str) else value

    @model_validator(mode="after")
    def validate_deployment(self):
        if self.SESSION_MAX_BYTES > self.CACHE_MAX_BYTES:
            raise ValueError("SESSION_MAX_BYTES cannot exceed CACHE_MAX_BYTES")
        if self.AUTH_MODE == "oidc":
            if not self.OIDC_ISSUER or not self.OIDC_AUDIENCE:
                raise ValueError("OIDC requires an issuer and API audience")
            for name, value in (
                ("issuer", self.OIDC_ISSUER),
                ("redirect URI", self.OIDC_REDIRECT_URI),
            ):
                if not value:
                    continue
                url = urlsplit(value)
                if (
                    not url.hostname
                    or url.username
                    or url.password
                    or url.query
                    or url.fragment
                ):
                    raise ValueError(f"invalid OIDC {name}")
                if url.scheme != "https" and (self.PRODUCTION or url.scheme != "http"):
                    raise ValueError("OIDC endpoints require HTTPS in production")
            if (
                self.OIDC_REDIRECT_URI
                and urlsplit(self.OIDC_REDIRECT_URI).path != "/auth/callback"
            ):
                raise ValueError("OIDC_REDIRECT_URI must end in /auth/callback")
            if self.OIDC_CLIENT_ID and len(self.SENTINEL_SECRET.encode()) < 32:
                raise ValueError(
                    "Browser SSO requires an encryption secret of at least 32 bytes"
                )
            if self.PRODUCTION and self.OIDC_CLIENT_ID == self.OIDC_AUDIENCE:
                raise ValueError(
                    "Use distinct browser client and API audience identifiers"
                )
            if bool(self.OIDC_CLIENT_ID) != bool(self.OIDC_REDIRECT_URI):
                raise ValueError(
                    "Browser SSO requires both OIDC_CLIENT_ID and OIDC_REDIRECT_URI"
                )
        if self.PRODUCTION:
            if self.AUTH_MODE != "oidc" or not self.is_postgres:
                raise ValueError("Production requires OIDC and PostgreSQL")
            if not self.REQUIRE_REDIS or self.WORKER_MODE != "external":
                raise ValueError(
                    "Production requires Redis and external durable workers"
                )
            if not self.REQUIRE_LIVE_JURY or self.JURY_MIN_VOTES < 2:
                raise ValueError(
                    "Production requires a live jury and at least two valid votes"
                )
            if not self.RATE_LIMIT_ENABLED or not self.REQUIRE_IDEMPOTENCY_KEY:
                raise ValueError("Production requires rate limits and idempotency keys")
            required = [self.SENTINEL_SECRET, self.SENTINEL_AUDIT_SECRET]
            if any(len(value.encode()) < 32 for value in required) or len(
                set(required)
            ) != len(required):
                raise ValueError(
                    "Use independent encryption/audit secrets of at least 32 bytes"
                )
            if self.SENTINEL_PROXY_KEY and (
                len(self.SENTINEL_PROXY_KEY) < 32 or self.SENTINEL_PROXY_KEY in required
            ):
                raise ValueError("Machine proxy keys must be strong and independent")
            if "*" in self.CORS_ORIGINS or self.EMBEDDER == "auto":
                raise ValueError(
                    "Production requires explicit origins and a pinned embedder mode"
                )
        return self

    @property
    def fusion_weights(self) -> dict[str, float]:
        out: dict[str, float] = {}
        for part in self.FUSION_W.split(","):
            k, v = part.split(":")
            out[k.strip()] = float(v)
        return out

    @property
    def response_weights(self) -> dict[str, float]:
        out: dict[str, float] = {}
        for part in self.FUSION_RESPONSE_W.split(","):
            k, v = part.split(":")
            out[k.strip()] = float(v)
        return out

    @property
    def jury_specs(self) -> list[tuple[str, str]]:
        specs = []
        for part in self.JURY_MODELS.split(","):
            part = part.strip()
            if not part:
                continue
            provider, _, model = part.partition("/")
            specs.append((provider.strip(), model.strip()))
        return specs

    @property
    def admin_key(self) -> str:
        return self.SENTINEL_ADMIN_KEY or _GENERATED_ADMIN_KEY

    @property
    def is_postgres(self) -> bool:
        return self.DATABASE_URL.startswith("postgres")


@lru_cache
def get_settings() -> Settings:
    return Settings()
