"""Bounded, activity-expiring session queues with equivalent memory/Redis semantics.

push returns the updated window atomically, so drift uses the same snapshot that
was stored. Memory fallback sweeps idle sessions even when they are never read
again. Namespaced, hashed keys prevent cross-target and cross-channel collisions.
"""

from __future__ import annotations

import asyncio
import hashlib
import json
import time
from collections import OrderedDict, deque
from contextlib import suppress


def session_key(session_id: str, target_id: str = "", channel: str = "request") -> str:
    digest = hashlib.sha256(
        json.dumps([target_id, session_id, channel]).encode()
    ).hexdigest()
    return f"sentinel:session:{digest}"


class MemorySessionStore:
    mode = "memory"

    def __init__(
        self,
        window: int,
        ttl_s: int,
        cleanup_interval_s: float = 30,
        max_sessions: int = 4096,
        max_bytes: int = 64 * 1024 * 1024,
        session_max_bytes: int = 8 * 1024 * 1024,
    ):
        if window < 1 or ttl_s <= 0 or cleanup_interval_s <= 0 or max_sessions < 1:
            raise ValueError("session limits must be positive")
        self.maxlen, self.ttl = window, ttl_s
        self.max_sessions = max_sessions
        self.max_bytes, self.session_max_bytes = max_bytes, session_max_bytes
        self.bytes_used = 0
        self._sizes = {}
        self.cleanup_interval = min(cleanup_interval_s, ttl_s)
        self._data: OrderedDict[str, deque] = OrderedDict()
        self._exp: dict[str, float] = {}
        self._cleanup_task: asyncio.Task | None = None
        self._closed = False

    def start(self):
        if self._closed:
            raise RuntimeError("session store is closed")
        if self._cleanup_task is None:
            self._cleanup_task = asyncio.create_task(
                self._cleanup_loop(), name="session-cleanup"
            )

    def _evict(self, sid: str):
        self.bytes_used -= self._sizes.pop(sid, 0)
        self._data.pop(sid, None)
        self._exp.pop(sid, None)

    def _prune(self, sid: str):
        if self._exp.get(sid, float("inf")) <= time.monotonic():
            self._evict(sid)

    def cleanup_expired(self) -> int:
        now = time.monotonic()
        expired = [sid for sid, deadline in self._exp.items() if deadline <= now]
        for sid in expired:
            self._evict(sid)
        return len(expired)

    async def _cleanup_loop(self):
        while True:
            await asyncio.sleep(self.cleanup_interval)
            self.cleanup_expired()

    async def push(self, sid: str, text: str) -> list[str]:
        return await self.push_many(sid, [text])

    async def push_many(self, sid: str, texts: list[str]) -> list[str]:
        self.start()
        self._prune(sid)
        if sid not in self._data and len(self._data) >= self.max_sessions:
            self.cleanup_expired()
            if len(self._data) >= self.max_sessions:
                self._evict(next(iter(self._data)))
        if any(len(text.encode("utf-8")) > self.session_max_bytes for text in texts):
            raise ValueError("session value exceeds the memory budget")
        queue = self._data.setdefault(sid, deque(maxlen=self.maxlen))
        queue.extend(texts)
        size = sum(len(text.encode("utf-8")) for text in queue)
        while size > self.session_max_bytes:
            size -= len(queue.popleft().encode("utf-8"))
        self.bytes_used += size - self._sizes.get(sid, 0)
        self._sizes[sid] = size
        self._data.move_to_end(sid)
        while self.bytes_used > self.max_bytes:
            self._evict(next(iter(self._data)))
        self._exp[sid] = time.monotonic() + self.ttl
        return list(queue)

    async def window(self, sid: str) -> list[str]:
        self.start()
        self._prune(sid)
        return list(self._data.get(sid, ()))

    async def ping(self) -> bool:
        return not self._closed

    async def close(self):
        self._closed = True
        if self._cleanup_task:
            self._cleanup_task.cancel()
            with suppress(asyncio.CancelledError):
                await self._cleanup_task
            self._cleanup_task = None
        self._data.clear()
        self._exp.clear()
        self._sizes.clear()
        self.bytes_used = 0


class RedisSessionStore:
    mode = "redis"

    def __init__(
        self,
        client,
        window: int,
        ttl_s: int,
        session_max_bytes=8 * 1024 * 1024,
        namespace="",
    ):
        self.namespace = namespace + ":" if namespace else ""
        self.r = client
        self.session_max_bytes = session_max_bytes
        self.maxlen = window  # do not shadow the window() method
        self.ttl = ttl_s

    async def push(self, sid: str, text: str) -> list[str]:
        return await self.push_many(sid, [text])

    async def push_many(self, sid: str, texts: list[str]) -> list[str]:
        if not texts:
            return await self.window(sid)
        if any(len(text.encode("utf-8")) > self.session_max_bytes for text in texts):
            raise ValueError("session value exceeds the memory budget")
        key = f"{self.namespace}{sid}:msgs"
        pipe = self.r.pipeline(transaction=True)
        pipe.rpush(key, *texts)
        pipe.ltrim(key, -self.maxlen, -1)
        pipe.expire(key, self.ttl)
        pipe.eval(
            """
            local values = redis.call('LRANGE', KEYS[1], 0, -1)
            local size = 0
            for _,value in ipairs(values) do size = size + #value end
            local cut = 0
            while size > tonumber(ARGV[1]) and cut < #values do
                cut = cut + 1
                size = size - #values[cut]
            end
            if cut > 0 then redis.call('LTRIM', KEYS[1], cut, -1) end
            return size
        """,
            1,
            key,
            self.session_max_bytes,
        )
        pipe.lrange(key, 0, -1)
        values = (await pipe.execute())[-1]
        return [v.decode() if isinstance(v, bytes) else v for v in values]

    async def window(self, sid: str) -> list[str]:
        values = await self.r.lrange(f"{self.namespace}{sid}:msgs", 0, -1)
        return [v.decode() if isinstance(v, bytes) else v for v in values]

    async def ping(self) -> bool:
        return bool(await self.r.ping())

    async def close(self):
        await self.r.aclose()


async def build_session_store(settings):
    client = None
    try:
        import redis.asyncio as aioredis

        client = aioredis.from_url(
            settings.REDIS_URL, socket_timeout=1.5, socket_connect_timeout=1.5
        )
        store = RedisSessionStore(
            client,
            settings.SESSION_WINDOW,
            settings.SESSION_TTL_S,
            settings.SESSION_MAX_BYTES,
            settings.REDIS_NAMESPACE,
        )
        if await store.ping():
            return store
    except Exception as exc:
        # Redis clients use their own connection-error hierarchy. Startup may fall
        # back; a Redis failure during a conversation is not silently downgraded.
        print(f"[cache] redis unavailable ({exc.__class__.__name__})")
    if client is not None:
        await client.aclose()
    if settings.REQUIRE_REDIS or settings.PRODUCTION:
        raise RuntimeError("Redis is required; refusing memory fallback")
    store = MemorySessionStore(
        settings.SESSION_WINDOW,
        settings.SESSION_TTL_S,
        settings.SESSION_CLEANUP_S,
        settings.SESSION_MAX_COUNT,
        settings.CACHE_MAX_BYTES,
        settings.SESSION_MAX_BYTES,
    )
    store.start()
    return store
