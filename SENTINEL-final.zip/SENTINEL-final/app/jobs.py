"""Durable SQL-backed worker queue (PostgreSQL SKIP LOCKED, SQLite lab fallback).

API handlers commit jobs before responding. Multiple worker processes may compete;
leases, authenticated job snapshots and per-effect receipts protect recovery. The
embedded worker is a lab convenience, not the production execution mechanism.
"""

from __future__ import annotations

import asyncio
import copy
import time
import uuid
from contextlib import suppress

from .identity import actor_context
from .operations import IndeterminateEffect, JobLeaseLost
from .textnorm import canonical_json, sha256_hex

POLICY_FIELDS = (
    "FUSION_W",
    "FUSION_RESPONSE_W",
    "BAND_REVIEW_LO",
    "BAND_BLOCK_HI",
    "CONF_MIN_BLOCK",
    "OBFUSCATION_BONUS",
    "ENTROPY_THRESHOLD",
    "ENTROPY_MIN_LEN",
    "REDACT_INTERNAL_IPS",
    "JURY_MODELS",
    "JURY_MIN_VOTES",
    "REQUIRE_LIVE_JURY",
    "OPENAI_MODEL",
    "ANTHROPIC_MODEL",
)


def policy_snapshot(settings):
    return {key: getattr(settings, key) for key in POLICY_FIELDS}


class Worker:
    def __init__(self, deps):
        self.d = deps
        self.id = uuid.uuid4().hex
        self.tasks = set()
        self.main_task = None
        self.heartbeat_task = None
        self.wakeup = asyncio.Event()
        self.stopping = False

    def start(self):
        if self.main_task is None:
            self.main_task = asyncio.create_task(self.run(), name="durable-worker")
            self.heartbeat_task = asyncio.create_task(
                self.heartbeat(), name="worker-heartbeat"
            )

    async def heartbeat(self):
        while True:
            try:
                await self.d.operations.heartbeat(self.id)
            except Exception as exc:
                self.d.telemetry.failures.labels(
                    "worker_heartbeat", type(exc).__name__
                ).inc()
            await asyncio.sleep(min(5, self.d.settings.JOB_LEASE_S / 3))

    async def run(self):
        while not self.stopping:
            self.wakeup.clear()
            self.tasks = {task for task in self.tasks if not task.done()}
            try:
                if len(self.tasks) < self.d.settings.WORKER_CONCURRENCY:
                    job = await self.d.operations.claim(self.d.settings.JOB_LEASE_S)
                    if job:
                        self.tasks.add(
                            asyncio.create_task(
                                self.execute(job), name="job-" + job["id"]
                            )
                        )
                        continue
            except Exception as exc:
                self.d.telemetry.failures.labels("job_claim", type(exc).__name__).inc()
            try:
                await asyncio.wait_for(
                    self.wakeup.wait(), timeout=self.d.settings.JOB_POLL_S
                )
            except TimeoutError:
                pass

    async def execute(self, job):
        ops = self.d.operations
        token = actor_context.set(job["data"].get("actor"))
        owner = asyncio.current_task()
        lost = False

        async def guard():
            await ops.check(job["id"], job["lease_token"])

        async def renew():
            nonlocal lost
            while True:
                await asyncio.sleep(self.d.settings.JOB_LEASE_S / 3)
                try:
                    if await ops.renew(
                        job["id"], job["lease_token"], self.d.settings.JOB_LEASE_S
                    ):
                        continue
                except Exception:
                    pass
                lost = True
                owner.cancel("job lease lost")
                return

        renewer = asyncio.create_task(renew(), name="job-lease")
        start = time.monotonic()
        data = job["data"]
        try:
            if job["attempts"] > self.d.settings.JOB_MAX_ATTEMPTS:
                raise IndeterminateEffect("job recovery limit reached")
            target = await self.d.store.get_target(data["resource_id"])
            if not target:
                raise ValueError("job target no longer exists")
            if data["kind"] == "assessment":
                from .jury import JuryPanel
                from .pipeline import InspectionEngine
                from .runner import run_batch

                params = data["params"]
                scoped = copy.copy(self.d)
                scoped.settings = self.d.settings.model_copy(update=params["policy"])
                scoped.rules = copy.deepcopy(self.d.rules)
                scoped.rules.load(params["rules"])
                scoped.sim = copy.copy(self.d.sim)
                await scoped.sim.reload(self.d.store)
                if (
                    params.get("similarity_fingerprint")
                    and scoped.sim.fingerprint() != params["similarity_fingerprint"]
                ):
                    raise IndeterminateEffect(
                        "similarity corpus changed after assessment enqueue"
                    )
                scoped.jury = JuryPanel(scoped.settings)
                scoped.engine = InspectionEngine(scoped)
                await self.d.store._write(
                    "UPDATE test_runs SET status='running' WHERE id=?",
                    (data["run_id"],),
                )
                await run_batch(
                    scoped,
                    data["run_id"],
                    target,
                    categories=params.get("categories"),
                    limit=params.get("limit"),
                    enforce_request_block=params["enforce"],
                    guard=guard,
                    pattern_manifest=params.get("patterns"),
                    baseline_snapshot=params.get("baseline", ...),
                )
            elif data["kind"] == "baseline":
                from .baseline import baseline_target

                await ops.once(
                    job["id"],
                    "baseline",
                    sha256_hex(canonical_json(target)),
                    lambda: baseline_target(self.d, target),
                    guard,
                )
            else:
                raise ValueError("unknown job kind")
            await guard()
            await ops.finish(job["id"], job["lease_token"], "completed")
            self.d.telemetry.jobs.labels(data["kind"], "completed").inc()
        except asyncio.CancelledError:
            await ops.abandon(job["id"], job["lease_token"])
            # Do not turn cancellation into successful completion. Receipts decide
            # whether the next owner can resume or must mark an effect uncertain.
            with suppress(Exception):
                await self.d.audit.seal(
                    {"type": "job_interrupted", "job_id": job["id"], "lease_lost": lost}
                )
            raise
        except JobLeaseLost:
            await ops.abandon(job["id"], job["lease_token"])
        except Exception as exc:
            status = (
                "indeterminate" if isinstance(exc, IndeterminateEffect) else "failed"
            )
            if await ops.finish(
                job["id"], job["lease_token"], status, type(exc).__name__
            ):
                if data.get("run_id"):
                    await self.d.store._write(
                        "UPDATE test_runs SET status=? WHERE id=?",
                        (status, data["run_id"]),
                    )
                await self.d.audit.seal(
                    {
                        "type": "job_failed",
                        "job_id": job["id"],
                        "error": type(exc).__name__,
                    }
                )
            self.d.telemetry.jobs.labels(data["kind"], status).inc()
        finally:
            renewer.cancel()
            with suppress(asyncio.CancelledError):
                await renewer
            actor_context.reset(token)
            self.d.telemetry.job_seconds.labels(data["kind"]).observe(
                time.monotonic() - start
            )
            self.wakeup.set()

    async def wait(self, job_id, timeout=300):
        async with asyncio.timeout(timeout):
            while True:
                row = await self.d.operations.get_job(job_id)
                if row and row["status"] not in {"pending", "running"}:
                    return row
                await asyncio.sleep(self.d.settings.JOB_POLL_S)

    async def stop(self):
        self.stopping = True
        tasks = [
            task for task in [self.main_task, self.heartbeat_task, *self.tasks] if task
        ]
        for task in tasks:
            task.cancel()
        await asyncio.gather(*tasks, return_exceptions=True)
        with suppress(Exception):
            await self.d.store._write(
                "DELETE FROM worker_heartbeats WHERE id=?", (self.id,)
            )
        self.tasks.clear()
        self.main_task = self.heartbeat_task = None
