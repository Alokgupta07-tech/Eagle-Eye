"""Stateless target adapters with full conversation history and pinned public egress."""

from __future__ import annotations

import asyncio
import json
import re
from contextvars import ContextVar
from copy import deepcopy

import httpx

from . import mocktarget
from .cache import session_key
from .provider_io import model_json, usage_from
from .ssrf import INTERNAL_ENDPOINTS, UnsafeEndpoint, validate_endpoint_url
from .textnorm import strip_zero_width

MOCK_PREFIX = "internal://mock"
target_observer = ContextVar("target_observer", default=None)


def observed_reply(reply):
    if not isinstance(reply, TargetReply):
        # Built-in laboratory targets only simulate tool actions; they execute none.
        calls = [
            {"name": match, "arguments": {}}
            for match in re.findall(r"^Calling tool ([A-Za-z_]+)\(", str(reply))
        ]
        reply = TargetReply(str(reply), calls)
    observer = target_observer.get()
    if observer:
        observer(reply)
    return reply


def clean_untrusted(value):
    """Remove invisible format controls from text and nested tool definitions.

    Detection receives the original bytes for evidence; dispatch never sends
    Unicode tag instructions that a downstream tokenizer could still interpret.
    """
    if isinstance(value, str):
        return strip_zero_width(value)
    if isinstance(value, list):
        return [clean_untrusted(item) for item in value]
    if isinstance(value, dict):
        cleaned = {}
        for key, item in value.items():
            normalized = strip_zero_width(key)
            if normalized in cleaned:
                raise ValueError(
                    "tool schema keys collide after format-control removal"
                )
            cleaned[normalized] = clean_untrusted(item)
        return cleaned
    return value


def _openai_tools(tools: list[dict]) -> list[dict]:
    result = []
    for tool in tools:
        if tool.get("type") == "function" and isinstance(tool.get("function"), dict):
            result.append(tool)
        else:
            result.append(
                {
                    "type": "function",
                    "function": {
                        "name": tool["name"],
                        "description": tool.get("description", ""),
                        "parameters": tool.get(
                            "inputSchema",
                            tool.get(
                                "input_schema",
                                tool.get(
                                    "parameters", {"type": "object", "properties": {}}
                                ),
                            ),
                        ),
                    },
                }
            )
    return result


def _anthropic_tools(tools: list[dict]) -> list[dict]:
    result = []
    for tool in tools:
        function = tool.get("function", tool)
        result.append(
            {
                "name": function["name"],
                "description": function.get("description", ""),
                "input_schema": function.get(
                    "input_schema",
                    function.get(
                        "inputSchema",
                        function.get(
                            "parameters", {"type": "object", "properties": {}}
                        ),
                    ),
                ),
            }
        )
    return result


class TargetReply(str):
    """Text-compatible reply that also preserves structured tool-call evidence."""

    def __new__(cls, text, tool_calls=None, usage=None, model=None):
        result = super().__new__(cls, text)
        result.tool_calls = tool_calls or []
        result.usage = usage or {}
        result.model = model
        return result


def tool_calls_from(data):
    calls = []
    if data.get("choices"):
        for item in data["choices"][0]["message"].get("tool_calls", []):
            function = item.get("function", {})
            arguments = function.get("arguments", {})
            if isinstance(arguments, str):
                try:
                    arguments = json.loads(arguments)
                except ValueError:
                    arguments = {"unparsed": arguments}
            calls.append({"name": function.get("name"), "arguments": arguments})
    elif isinstance(data.get("content"), list):
        calls = [
            {"name": item.get("name"), "arguments": item.get("input", {})}
            for item in data["content"]
            if item.get("type") == "tool_use"
        ]
    return calls


def _response_text(data: dict) -> str:
    """Include tool calls in inspection, rather than treating them as an empty reply."""
    if data.get("choices"):
        message = data["choices"][0]["message"]
        content = message.get("content") or ""
        if isinstance(content, list):
            content = "\n".join(
                part.get("text", "") for part in content if isinstance(part, dict)
            )
        if message.get("tool_calls"):
            content += "\nTool calls: " + json.dumps(
                message["tool_calls"], ensure_ascii=False
            )
        return str(content)
    if isinstance(data.get("content"), list):
        parts = []
        for block in data["content"]:
            if block.get("type") == "tool_use":
                parts.append("Tool call: " + json.dumps(block, ensure_ascii=False))
            elif isinstance(block.get("text"), str):
                parts.append(block["text"])
        return "\n".join(parts)
    raise ValueError("target did not return a supported chat response")


async def call_target(
    target: dict,
    messages: list[dict],
    session_id: str,
    settings,
    timeout: float | None = None,
    tools: list[dict] | None = None,
) -> str:
    url = target["endpoint_url"]
    if settings.PRODUCTION and url.startswith("internal://mock"):
        raise UnsafeEndpoint("demonstration targets are disabled in production")
    messages = clean_untrusted(deepcopy(messages))
    tools = clean_untrusted(deepcopy(tools)) if tools else None
    if target.get("system_prompt") and not any(
        message["role"] == "system" for message in messages
    ):
        messages.insert(0, {"role": "system", "content": target["system_prompt"]})
    if url.startswith("internal://mock") and target.get("canary_token"):
        settings = settings.model_copy(update={"MOCK_CANARY": target["canary_token"]})
    if url.startswith("internal://mock") and settings.MOCK_LATENCY_MS:
        await asyncio.sleep(settings.MOCK_LATENCY_MS / 1000)
    mock_sid = session_key(session_id, target.get("id", url), "mock-target")
    if url in {"internal://mock-rag", "internal://mock-rag-hardened"}:
        return observed_reply(
            mocktarget.handle_chat_rag(
                messages, mock_sid, settings, hardened="hardened" in url, tools=tools
            )
        )
    if url in {"internal://mock", "internal://mock-hardened"}:
        return observed_reply(
            mocktarget.handle_chat(
                messages, mock_sid, settings, hardened="hardened" in url, tools=tools
            )
        )
    if url.startswith("internal:") and url not in INTERNAL_ENDPOINTS:
        raise UnsafeEndpoint("unknown internal target")

    provider = (
        "anthropic"
        if url == "internal://anthropic"
        else "openai"
        if url == "internal://openai"
        else "external"
    )
    output_tokens = target.get("max_output_tokens", settings.MAX_TARGET_OUTPUT_TOKENS)
    headers = {"Content-Type": "application/json", "X-Session-Id": session_id}
    if url == "internal://anthropic":
        if not settings.ANTHROPIC_API_KEY:
            raise RuntimeError("ANTHROPIC_API_KEY not set")
        url = "https://api.anthropic.com/v1/messages"
        headers.update(
            {"x-api-key": settings.ANTHROPIC_API_KEY, "anthropic-version": "2023-06-01"}
        )
        model = target.get("capabilities", {}).get("model") or settings.ANTHROPIC_MODEL
        payload = {
            "model": model,
            "max_tokens": output_tokens,
            "messages": [
                message for message in messages if message["role"] != "system"
            ],
        }
        system = "\n".join(
            message["content"] for message in messages if message["role"] == "system"
        )
        if system:
            payload["system"] = system
        if tools:
            payload["tools"] = _anthropic_tools(tools)
    else:
        model = target.get("capabilities", {}).get("model") or target.get(
            "name", "target"
        )
        if url == "internal://openai":
            if not settings.OPENAI_API_KEY:
                raise RuntimeError("OPENAI_API_KEY not set")
            url = "https://api.openai.com/v1/chat/completions"
            model = target.get("capabilities", {}).get("model") or settings.OPENAI_MODEL
            headers["Authorization"] = f"Bearer {settings.OPENAI_API_KEY}"
        elif target.get("auth_header"):
            from .secrets import reveal

            headers["Authorization"] = reveal(
                target["auth_header"], settings.SENTINEL_SECRET
            )
        payload = {"model": model, "messages": messages, "max_tokens": output_tokens}
        if tools:
            payload["tools"] = _openai_tools(tools)

    data = await model_json(
        url,
        headers,
        payload,
        provider=provider,
        model=model,
        output_tokens=output_tokens,
        timeout=settings.TARGET_TIMEOUT_S
        if timeout is None
        else min(timeout, settings.TARGET_TIMEOUT_S),
    )
    return observed_reply(
        TargetReply(
            _response_text(data),
            tool_calls_from(data),
            usage_from(data, provider),
            data.get("model", model),
        )
    )
