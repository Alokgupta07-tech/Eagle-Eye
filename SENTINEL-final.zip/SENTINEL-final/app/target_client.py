"""Stateless target adapters with full conversation history and pinned public egress."""
from __future__ import annotations

import json
from copy import deepcopy

import httpx

from . import mocktarget
from .cache import session_key
from .ssrf import INTERNAL_ENDPOINTS, UnsafeEndpoint, validate_endpoint_url
from .textnorm import strip_zero_width

MOCK_PREFIX = "internal://mock"


def clean_untrusted(value):
    """Remove invisible format controls from text and nested tool definitions.

    Detection receives the original bytes for evidence; dispatch never sends
    Unicode tag instructions that a downstream tokenizer could still interpret.
    """
    if isinstance(value, str):
        return strip_zero_width(value)
    if isinstance(value, list):
        return [clean_untrusted(item) for item in value]
    if isinstance(value, dict):
        cleaned = {}
        for key, item in value.items():
            normalized = strip_zero_width(key)
            if normalized in cleaned:
                raise ValueError("tool schema keys collide after format-control removal")
            cleaned[normalized] = clean_untrusted(item)
        return cleaned
    return value


def _openai_tools(tools: list[dict]) -> list[dict]:
    result = []
    for tool in tools:
        if tool.get("type") == "function" and isinstance(tool.get("function"), dict):
            result.append(tool)
        else:
            result.append({"type": "function", "function": {
                "name": tool["name"], "description": tool.get("description", ""),
                "parameters": tool.get("inputSchema", tool.get("input_schema",
                                  tool.get("parameters", {"type": "object", "properties": {}})))}})
    return result


def _anthropic_tools(tools: list[dict]) -> list[dict]:
    result = []
    for tool in tools:
        function = tool.get("function", tool)
        result.append({"name": function["name"],
                       "description": function.get("description", ""),
                       "input_schema": function.get("input_schema", function.get("inputSchema",
                           function.get("parameters", {"type": "object", "properties": {}})))})
    return result


def _response_text(data: dict) -> str:
    """Include tool calls in inspection, rather than treating them as an empty reply."""
    if data.get("choices"):
        message = data["choices"][0]["message"]
        content = message.get("content") or ""
        if isinstance(content, list):
            content = "\n".join(part.get("text", "") for part in content if isinstance(part, dict))
        if message.get("tool_calls"):
            content += "\nTool calls: " + json.dumps(message["tool_calls"], ensure_ascii=False)
        return str(content)
    if isinstance(data.get("content"), list):
        parts = []
        for block in data["content"]:
            if block.get("type") == "tool_use":
                parts.append("Tool call: " + json.dumps(block, ensure_ascii=False))
            elif isinstance(block.get("text"), str):
                parts.append(block["text"])
        return "\n".join(parts)
    raise ValueError("target did not return a supported chat response")


async def call_target(target: dict, messages: list[dict], session_id: str,
                      settings, timeout: float = 30.0,
                      tools: list[dict] | None = None) -> str:
    url = target["endpoint_url"]
    messages = clean_untrusted(deepcopy(messages))
    tools = clean_untrusted(deepcopy(tools)) if tools else None
    mock_sid = session_key(session_id, target.get("id", url), "mock-target")
    if url in {"internal://mock-rag", "internal://mock-rag-hardened"}:
        return mocktarget.handle_chat_rag(messages, mock_sid, settings,
                                          hardened="hardened" in url, tools=tools)
    if url in {"internal://mock", "internal://mock-hardened"}:
        return mocktarget.handle_chat(messages, mock_sid, settings,
                                      hardened="hardened" in url, tools=tools)
    if url.startswith("internal:") and url not in INTERNAL_ENDPOINTS:
        raise UnsafeEndpoint("unknown internal target")

    headers = {"Content-Type": "application/json", "X-Session-Id": session_id}
    if url == "internal://anthropic":
        if not settings.ANTHROPIC_API_KEY:
            raise RuntimeError("ANTHROPIC_API_KEY not set")
        url = "https://api.anthropic.com/v1/messages"
        headers.update({"x-api-key": settings.ANTHROPIC_API_KEY,
                        "anthropic-version": "2023-06-01"})
        payload = {"model": settings.ANTHROPIC_MODEL, "max_tokens": 300,
                   "messages": [message for message in messages if message["role"] != "system"]}
        system = "\n".join(message["content"] for message in messages if message["role"] == "system")
        if system:
            payload["system"] = system
        if tools:
            payload["tools"] = _anthropic_tools(tools)
    else:
        model = target.get("capabilities", {}).get("model") or target.get("name", "target")
        if url == "internal://openai":
            if not settings.OPENAI_API_KEY:
                raise RuntimeError("OPENAI_API_KEY not set")
            url, model = "https://api.openai.com/v1/chat/completions", settings.OPENAI_MODEL
            headers["Authorization"] = f"Bearer {settings.OPENAI_API_KEY}"
        elif target.get("auth_header"):
            from .secrets import reveal
            headers["Authorization"] = reveal(target["auth_header"], settings.SENTINEL_SECRET)
        payload = {"model": model, "messages": messages, "max_tokens": 300}
        if tools:
            payload["tools"] = _openai_tools(tools)

    endpoint = await validate_endpoint_url(url)
    headers["Host"] = endpoint.host_header
    async with httpx.AsyncClient(timeout=timeout, follow_redirects=False, trust_env=False) as client:
        # httpcore's sni_hostname extension keeps TLS certificate validation bound
        # to the original host even though the TCP destination is the pinned IP.
        async with client.stream("POST", endpoint.pinned_url, json=payload, headers=headers,
                                  extensions={"sni_hostname": endpoint.hostname}) as response:
            response.raise_for_status()  # 3xx is rejected, never redirected into a private net
            body = bytearray()
            async for chunk in response.aiter_bytes():
                body.extend(chunk)
                if len(body) > 2 * 1024 * 1024:
                    raise ValueError("target response exceeds the 2 MiB inspection limit")
            return _response_text(json.loads(body))
