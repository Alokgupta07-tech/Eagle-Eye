"""Checked authoring contract for curated seeds; validation results are not inputs."""

from __future__ import annotations

import json
import re
from typing import Literal

from pydantic import BaseModel, ConfigDict, Field, model_validator

CATEGORIES = frozenset(
    {
        "direct_override",
        "roleplay_persona",
        "fake_delimiters",
        "system_prompt_extraction",
        "data_exfiltration",
        "hierarchy_confusion",
        "encoded_payloads",
        "homoglyph_leetspeak",
        "language_switching",
        "multiturn_splitting",
        "quoted_context_smuggling",
        "tool_call_abuse",
        "indirect_injection_rag",
        "tool_definition_poisoning",
        "multi_turn",
        "markdown_hidden_instruction",
        "few_shot_poisoning",
    }
)


class Seed(BaseModel):
    model_config = ConfigDict(extra="forbid", hide_input_in_errors=True)
    category: str
    subcategory: str | None = Field(default=None, max_length=120)
    payload: str | None = Field(default=None, min_length=1, max_length=16000)
    turns: list[str] | None = Field(default=None, min_length=1, max_length=20)
    tools: list[dict] | None = Field(default=None, max_length=64)
    expected_safe_behavior: str = Field(min_length=1, max_length=4096)
    success_indicators: list[str] = Field(min_length=1, max_length=32)
    failure_indicators: list[str] = Field(min_length=1, max_length=32)
    severity: Literal["low", "medium", "high", "critical"]
    remediation: str = Field(min_length=1, max_length=4096)
    allowed_mutations: list[str] = Field(default_factory=list, max_length=32)
    owasp_llm: str = Field(pattern=r"^LLM(?:0[1-9]|10):[A-Za-z][A-Za-z0-9_ -]{1,100}$")
    mitre_atlas: str = Field(
        pattern=r"^AML\.T[0-9]{4}(?:\.[0-9]{3})?:[A-Za-z][A-Za-z0-9_ -]{1,100}$"
    )
    origin: Literal["hand_authored", "adapted", "ai_assisted"]
    taxonomy_source: str = Field(min_length=1, max_length=1000)
    provenance_note: str = Field(min_length=1, max_length=4096)

    @model_validator(mode="after")
    def check_authoring_contract(self):
        from .corpus import MULTI_TURN_MUTATIONS, TRANSFORMS

        if self.category not in CATEGORIES:
            raise ValueError(
                "unknown category; update the reviewed category registry first"
            )
        if not self.payload and not self.turns:
            raise ValueError("provide payload or turns")
        if self.turns:
            if any(not text.strip() or len(text) > 16000 for text in self.turns):
                raise ValueError("each turn must contain 1-16000 characters")
            if self.allowed_mutations:
                raise ValueError(
                    "multi-turn seeds must explicitly use allowed_mutations: []"
                )
        if len(set(self.allowed_mutations)) != len(self.allowed_mutations):
            raise ValueError("duplicate mutation names")
        unknown = set(self.allowed_mutations) - TRANSFORMS.keys()
        if unknown:
            raise ValueError("unknown mutation name")
        for text in [self.payload or "", *(self.turns or []), self.provenance_note]:
            text.encode("utf-8")
        for expression in self.success_indicators + self.failure_indicators:
            if not expression.strip() or len(expression) > 1000:
                raise ValueError(
                    "indicators must be nonempty, bounded regular expressions"
                )
            try:
                re.compile(expression, re.IGNORECASE)
            except re.error as exc:
                raise ValueError("invalid indicator regular expression") from exc
        if self.origin == "adapted" and not re.search(
            r"https?://\S+", self.provenance_note
        ):
            raise ValueError("adapted seeds require a source URL in provenance_note")
        if self.tools:
            if self.category == "indirect_injection_rag":
                raise ValueError(
                    "keep retrieved-document and tool-metadata fixtures separate"
                )
            if set(self.allowed_mutations) & MULTI_TURN_MUTATIONS:
                raise ValueError(
                    "turn-splitting mutators cannot transform tool descriptions"
                )
            try:
                size = len(
                    json.dumps(self.tools, ensure_ascii=False, allow_nan=False).encode(
                        "utf-8"
                    )
                )
            except (ValueError, RecursionError) as exc:
                raise ValueError("tool schemas must be finite, valid JSON") from exc
            if size > 65536:
                raise ValueError("tool definitions exceed 64 KiB")
            descriptions = 0
            stack = [(self.tools, 0)]
            nodes = 0
            while stack:
                value, depth = stack.pop()
                nodes += 1
                if depth > 24 or nodes > 4096:
                    raise ValueError("tool definitions exceed structural limits")
                if isinstance(value, dict):
                    descriptions += int(isinstance(value.get("description"), str))
                    stack.extend((item, depth + 1) for item in value.values())
                elif isinstance(value, list):
                    stack.extend((item, depth + 1) for item in value)
            for tool in self.tools:
                function = tool.get("function", tool)
                if not isinstance(function, dict) or not re.fullmatch(
                    r"[A-Za-z0-9_-]{1,64}", str(function.get("name", ""))
                ):
                    raise ValueError(
                        "tool names must be valid provider function identifiers"
                    )
                schema = function.get(
                    "inputSchema",
                    function.get(
                        "input_schema", function.get("parameters", {"type": "object"})
                    ),
                )
                if (
                    not isinstance(schema, dict)
                    or schema.get("type", "object") != "object"
                ):
                    raise ValueError("tool inputs must have an object schema")
            if self.allowed_mutations and not descriptions:
                raise ValueError("tool metadata mutators require a description field")
        return self


def validate_seeds(values) -> list[dict]:
    from .textnorm import attack_payload_id

    if not isinstance(values, list) or not 1 <= len(values) <= 5000:
        raise ValueError("corpus must be a nonempty JSON array of at most 5000 seeds")
    seen = set()
    for index, value in enumerate(values, 1):
        try:
            seed = Seed.model_validate(value)
            payload = json.dumps({"turns": seed.turns}) if seed.turns else seed.payload
            digest = attack_payload_id(payload, seed.tools)
            if digest in seen:
                raise ValueError("duplicate message/tool payload")
            seen.add(digest)
        except (ValueError, RecursionError) as exc:
            raise ValueError(f"invalid corpus seed #{index}: {exc}") from exc
    # Preserve original bytes/field choices in provenance and legacy payload hashes.
    return values
