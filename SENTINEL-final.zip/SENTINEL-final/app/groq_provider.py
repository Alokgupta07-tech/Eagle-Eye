"""Opt-in Groq free-plan integration; never chooses a paid fallback or built-in tool.

A key cannot prove its billing tier. The account owner must confirm a Free plan;
limits and billing remain provider/account policy, not something this adapter can
verify. Send synthetic test data until the provider's privacy terms are reviewed.
"""

from __future__ import annotations

import json
from copy import deepcopy

GROQ_CHAT_URL = "https://api.groq.com/openai/v1/chat/completions"
GROQ_MODELS = ("openai/gpt-oss-120b", "openai/gpt-oss-20b")

# Strict mode supports these production models. JSON validity is not truthfulness.
VERDICT_SCHEMA = {
    "type": "object",
    "properties": {
        "attack_type": {"type": "string"},
        "risk_score": {"type": "number"},
        "confidence": {"type": "number"},
        "explanation": {"type": "string"},
        "verdict": {
            "type": ["string", "null"],
            "enum": ["SUCCESSFUL", "RESISTED", "INCONCLUSIVE", None],
        },
    },
    "required": ["attack_type", "risk_score", "confidence", "explanation", "verdict"],
    "additionalProperties": False,
}


class GroqConfigurationError(ValueError):
    """Local configuration is incomplete; no provider request has been made."""


class GroqResponseError(ValueError):
    """Incomplete/malformed provider output must not become a valid assessment."""


def validate_groq(settings, model=None):
    selected = model or settings.GROQ_MODEL
    if selected not in GROQ_MODELS:
        raise GroqConfigurationError(
            "Select a supported Groq GPT-OSS model; automatic model fallback is disabled"
        )
    if not settings.GROQ_API_KEY:
        raise GroqConfigurationError("GROQ_API_KEY is not configured on the server")
    if any(
        ord(character) < 33 or ord(character) > 126
        for character in settings.GROQ_API_KEY
    ):
        raise GroqConfigurationError("GROQ_API_KEY contains invalid header characters")
    if not settings.GROQ_FREE_PLAN_CONFIRMED:
        raise GroqConfigurationError(
            "Confirm your Groq account is on the Free plan and set GROQ_FREE_PLAN_CONFIRMED=true"
        )
    return selected


def groq_payload(
    settings, model, messages, *, tools=None, judge=False, max_tokens=None
):
    selected = validate_groq(settings, model)
    cap = settings.GROQ_JUDGE_MAX_TOKENS if judge else settings.GROQ_TARGET_MAX_TOKENS
    if max_tokens is not None:
        if (
            isinstance(max_tokens, bool)
            or not isinstance(max_tokens, int)
            or max_tokens < 1
        ):
            raise GroqConfigurationError("Invalid completion-token limit")
        cap = min(cap, max_tokens)
    if judge and tools:
        raise GroqConfigurationError("Jury calls cannot execute tools")
    if tools and any(tool.get("type") != "function" for tool in tools):
        raise GroqConfigurationError(
            "Only custom function definitions are supported; provider-built-in tools are disabled"
        )
    payload = {
        "model": selected,
        "messages": deepcopy(messages),
        "max_completion_tokens": cap,
        "reasoning_effort": "low",
        "include_reasoning": False,
        "temperature": 0,
        "stream": False,
    }
    if judge:
        payload["response_format"] = {
            "type": "json_schema",
            "json_schema": {
                "name": "sentinel_verdict",
                "strict": True,
                "schema": deepcopy(VERDICT_SCHEMA),
            },
        }
    elif tools:
        payload.update(
            tools=deepcopy(tools), parallel_tool_calls=False, tool_choice="auto"
        )
    if (
        len(json.dumps(payload, ensure_ascii=False, allow_nan=False).encode("utf-8"))
        > settings.GROQ_MAX_INPUT_BYTES
    ):
        raise GroqConfigurationError(
            "Groq free-profile input limit exceeded; shorten the message/history/tools"
        )
    return payload


def validate_groq_response(data):
    try:
        choice = data["choices"][0]
        message = choice["message"]
        reason = choice.get("finish_reason")
        if not isinstance(message, dict):
            raise GroqResponseError("Invalid Groq message shape")
        if message.get("tool_calls") is not None and not isinstance(
            message["tool_calls"], list
        ):
            raise GroqResponseError("Invalid Groq tool-call list")
        if reason not in {"stop", "tool_calls"}:
            raise GroqResponseError("Groq response was truncated or did not complete")
        if reason == "tool_calls" and not message.get("tool_calls"):
            raise GroqResponseError("Groq returned an empty tool-call response")
        if not isinstance(message.get("content"), str) and not message.get(
            "tool_calls"
        ):
            raise GroqResponseError("Groq returned no inspectable response")
        if not (message.get("content") or "").strip() and not message.get("tool_calls"):
            raise GroqResponseError("Groq returned empty content")
    except (KeyError, IndexError, TypeError, AttributeError) as exc:
        raise GroqResponseError("Invalid Groq response envelope") from exc
    return data


def validate_jury_shape(value):
    if not isinstance(value, dict) or set(value) != set(VERDICT_SCHEMA["required"]):
        raise GroqResponseError("Groq jury response does not match the required schema")
    if any(not isinstance(value[key], str) for key in ("attack_type", "explanation")):
        raise GroqResponseError("Invalid Groq jury text fields")
    if any(
        isinstance(value[key], bool) or not isinstance(value[key], (int, float))
        for key in ("risk_score", "confidence")
    ):
        raise GroqResponseError("Invalid Groq jury numeric fields")
    if value["verdict"] not in {None, "SUCCESSFUL", "RESISTED", "INCONCLUSIVE"}:
        raise GroqResponseError("Invalid Groq jury verdict")
    # The shared parser also enforces finite scores and their numeric ranges.
    return value


def groq_status(settings, jury):
    """Configuration only, never a connectivity/billing claim and never a key echo."""
    return {
        "provider": "groq",
        "label": "Groq / GPT-OSS (free-plan option)",
        "model": settings.GROQ_MODEL,
        "models": list(GROQ_MODELS),
        "key_configured": bool(settings.GROQ_API_KEY),
        "free_plan_confirmed": settings.GROQ_FREE_PLAN_CONFIRMED,
        "configured": bool(settings.GROQ_API_KEY and settings.GROQ_FREE_PLAN_CONFIRMED),
        "billing_verified": False,
        "connection_verified": False,
        "jury_mode": jury.mode,
        "jury_members": jury.describe(),
        "live_jury_members": sum(
            not member.startswith("MOCK:") for member in jury.describe()
        ),
        "jury_members_total": len(jury.members),
        "judge_all_requests": settings.GROQ_JUDGE_ALL_REQUESTS,
        "baseline_probe_limit": settings.GROQ_BASELINE_PROBES,
        "assessment_case_limit": settings.GROQ_MAX_RUN_CASES,
        "automatic_baseline": False,
        "automatic_fallback": False,
        "setup_command": "python scripts/run_free_ai.py --env-file .env.groq --check",
        "note": "Requires your own Free-plan API key. Groq receives submitted content. Quotas may produce 429; SENTINEL does not upgrade or switch providers.",
    }


def uses_groq(settings, target=None):
    return bool(
        (target or {}).get("endpoint_url") == "internal://groq"
        or (
            settings.GROQ_API_KEY
            and settings.GROQ_FREE_PLAN_CONFIRMED
            and any(provider == "groq" for provider, _ in settings.jury_specs)
        )
    )


def validate_free_assessment(settings, target, limit):
    if uses_groq(settings, target) and (
        limit is None or not 1 <= limit <= settings.GROQ_MAX_RUN_CASES
    ):
        raise GroqConfigurationError(
            f"Free-plan assessments require an explicit limit between 1 and {settings.GROQ_MAX_RUN_CASES}; use the budgeted evaluator for a larger approved campaign"
        )
