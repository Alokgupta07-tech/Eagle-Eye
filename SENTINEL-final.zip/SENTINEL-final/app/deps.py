"""Dependency container — single object holding every wired component."""
from __future__ import annotations

import asyncio
import ipaddress
import secrets
import time
from collections import deque
from functools import lru_cache

from fastapi import Header, HTTPException, Request

from .audit import Audit
from .cache import build_session_store
from .db import Store
from .embed import build_embedder
from .jury import JuryPanel
from .pipeline import InspectionEngine
from .rules import SEED_RULES, RuleEngine
from .similarity import SimilarityEngine


class Deps:
    def __init__(self, settings):
        self.settings = settings
        self.store: Store | None = None
        self.cache = None
        self.embedder = None
        self.rules: RuleEngine | None = None
        self.sim: SimilarityEngine | None = None
        self.jury: JuryPanel | None = None
        self.audit: Audit | None = None
        self.engine: InspectionEngine | None = None
        self.run_tasks: dict[str, asyncio.Task] = {}
        self.baseline_tasks: dict[str, asyncio.Task] = {}
        self._refresh_task: asyncio.Task | None = None
        self._maintenance_task: asyncio.Task | None = None
        self.baseline_errors: dict[str, str] = {}

    async def start(self):
        try:
            self.store = Store(self.settings)
            await self.store.connect()
            await self.store.seed_rules(SEED_RULES)
            self.rules = RuleEngine()
            await self.rules.reload(self.store)
            self.cache = await build_session_store(self.settings)
            self.embedder = await asyncio.to_thread(build_embedder, self.settings.EMBEDDER)
            self.sim = SimilarityEngine(self.embedder, self.settings.SIMILARITY_STRONG)
            await self.sim.reload(self.store)
            self.jury = JuryPanel(self.settings)
            self.audit = Audit(self.store)
            self.engine = InspectionEngine(self)
            self._refresh_task = asyncio.create_task(self._rule_refresher(), name="rule-refresh")
            self._maintenance_task = asyncio.create_task(self._maintenance(), name="state-maintenance")
        except BaseException:
            await self.stop()
            raise

    async def _rule_refresher(self):
        """Stale-cache fix: periodic hot-reload of the in-memory rule cache."""
        while True:
            await asyncio.sleep(max(5, self.settings.RULE_REFRESH_S))
            try:
                await self.rules.reload(self.store)
                await self.sim.reload(self.store)
                await self.store.cleanup_quarantines()
            except Exception as exc:  # noqa: BLE001
                print(f"[rules] periodic refresh failed: {exc}")

    async def _maintenance(self):
        while True:
            await asyncio.sleep(30)
            try:
                await self.store.cleanup_quarantines()
                from .mocktarget import cleanup_sessions
                cleanup_sessions(self.settings.SESSION_TTL_S)
            except Exception as exc:
                print(f"[maintenance] cleanup failed: {exc.__class__.__name__}")

    def start_baseline(self, target: dict):
        target_id = target["id"]
        existing = self.baseline_tasks.get(target_id)
        if existing and not existing.done():
            return
        self.baseline_errors.pop(target_id, None)

        async def work():
            from .baseline import baseline_target
            try:
                await baseline_target(self, target)
            except Exception as exc:
                self.baseline_errors[target_id] = exc.__class__.__name__
                await self.audit.seal({"type": "baseline_failed", "target_id": target_id,
                                       "error": exc.__class__.__name__})
            finally:
                self.baseline_tasks.pop(target_id, None)
        self.baseline_tasks[target_id] = asyncio.create_task(work(), name=f"baseline-{target_id}")

    async def stop(self):
        tasks = [t for t in [self._refresh_task, self._maintenance_task, *self.run_tasks.values(),
                              *self.baseline_tasks.values()] if t is not None]
        for task in tasks:
            task.cancel()
        await asyncio.gather(*tasks, return_exceptions=True)
        self.run_tasks.clear()
        self.baseline_tasks.clear()
        if self.cache:
            await self.cache.close()
        if self.store:
            await self.store.close()


# Per-process sliding-window rate-limiter state: bucket -> client IP -> timestamps.
# Reset by tests via conftest; no Redis/dependency needed (spec: no new deps).
_now = time.monotonic
_RATE_WINDOWS: dict[str, dict[str, deque]] = {}
_RATE_PRUNED: dict[str, float] = {}


@lru_cache(maxsize=16)
def _trusted_networks(value: str):
    # Invalid trust configuration must fail closed rather than trust all proxies.
    return tuple(ipaddress.ip_network(part.strip(), strict=False)
                 for part in value.split(",") if part.strip())


def client_ip(request: Request) -> str:
    """Peel forwarding hops from the right only while the immediate hop is trusted.

    Direct clients cannot choose their rate-limit identity with a forged header.
    Configure SENTINEL_TRUSTED_PROXIES with the actual ingress proxy CIDRs and
    disable Uvicorn's own proxy-header rewriting (run.py does this).
    """
    peer = request.client.host if request.client else "unknown"
    try:
        address = ipaddress.ip_address(peer)
        networks = _trusted_networks(request.app.state.deps.settings.SENTINEL_TRUSTED_PROXIES)
    except ValueError:
        return peer

    def trusted(addr):
        return any(addr in network for network in networks)

    if not trusted(address):
        return address.compressed
    forwarded = request.headers.get("x-forwarded-for")
    if forwarded:
        if len(forwarded) > 4096 or len(forwarded.split(",")) > 32:
            return address.compressed
        try:
            hops = [ipaddress.ip_address(hop.strip()) for hop in forwarded.split(",")]
        except ValueError:
            return address.compressed
        for hop in reversed(hops):
            if not trusted(address):
                break
            address = hop
    elif request.headers.get("x-real-ip"):
        try:
            address = ipaddress.ip_address(request.headers["x-real-ip"].strip())
        except ValueError:
            return peer
    return address.compressed


def rate_limited(bucket: str, per_min: int):
    """Dependency factory: per-IP sliding-window limit (per_min requests / 60s).
    Breach -> 429 with Retry-After. RATE_LIMIT_ENABLED=false disables globally."""
    async def _check(request: Request):
        if not request.app.state.deps.settings.RATE_LIMIT_ENABLED:
            return
        ip = client_ip(request)
        now = _now()
        windows = _RATE_WINDOWS.setdefault(bucket, {})
        if now - _RATE_PRUNED.get(bucket, 0) >= 60:
            for stale_ip, timestamps in list(windows.items()):
                if not timestamps or timestamps[-1] <= now - 60:
                    windows.pop(stale_ip, None)
            _RATE_PRUNED[bucket] = now
        win = windows.setdefault(ip, deque())
        while win and win[0] <= now - 60.0:
            win.popleft()
        if len(win) >= per_min:
            retry = max(1, int(60.0 - (now - win[0])))
            raise HTTPException(status_code=429,
                                detail=f"rate limit exceeded for '{bucket}' "
                                       f"({per_min}/min per IP)",
                                headers={"Retry-After": str(retry)})
        win.append(now)

    return _check


async def require_proxy_key(request: Request,
                            x_sentinel_proxy_key: str | None = Header(default=None)):
    """Optional lock on the data plane (v2.4): enforced only when SENTINEL_PROXY_KEY is set,
    so the open demo stays open and a judge can see it can be locked."""
    expected = request.app.state.deps.settings.SENTINEL_PROXY_KEY
    if expected and not secrets.compare_digest(
            (x_sentinel_proxy_key or "").encode("utf-8"), expected.encode("utf-8")):
        raise HTTPException(status_code=401, detail="invalid or missing X-Sentinel-Proxy-Key")


async def require_admin(request: Request,
                        x_sentinel_admin_key: str | None = Header(default=None)):
    """Control-plane gate: admin operations, assessments, executions and reports."""
    expected = request.app.state.deps.settings.admin_key
    if not secrets.compare_digest(
            (x_sentinel_admin_key or "").encode("utf-8"), expected.encode("utf-8")):
        raise HTTPException(status_code=401,
                            detail="invalid or missing X-Sentinel-Admin-Key")
