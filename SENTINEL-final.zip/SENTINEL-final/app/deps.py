"""Dependency container — single object holding every wired component."""

from __future__ import annotations

import asyncio
import ipaddress
import secrets
import time
from collections import deque
from functools import lru_cache

from fastapi import Header, HTTPException, Request

from .audit import Audit
from .cache import build_session_store
from .coordination import MemoryCoordinator, RedisCoordinator, key_for
from .db import Store
from .embed import build_embedder
from .identity import Identity, Principal, actor_context, anonymous, attach_principal
from .jury import JuryPanel
from .operations import Operations
from .pipeline import InspectionEngine
from .rules import SEED_RULES, RuleEngine
from .similarity import SimilarityEngine
from .telemetry import Telemetry


class Deps:
    def __init__(self, settings, role="api"):
        self.settings, self.role = settings, role
        self.operations = None
        self.coordination = None
        self.identity = None
        self.worker = None
        self.telemetry = Telemetry()
        self.store: Store | None = None
        self.cache = None
        self.embedder = None
        self.rules: RuleEngine | None = None
        self.sim: SimilarityEngine | None = None
        self.jury: JuryPanel | None = None
        self.audit: Audit | None = None
        self.engine: InspectionEngine | None = None
        self.run_tasks: dict[str, asyncio.Task] = {}
        self.baseline_tasks: dict[str, asyncio.Task] = {}
        self._refresh_task: asyncio.Task | None = None
        self._maintenance_task: asyncio.Task | None = None
        self.baseline_errors: dict[str, str] = {}

    async def start(self):
        try:
            self.store = Store(self.settings)
            await self.store.connect()
            self.operations = Operations(self.store)
            await self.operations.migrate()
            await self.refresh_policy()
            await self.store.seed_rules(SEED_RULES)
            self.rules = RuleEngine()
            await self.rules.reload(self.store)
            self.cache = await build_session_store(self.settings)
            self.coordination = (
                RedisCoordinator(self.cache.r, self.settings.REDIS_NAMESPACE)
                if self.cache.mode == "redis"
                else MemoryCoordinator(self.settings.CACHE_MAX_BYTES)
            )
            self.identity = Identity(self.settings, self.coordination)
            if self.role == "api":
                await self.identity.start()
            self.embedder = await asyncio.to_thread(
                build_embedder, self.settings.EMBEDDER
            )
            self.sim = SimilarityEngine(self.embedder, self.settings.SIMILARITY_STRONG)
            await self.sim.reload(self.store)
            self.jury = JuryPanel(self.settings)
            if self.settings.REQUIRE_LIVE_JURY:
                if (
                    self.jury.mode != "live"
                    or len({p for p, _ in self.settings.jury_specs}) < 2
                ):
                    raise RuntimeError(
                        "A live jury from at least two providers is required"
                    )
            if self.settings.PRODUCTION and self.embedder.mode != (
                {"st": "st-384"}.get(self.settings.EMBEDDER, self.settings.EMBEDDER)
            ):
                raise RuntimeError("Pinned embedder unavailable; refusing fallback")
            self.audit = Audit(self.store)
            self.engine = InspectionEngine(self)
            if self.role == "worker" or self.settings.WORKER_MODE == "embedded":
                from .jobs import Worker

                self.worker = Worker(self)
                self.worker.start()
            self._refresh_task = asyncio.create_task(
                self._rule_refresher(), name="rule-refresh"
            )
            self._maintenance_task = asyncio.create_task(
                self._maintenance(), name="state-maintenance"
            )
        except BaseException:
            await self.stop()
            raise

    async def _rule_refresher(self):
        """Stale-cache fix: periodic hot-reload of the in-memory rule cache."""
        while True:
            await asyncio.sleep(max(5, self.settings.RULE_REFRESH_S))
            try:
                await self.rules.reload(self.store)
                await self.sim.reload(self.store)
                await self.store.cleanup_quarantines()
            except Exception as exc:  # noqa: BLE001
                print(f"[rules] periodic refresh failed: {exc}")

    async def _maintenance(self):
        while True:
            await asyncio.sleep(30)
            try:
                await self.store.cleanup_quarantines()
                await self.operations.cleanup()
                if self.coordination.mode == "memory":
                    self.coordination.cleanup()
                from .mocktarget import cleanup_sessions

                cleanup_sessions(self.settings.SESSION_TTL_S)
            except Exception as exc:
                print(f"[maintenance] cleanup failed: {exc.__class__.__name__}")

    async def refresh_policy(self):
        policy = await self.operations.policy() if self.operations else None
        if policy:
            for key in ("FUSION_W", "FUSION_RESPONSE_W"):
                if key in policy:
                    setattr(self.settings, key, policy[key])

    async def start_baseline(self, target: dict):
        existing = await self.operations.latest_baseline_job(target["id"])
        if existing and existing["status"] in {"pending", "running"}:
            return existing["id"]
        job_id = await self.operations.enqueue(
            "baseline", target["id"], {}, actor_context.get()
        )
        if self.worker:
            self.worker.wakeup.set()

            # Compatibility/observation only. Work itself is in the durable queue.
            async def observe():
                try:
                    await self.worker.wait(
                        job_id,
                        timeout=self.settings.BASELINE_PROBES
                        * (self.settings.TARGET_TIMEOUT_S + 2)
                        + 30,
                    )
                finally:
                    self.baseline_tasks.pop(target["id"], None)

            self.baseline_tasks[target["id"]] = asyncio.create_task(
                observe(), name="baseline-observer"
            )
        return job_id

    async def stop(self):
        if self.worker:
            await self.worker.stop()
        tasks = [
            t
            for t in [
                self._refresh_task,
                self._maintenance_task,
                *self.run_tasks.values(),
                *self.baseline_tasks.values(),
            ]
            if t is not None
        ]
        for task in tasks:
            task.cancel()
        await asyncio.gather(*tasks, return_exceptions=True)
        self.run_tasks.clear()
        self.baseline_tasks.clear()
        if self.identity:
            await self.identity.close()
        if self.coordination:
            await self.coordination.close()
        if self.cache:
            await self.cache.close()
        if self.store:
            await self.store.close()


# Per-process sliding-window rate-limiter state: bucket -> client IP -> timestamps.
# Reset by tests via conftest; no Redis/dependency needed (spec: no new deps).
_now = time.monotonic
_RATE_WINDOWS: dict[str, dict[str, deque]] = {}
_RATE_PRUNED: dict[str, float] = {}


@lru_cache(maxsize=16)
def _trusted_networks(value: str):
    # Invalid trust configuration must fail closed rather than trust all proxies.
    return tuple(
        ipaddress.ip_network(part.strip(), strict=False)
        for part in value.split(",")
        if part.strip()
    )


def client_ip(request: Request) -> str:
    """Peel forwarding hops from the right only while the immediate hop is trusted.

    Direct clients cannot choose their rate-limit identity with a forged header.
    Configure SENTINEL_TRUSTED_PROXIES with the actual ingress proxy CIDRs and
    disable Uvicorn's own proxy-header rewriting (run.py does this).
    """
    peer = request.client.host if request.client else "unknown"
    try:
        address = ipaddress.ip_address(peer)
        networks = _trusted_networks(
            request.app.state.deps.settings.SENTINEL_TRUSTED_PROXIES
        )
    except ValueError:
        return peer

    def trusted(addr):
        return any(addr in network for network in networks)

    if not trusted(address):
        return address.compressed
    forwarded = request.headers.get("x-forwarded-for")
    if forwarded:
        if len(forwarded) > 4096 or len(forwarded.split(",")) > 32:
            return address.compressed
        try:
            hops = [ipaddress.ip_address(hop.strip()) for hop in forwarded.split(",")]
        except ValueError:
            return address.compressed
        for hop in reversed(hops):
            if not trusted(address):
                break
            address = hop
    elif request.headers.get("x-real-ip"):
        try:
            address = ipaddress.ip_address(request.headers["x-real-ip"].strip())
        except ValueError:
            return peer
    return address.compressed


def rate_limited(bucket: str, per_min: int):
    """Dependency factory: per-IP sliding-window limit (per_min requests / 60s).
    Breach -> 429 with Retry-After. RATE_LIMIT_ENABLED=false disables globally."""

    async def _check(request: Request):
        if not request.app.state.deps.settings.RATE_LIMIT_ENABLED:
            return
        d = request.app.state.deps
        ip = client_ip(request)
        if d.coordination and d.coordination.mode == "redis":
            principal = getattr(request.state, "principal", None)
            identity = (
                principal.identity_key
                if principal and principal.method != "anonymous"
                else ip
            )
            limits = [(key_for("rate", bucket, "identity", identity), per_min)]
            if identity != ip:
                limits.append(
                    (
                        key_for("rate", bucket, "ip", ip),
                        per_min * d.settings.RATE_LIMIT_IP_MULTIPLIER,
                    )
                )
            try:
                retry = await d.coordination.rate_limit(limits)
            except Exception:
                raise HTTPException(
                    status_code=503, detail="distributed quota service unavailable"
                ) from None
            if retry:
                raise HTTPException(
                    status_code=429,
                    detail=f"rate limit exceeded for '{bucket}'",
                    headers={"Retry-After": str(retry)},
                )
            return
        now = _now()
        windows = _RATE_WINDOWS.setdefault(bucket, {})
        if now - _RATE_PRUNED.get(bucket, 0) >= 60:
            for stale_ip, timestamps in list(windows.items()):
                if not timestamps or timestamps[-1] <= now - 60:
                    windows.pop(stale_ip, None)
            _RATE_PRUNED[bucket] = now
        win = windows.setdefault(ip, deque())
        while win and win[0] <= now - 60.0:
            win.popleft()
        if len(win) >= per_min:
            retry = max(1, int(60.0 - (now - win[0])))
            raise HTTPException(
                status_code=429,
                detail=f"rate limit exceeded for '{bucket}' ({per_min}/min per IP)",
                headers={"Retry-After": str(retry)},
            )
        win.append(now)

    return _check


async def require_proxy_key(
    request: Request, x_sentinel_proxy_key: str | None = Header(default=None)
):
    d = request.app.state.deps
    if d.settings.AUTH_MODE == "oidc" and (
        request.headers.get("authorization") or request.cookies.get("sentinel_session")
    ):
        user = await d.identity.authenticate(request)
        if "proxy:chat" not in user.permissions:
            raise HTTPException(status_code=403, detail="proxy permission required")
        return user
    expected = d.settings.SENTINEL_PROXY_KEY
    if expected and not secrets.compare_digest(
        (x_sentinel_proxy_key or "").encode("utf-8"), expected.encode("utf-8")
    ):
        raise HTTPException(
            status_code=401, detail="invalid or missing X-Sentinel-Proxy-Key"
        )
    if not expected and d.settings.AUTH_MODE == "oidc":
        raise HTTPException(
            status_code=401, detail="identity or machine proxy key required"
        )
    user = (
        Principal("machine-proxy", "sentinel", frozenset({"service"}), "api_key")
        if expected
        else anonymous()
    )
    return attach_principal(request, user)


async def require_admin(
    request: Request, x_sentinel_admin_key: str | None = Header(default=None)
):
    d = request.app.state.deps
    if d.settings.AUTH_MODE == "oidc":
        user = await d.identity.authenticate(request)
        if "policy:write" not in user.permissions:
            raise HTTPException(status_code=403, detail="administrator role required")
        return user
    expected = d.settings.admin_key
    if not secrets.compare_digest(
        (x_sentinel_admin_key or "").encode("utf-8"), expected.encode("utf-8")
    ):
        raise HTTPException(
            status_code=401, detail="invalid or missing X-Sentinel-Admin-Key"
        )
    return attach_principal(
        request, Principal("legacy-admin", "sentinel", frozenset({"admin"}), "api_key")
    )


def require_permission(permission: str):
    async def check(request: Request):
        d = request.app.state.deps
        if d.settings.AUTH_MODE == "api_key":
            user = await require_admin(
                request, request.headers.get("x-sentinel-admin-key")
            )
        else:
            user = getattr(
                request.state, "principal", None
            ) or await d.identity.authenticate(request)
        if permission not in user.permissions:
            raise HTTPException(
                status_code=403, detail=f"permission required: {permission}"
            )
        return user

    return check
