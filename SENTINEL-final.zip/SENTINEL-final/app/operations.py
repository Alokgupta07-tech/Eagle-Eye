"""Transactional durable jobs, effect receipts, HTTP idempotency and policy state.

An interrupted upstream effect is INDETERMINATE, never automatically sent again.
That is deliberately not an exactly-once claim about a remote model/tool service.
Completed receipts let a restarted worker resume without repeating paid calls.
"""

from __future__ import annotations

import json
import time
import uuid
from datetime import datetime, timezone

from .audit import chain_hmac, valid_mac
from .secrets import protect, reveal
from .textnorm import canonical_json, sha256_hex

SCHEMA = """
CREATE TABLE IF NOT EXISTS durable_jobs(
 id TEXT PRIMARY KEY, kind TEXT NOT NULL, resource_id TEXT NOT NULL, run_id TEXT UNIQUE,
 payload TEXT NOT NULL, mac TEXT NOT NULL, status TEXT NOT NULL,
 attempts INTEGER NOT NULL DEFAULT 0, lease_token TEXT, lease_until DOUBLE PRECISION NOT NULL DEFAULT 0,
 available_at DOUBLE PRECISION NOT NULL, created_at DOUBLE PRECISION NOT NULL,
 updated_at DOUBLE PRECISION NOT NULL, error TEXT);
CREATE INDEX IF NOT EXISTS job_claim_index ON durable_jobs(status, available_at, lease_until);
CREATE INDEX IF NOT EXISTS job_resource_index ON durable_jobs(resource_id, kind, created_at);
CREATE UNIQUE INDEX IF NOT EXISTS one_active_baseline ON durable_jobs(resource_id)
 WHERE kind='baseline' AND status IN ('pending','running');
CREATE TABLE IF NOT EXISTS worker_heartbeats(
 id TEXT PRIMARY KEY, seen_at DOUBLE PRECISION NOT NULL);
CREATE TABLE IF NOT EXISTS effect_receipts(
 scope TEXT NOT NULL, step TEXT NOT NULL, fingerprint TEXT NOT NULL,
 status TEXT NOT NULL, result TEXT, mac TEXT, created_at DOUBLE PRECISION NOT NULL,
 PRIMARY KEY(scope, step));
CREATE TABLE IF NOT EXISTS execution_commits(
 id TEXT PRIMARY KEY, run_id TEXT NOT NULL, pattern_id TEXT NOT NULL,
 UNIQUE(run_id, pattern_id));
CREATE TABLE IF NOT EXISTS idempotency_requests(
 scope TEXT NOT NULL, key_hash TEXT NOT NULL, fingerprint TEXT NOT NULL,
 status TEXT NOT NULL, result TEXT, mac TEXT, expires_at DOUBLE PRECISION NOT NULL,
 PRIMARY KEY(scope, key_hash));
CREATE TABLE IF NOT EXISTS conversations(
 scope TEXT PRIMARY KEY, version BIGINT NOT NULL, payload TEXT NOT NULL, mac TEXT NOT NULL,
 expires_at DOUBLE PRECISION NOT NULL);
CREATE INDEX IF NOT EXISTS conversation_expiry ON conversations(expires_at);
CREATE TABLE IF NOT EXISTS runtime_policy(
 id TEXT PRIMARY KEY, payload TEXT NOT NULL, mac TEXT NOT NULL);
"""


class IndeterminateEffect(Exception):
    """A previous worker may have dispatched this effect; a retry is unsafe."""


class JobLeaseLost(Exception):
    """Only the current durable-job owner may finalize work."""


class IdempotencyConflict(Exception):
    """The key has a different payload, is in progress, or has uncertain outcome."""


class Operations:
    def __init__(self, store):
        self.store = store

    async def migrate(self):
        await self.store.migrate_schema(SCHEMA)

    def pack(self, domain, data):
        payload = canonical_json(data)
        return payload, chain_hmac(self.store.audit_key, domain, data)

    def unpack(self, domain, row):
        try:
            data = json.loads(row["payload"])
            if not valid_mac(
                row["mac"], chain_hmac(self.store.audit_key, domain, data)
            ):
                raise ValueError("operational record failed integrity verification")
            return data
        except (TypeError, KeyError, ValueError) as exc:
            raise ValueError(
                "operational record failed integrity verification"
            ) from exc

    async def enqueue(self, kind, resource_id, params, actor=None, run=None):
        job_id, now = uuid.uuid4().hex, time.time()
        run_id = run["id"] if run else None
        data = {
            "kind": kind,
            "resource_id": resource_id,
            "run_id": run_id,
            "params": params,
            "actor": actor,
        }
        from .audit import Audit

        data["intent_seq"] = await Audit(self.store).seal(
            {
                "type": "job_enqueue_intent",
                "job_id": job_id,
                "run_id": run_id,
                "target_id": resource_id,
                "kind": kind,
            }
        )
        payload, mac = self.pack("job:" + job_id, data)
        statements = []
        if run:
            columns = list(run)
            statements.append(
                (
                    f"INSERT INTO test_runs({','.join(columns)}) VALUES({','.join('?' for _ in columns)})",
                    tuple(run[column] for column in columns),
                )
            )
        statements.append(
            (
                "INSERT INTO durable_jobs(id,kind,resource_id,run_id,payload,mac,status,available_at,created_at,updated_at) "
                "VALUES(?,?,?,?,?,?,'pending',?,?,?)",
                (job_id, kind, resource_id, run_id, payload, mac, now, now, now),
            )
        )
        try:
            await self.store.transaction(statements)
        except Exception:
            if kind == "baseline":
                existing = await self.latest_baseline_job(resource_id)
                if existing and existing["status"] in {"pending", "running"}:
                    return existing["id"]
            raise
        return job_id

    async def claim(self, lease_s):
        now, token = time.time(), uuid.uuid4().hex
        condition = "(status='pending' AND available_at<=?) OR (status='running' AND lease_until<=?)"
        select = (
            f"SELECT id FROM durable_jobs WHERE {condition} ORDER BY created_at LIMIT 1"
            + (" FOR UPDATE SKIP LOCKED" if self.store.backend == "postgres" else "")
        )
        rows = await self.store.transaction(
            [
                (
                    f"UPDATE durable_jobs SET status='running',attempts=attempts+1,lease_token=?,lease_until=?,updated_at=? "
                    f"WHERE id=({select}) RETURNING *",
                    (token, now + lease_s, now, now, now),
                )
            ]
        )
        if not rows[0]:
            return None
        row = rows[0][0]
        try:
            row["data"] = self.unpack("job:" + row["id"], row)
        except ValueError:
            await self.finish(row["id"], token, "failed", "integrity_failure")
            raise
        return row

    async def renew(self, job_id, token, seconds):
        now = time.time()
        rows = await self.store.transaction(
            [
                (
                    "UPDATE durable_jobs SET lease_until=?,updated_at=? WHERE id=? AND lease_token=? "
                    "AND status='running' AND lease_until>? RETURNING id",
                    (now + seconds, now, job_id, token, now),
                )
            ]
        )
        return bool(rows[0])

    async def check(self, job_id, token):
        row = await self.store.query_one(
            "SELECT id FROM durable_jobs WHERE id=? AND lease_token=? AND status='running' AND lease_until>?",
            (job_id, token, time.time()),
        )
        if not row:
            raise JobLeaseLost("durable job ownership lost")

    async def finish(self, job_id, token, status, error=None):
        rows = await self.store.transaction(
            [
                (
                    "UPDATE durable_jobs SET status=?,error=?,lease_until=0,updated_at=? WHERE id=? AND lease_token=? "
                    "AND status='running' RETURNING id",
                    (status, error, time.time(), job_id, token),
                )
            ]
        )
        return bool(rows[0])

    async def abandon(self, job_id, token):
        # Recovery immediately becomes possible, but started effects remain guarded.
        await self.store._write(
            "UPDATE durable_jobs SET lease_until=0 WHERE id=? AND lease_token=?",
            (job_id, token),
        )

    async def heartbeat(self, worker_id):
        await self.store._write(
            "INSERT INTO worker_heartbeats(id,seen_at) VALUES(?,?) "
            "ON CONFLICT(id) DO UPDATE SET seen_at=excluded.seen_at",
            (worker_id, time.time()),
        )

    async def state(self):
        rows = await self.store.query(
            "SELECT status,COUNT(*) AS n FROM durable_jobs GROUP BY status"
        )
        active = await self.store.query_one(
            "SELECT COUNT(*) AS n FROM worker_heartbeats WHERE seen_at>?",
            (time.time() - max(15, self.store.s.JOB_LEASE_S),),
        )
        return {
            "jobs": {row["status"]: row["n"] for row in rows},
            "active_workers": active["n"],
        }

    async def get_job(self, job_id):
        return await self.store.query_one(
            "SELECT id,kind,resource_id,run_id,status,attempts,created_at,updated_at,error FROM durable_jobs WHERE id=?",
            (job_id,),
        )

    async def latest_baseline_job(self, target_id):
        return await self.store.query_one(
            "SELECT id,status,error FROM durable_jobs WHERE kind='baseline' AND resource_id=? ORDER BY created_at DESC LIMIT 1",
            (target_id,),
        )

    async def once(self, scope, step, fingerprint, execute, guard=None):
        if guard:
            await guard()
        rows = await self.store.transaction(
            [
                (
                    "INSERT INTO effect_receipts(scope,step,fingerprint,status,created_at) VALUES(?,?,?,'started',?) "
                    "ON CONFLICT(scope,step) DO NOTHING RETURNING scope",
                    (scope, step, fingerprint, time.time()),
                )
            ]
        )
        if not rows[0]:
            row = await self.store.query_one(
                "SELECT * FROM effect_receipts WHERE scope=? AND step=?", (scope, step)
            )
            if row["fingerprint"] != fingerprint:
                raise IndeterminateEffect(
                    "assessment input changed since its previous attempt"
                )
            if row["status"] != "completed":
                raise IndeterminateEffect(
                    "previous upstream call has no durable completion receipt"
                )
            data = self.unpack(
                "effect:" + scope + ":" + step,
                {"payload": row["result"], "mac": row["mac"]},
            )
            if data["fingerprint"] != fingerprint:
                raise ValueError("effect receipt fingerprint mismatch")
            return json.loads(reveal(data["value"], self.store.s.SENTINEL_SECRET))
        if guard:
            await guard()
        value = await execute()
        if guard:
            await guard()
        encrypted = protect(
            canonical_json(value),
            self.store.s.SENTINEL_SECRET,
            self.store.s.SENTINEL_SALT,
        )
        payload, mac = self.pack(
            "effect:" + scope + ":" + step,
            {"fingerprint": fingerprint, "value": encrypted},
        )
        await self.store._write(
            "UPDATE effect_receipts SET status='completed',result=?,mac=? WHERE scope=? AND step=?",
            (payload, mac, scope, step),
        )
        return value

    async def execution_done(self, run_id, pattern_id):
        return bool(
            await self.store.query_one(
                "SELECT id FROM execution_commits WHERE run_id=? AND pattern_id=?",
                (run_id, pattern_id),
            )
        )

    async def commit_execution(self, run_id, pattern_id, values, counters):
        token, execution_id = uuid.uuid4().hex, uuid.uuid4().hex[:12]
        values = {
            "id": execution_id,
            "run_id": run_id,
            "pattern_id": pattern_id,
            **values,
            "created_at": datetime.now(timezone.utc).isoformat(),
        }
        values = self.store._enc("test_executions", values)
        columns = list(values)
        statements = [
            (
                "INSERT INTO execution_commits(id,run_id,pattern_id) VALUES(?,?,?) "
                "ON CONFLICT(run_id,pattern_id) DO NOTHING RETURNING id",
                (token, run_id, pattern_id),
            ),
            (
                f"INSERT INTO test_executions({','.join(columns)}) SELECT {','.join('?' for _ in columns)} "
                "WHERE EXISTS(SELECT 1 FROM execution_commits WHERE id=?)",
                tuple(values.values()) + (token,),
            ),
        ]
        if counters:
            if not set(counters) <= {
                "total",
                "successful",
                "resisted",
                "inconclusive",
                "blocked",
                "redacted",
            }:
                raise ValueError("invalid counter")
            updates = ",".join(f"{key}={key}+?" for key in counters)
            statements.append(
                (
                    f"UPDATE test_runs SET {updates} WHERE id=? AND EXISTS(SELECT 1 FROM execution_commits WHERE id=?)",
                    tuple(counters.values()) + (run_id, token),
                )
            )
        rows = await self.store.transaction(statements)
        return bool(rows[0])

    async def begin_request(self, scope, key, fingerprint):
        digest, expiry = sha256_hex(key), time.time() + self.store.s.IDEMPOTENCY_TTL_S
        rows = await self.store.transaction(
            [
                (
                    "INSERT INTO idempotency_requests(scope,key_hash,fingerprint,status,expires_at) VALUES(?,?,?,'running',?) "
                    "ON CONFLICT(scope,key_hash) DO NOTHING RETURNING scope",
                    (scope, digest, fingerprint, expiry),
                )
            ]
        )
        if rows[0]:
            return None
        row = await self.store.query_one(
            "SELECT * FROM idempotency_requests WHERE scope=? AND key_hash=?",
            (scope, digest),
        )
        if row["fingerprint"] != fingerprint or row["status"] not in {
            "completed",
            "indeterminate_result",
        }:
            raise IdempotencyConflict(
                "idempotency key is reused, in progress, or has an uncertain outcome"
            )
        data = self.unpack(
            "request:" + scope + ":" + digest,
            {"payload": row["result"], "mac": row["mac"]},
        )
        if data["fingerprint"] != fingerprint:
            raise ValueError("request receipt mismatch")
        return json.loads(reveal(data["response"], self.store.s.SENTINEL_SECRET))

    async def complete_request(self, scope, key, fingerprint, response):
        digest = sha256_hex(key)
        encrypted = protect(
            canonical_json(response),
            self.store.s.SENTINEL_SECRET,
            self.store.s.SENTINEL_SALT,
        )
        payload, mac = self.pack(
            "request:" + scope + ":" + digest,
            {"fingerprint": fingerprint, "response": encrypted},
        )
        status = (
            "indeterminate_result"
            if response.get("final", {}).get("error")
            else "completed"
        )
        await self.store._write(
            "UPDATE idempotency_requests SET status=?,result=?,mac=? "
            "WHERE scope=? AND key_hash=? AND fingerprint=? AND status='running'",
            (status, payload, mac, scope, digest, fingerprint),
        )

    async def fail_request(self, scope, key):
        await self.store._write(
            "UPDATE idempotency_requests SET status='indeterminate' WHERE scope=? AND key_hash=? AND status='running'",
            (scope, sha256_hex(key)),
        )

    async def cleanup(self):
        now = time.time()
        await self.store._write(
            "DELETE FROM idempotency_requests WHERE status='completed' AND expires_at<?",
            (now,),
        )
        await self.store._write(
            "DELETE FROM conversations WHERE expires_at<?",
            (now - max(86400, self.store.s.QUARANTINE_TTL_S * 2),),
        )
        await self.store._write(
            "DELETE FROM worker_heartbeats WHERE seen_at<?", (now - 86400,)
        )
        # Uncertain requests intentionally retain tombstones; an operator must not
        # unknowingly reuse the same key after a potentially effective dispatch.

    async def conversation(self, scope):
        row = await self.store.query_one(
            "SELECT * FROM conversations WHERE scope=?", (scope,)
        )
        if row:
            data = self.unpack("conversation:" + scope, row)
            if data["version"] != row["version"]:
                raise ValueError("conversation version failed integrity verification")
            history = (
                json.loads(reveal(data["history"], self.store.s.SENTINEL_SECRET))
                if data["expires_at"] > time.time()
                else []
            )
            version = data["version"]
        else:
            version, history = 0, []
        signature = chain_hmac(
            self.store.audit_key, scope, {"version": version, "history": history}
        )
        return {"version": version, "history": history, "mac": signature}

    async def save_conversation(self, scope, history, version, lease, ttl):
        from .coordination import LeaseLost

        await lease.check()
        expires = time.time() + ttl
        encrypted = protect(
            canonical_json(history),
            self.store.s.SENTINEL_SECRET,
            self.store.s.SENTINEL_SALT,
        )
        payload, mac = self.pack(
            "conversation:" + scope,
            {"version": version + 1, "history": encrypted, "expires_at": expires},
        )
        if version == 0:
            statement = (
                "INSERT INTO conversations(scope,version,payload,mac,expires_at) VALUES(?,?,?,?,?) "
                "ON CONFLICT(scope) DO NOTHING RETURNING version",
                (scope, 1, payload, mac, expires),
            )
        else:
            statement = (
                "UPDATE conversations SET version=?,payload=?,mac=?,expires_at=? WHERE scope=? AND version=? RETURNING version",
                (version + 1, payload, mac, expires, scope, version),
            )
        rows = await self.store.transaction([statement])
        if not rows[0]:
            raise LeaseLost("conversation compare-and-set failed")
        await lease.check()

    async def put_policy(self, policy):
        payload, mac = self.pack("runtime-policy", policy)
        await self.store._write(
            "INSERT INTO runtime_policy(id,payload,mac) VALUES('active',?,?) "
            "ON CONFLICT(id) DO UPDATE SET payload=excluded.payload,mac=excluded.mac",
            (payload, mac),
        )

    async def policy(self):
        row = await self.store.query_one(
            "SELECT payload,mac FROM runtime_policy WHERE id='active'"
        )
        return self.unpack("runtime-policy", row) if row else None
