"""Transport resource limits, isolated audit identities and streaming-safe metrics."""

from __future__ import annotations

import asyncio
import time

from starlette.responses import JSONResponse

from .identity import actor_context


class RequestBoundary:
    def __init__(self, app, max_body_bytes, body_timeout=15):
        self.app, self.max_body_bytes, self.body_timeout = (
            app,
            max_body_bytes,
            body_timeout,
        )

    async def __call__(self, scope, receive, send):
        if scope["type"] != "http":
            return await self.app(scope, receive, send)
        token = actor_context.set(None)
        began, status = time.monotonic(), 500
        try:
            if scope["method"] in {"POST", "PUT", "PATCH", "DELETE"}:
                chunks, count = [], 0
                deadline = time.monotonic() + self.body_timeout
                while True:
                    try:
                        event = await asyncio.wait_for(
                            receive(), timeout=max(0.001, deadline - time.monotonic())
                        )
                    except TimeoutError:
                        status = 408
                        return await JSONResponse(
                            {"detail": "request body deadline exceeded"},
                            status_code=408,
                        )(scope, receive, send)
                    if event["type"] == "http.disconnect":
                        status = 499
                        return
                    chunk = event.get("body", b"")
                    count += len(chunk)
                    if count > self.max_body_bytes:
                        status = 413
                        return await JSONResponse(
                            {"detail": "request body limit exceeded"}, status_code=413
                        )(scope, receive, send)
                    chunks.append(chunk)
                    if not event.get("more_body", False):
                        break
                body, delivered, upstream_receive = b"".join(chunks), False, receive

                async def bounded_receive():
                    nonlocal delivered
                    if not delivered:
                        delivered = True
                        return {
                            "type": "http.request",
                            "body": body,
                            "more_body": False,
                        }
                    return await upstream_receive()

                receive = bounded_receive

            async def record_send(event):
                nonlocal status
                if event["type"] == "http.response.start":
                    status = event["status"]
                await send(event)

            await self.app(scope, receive, record_send)
        finally:
            actor_context.reset(token)
            deps = getattr(getattr(scope.get("app"), "state", None), "deps", None)
            if deps and deps.telemetry:
                route = getattr(scope.get("route"), "path", "/unmatched")
                method = (
                    scope["method"]
                    if scope["method"]
                    in {"GET", "POST", "PUT", "PATCH", "DELETE", "HEAD", "OPTIONS"}
                    else "OTHER"
                )
                deps.telemetry.requests.labels(method, route, str(status)).inc()
                deps.telemetry.http_seconds.labels(method, route).observe(
                    time.monotonic() - began
                )
