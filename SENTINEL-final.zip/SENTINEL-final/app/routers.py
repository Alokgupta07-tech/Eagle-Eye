"""All HTTP endpoints. Batch mode (judged) + live proxy (demo) share the one engine.
Every decision — both modes — is sealed to the audit chain (P6)."""

from __future__ import annotations

import asyncio
import copy
import json
import re
import time
import uuid
from contextlib import suppress
from typing import Literal

from fastapi import APIRouter, Depends, HTTPException, Query, Request
from fastapi.responses import Response, StreamingResponse
from pydantic import BaseModel, Field, FiniteFloat, field_validator

from . import mocktarget
from .audit import chain_hmac, valid_mac
from .cache import session_key
from .coordination import CapacityExceeded, LeaseLost, SessionBusy, key_for
from .deps import rate_limited, require_permission, require_proxy_key
from .identity import actor_context
from .jobs import policy_snapshot
from .operations import IdempotencyConflict
from .report import build_report, render_leaderboard_markdown, render_markdown
from .secrets import mask
from .ssrf import UnsafeEndpoint, validate_endpoint_url
from .target_client import call_target
from .textnorm import canonical_json, request_inspection_text, sha256_hex


class TargetIn(BaseModel):
    name: str = Field(min_length=1, max_length=120)
    endpoint_url: str = Field(min_length=1, max_length=2048)
    auth_header: str | None = Field(default=None, max_length=8192)
    capabilities: dict = Field(default_factory=dict)


class ChatIn(BaseModel):
    message: str = Field(min_length=1, max_length=16000)
    session_id: str | None = Field(
        default=None, min_length=1, max_length=128, pattern=r"^[A-Za-z0-9_.:-]+$"
    )
    tools: list[dict] | None = Field(default=None, max_length=64)

    @field_validator("message")
    @classmethod
    def valid_unicode(cls, value):
        value.encode("utf-8")
        return value

    @field_validator("tools")
    @classmethod
    def bounded_tools(cls, value):
        if (
            value is not None
            and len(
                json.dumps(value, ensure_ascii=False, allow_nan=False).encode("utf-8")
            )
            > 65536
        ):
            raise ValueError("serialized tool definitions exceed 64 KiB")
        return value


class QuarantineResolution(BaseModel):
    action: Literal["allow_once", "block"]
    reason: str = Field(default="", max_length=1000)


class RunIn(BaseModel):
    target_id: str | None = None
    targets: list[str] | None = Field(default=None, max_length=16)
    categories: list[str] | None = None
    limit: int | None = Field(default=None, ge=1, le=10000)
    enforce_request_block: bool = False


class FusionWeightsIn(BaseModel):
    rules: FiniteFloat
    similarity: FiniteFloat
    obfuscation: FiniteFloat
    judge: FiniteFloat
    response: dict[str, FiniteFloat] | None = (
        None  # {leakage, indicators, drift, judge}
    )


class KBDocIn(BaseModel):
    doc_id: str | None = None
    title: str
    body: str


class FPLabelIn(BaseModel):
    audit_seq: int
    label: Literal["false_positive", "true_positive"]
    labeler: str = Field(default="operator", min_length=1, max_length=80)


def sse(ev: str, data: dict) -> str:
    return f"event: {ev}\ndata: {json.dumps(data, default=str)}\n\n"


def conversation_owner():
    actor = actor_context.get()
    if not actor or actor.get("method") == "anonymous":
        return ""
    return sha256_hex(canonical_json([actor.get("issuer"), actor.get("subject")]))


async def _handle_chat(
    deps,
    target: dict,
    message: str,
    session_id: str,
    emit,
    tools=None,
    approved=None,
    quarantine_id=None,
) -> dict:
    owner = approved.get("conversation_owner", "") if approved else conversation_owner()
    resource = key_for("conversation", target["id"], session_id, owner)
    lock = key_for("conversation-lock", target["id"], session_id, owner)
    try:
        async with deps.coordination.lease(
            lock, deps.settings.SESSION_LEASE_S
        ) as lease:
            state = await deps.operations.conversation(resource)
            history, version = state["history"], state["version"]
            if history or version:
                if not valid_mac(
                    state.get("mac"),
                    chain_hmac(
                        deps.store.audit_key,
                        resource,
                        {"version": version, "history": history},
                    ),
                ):
                    raise ValueError(
                        "conversation history failed integrity verification"
                    )
            if (
                not isinstance(history, list)
                or len(history) % 2
                or any(
                    not isinstance(item, dict)
                    or item.get("role") != ("user" if i % 2 == 0 else "assistant")
                    or not isinstance(item.get("content"), str)
                    for i, item in enumerate(history)
                )
            ):
                raise ValueError("invalid conversation history")
            await deps.refresh_policy()
            scoped = copy.copy(deps)
            scoped.settings = deps.settings.model_copy(deep=True)
            scoped.rules, scoped.sim = copy.copy(deps.rules), copy.copy(deps.sim)
            scoped.engine = copy.copy(deps.engine)
            scoped.engine.d = scoped
            policy_id = sha256_hex(canonical_json(policy_snapshot(scoped.settings)))
            if approved and (
                approved.get("conversation_version") != version
                or approved.get("history") != history
                or approved.get("policy_id") != policy_id
            ):
                await deps.audit.seal(
                    {
                        "type": "quarantine_stale",
                        "quarantine_id": quarantine_id,
                        "target_id": target["id"],
                        "session_id": session_id,
                    }
                )
                raise HTTPException(
                    status_code=409,
                    detail="conversation or policy changed; submit for a fresh review",
                )
            internal_sid = (
                sha256_hex(canonical_json([session_id, owner])) if owner else session_id
            )
            return await _chat_locked(
                scoped,
                target,
                message,
                session_id,
                emit,
                tools,
                approved,
                quarantine_id,
                lease=lease,
                conversation=state,
                conversation_key=resource,
                internal_sid=internal_sid,
                owner=owner,
                policy_id=policy_id,
            )
    except SessionBusy as exc:
        raise HTTPException(
            status_code=409, detail=str(exc), headers={"Retry-After": "1"}
        ) from exc
    except (ValueError, KeyError, TypeError) as exc:
        await deps.audit.seal(
            {
                "type": "conversation_integrity_failure",
                "target_id": target["id"],
                "session_id": session_id,
                "error": type(exc).__name__,
            }
        )
        raise HTTPException(
            status_code=409,
            detail="conversation or policy failed integrity verification",
        ) from exc
    except (LeaseLost, CapacityExceeded) as exc:
        await deps.audit.seal(
            {
                "type": "conversation_unavailable",
                "target_id": target["id"],
                "session_id": session_id,
                "error": type(exc).__name__,
            }
        )
        raise HTTPException(
            status_code=503, detail="conversation state unavailable; no reply served"
        ) from exc


async def _chat_locked(
    deps,
    target: dict,
    message: str,
    session_id: str,
    emit,
    tools: list[dict] | None = None,
    approved: dict | None = None,
    quarantine_id: str | None = None,
    *,
    lease=None,
    conversation=None,
    conversation_key=None,
    internal_sid=None,
    owner="",
    policy_id="",
) -> dict:
    """One live path: inspect, hold REVIEW, dispatch, inspect response, seal, serve.

    An approved snapshot bypasses exactly its original REVIEW once. BLOCK is not
    overridable, response inspection is never bypassed, and no unaudited response
    is served. Both SSE and ordinary JSON use the same implementation.
    """
    t0 = time.perf_counter()
    engine, store, audit, settings = deps.engine, deps.store, deps.audit, deps.settings
    baseline = await store.latest_baseline(target["id"])
    inspection_text = request_inspection_text(message, tools)
    if tools:
        await emit("tool_inspection", {"count": len(tools), "definitions": tools})
    prior_requests = session_key(internal_sid, target["id"])
    if conversation["history"] and not await deps.cache.window(prior_requests):
        await deps.cache.push_many(
            prior_requests,
            [
                item["content"]
                for item in conversation["history"]
                if item["role"] == "user"
            ],
        )
    if approved:
        req = approved["request"]
        if req["band"] != "REVIEW":
            raise HTTPException(
                status_code=409, detail="only a held REVIEW may be approved"
            )
        await engine._replay_events(req, emit)
    else:
        req = await engine.inspect_request(
            inspection_text,
            session_id=internal_sid,
            emit=emit,
            baseline=baseline,
            target_id=target["id"],
        )
    band = req["band"]
    content, action, verdict, error = None, "NONE", None, None
    response_result = None
    history = conversation["history"]
    history_version = conversation["version"]

    if band == "BLOCK":
        action = "BLOCK"
        content = (
            "BLOCKED by SENTINEL — this prompt was classified as an injection attempt. "
            "The target model never saw it. This decision is sealed in the audit chain."
        )
        await emit(
            "log",
            {"level": "bad", "text": "[SYS] Request BLOCKED. No upstream call made."},
        )
    elif band == "REVIEW" and not approved:
        action, verdict = "QUARANTINE", "HELD"
        await emit(
            "log",
            {
                "level": "warn",
                "text": "[SYS] REVIEW quarantined. An authenticated operator must allow once or block.",
            },
        )
    else:
        await emit("stage_started", {"name": "TARGET"})
        await emit("proxied", {"target": target["name"]})
        messages = (
            [{"role": "system", "content": mocktarget.system_prompt(settings)}]
            if target["endpoint_url"].startswith("internal://mock")
            else []
        )
        messages += [*history, {"role": "user", "content": message}]
        upstream_started = time.perf_counter()
        try:
            await lease.check()
            raw_response = await call_target(
                target, messages, internal_sid, settings, tools=tools
            )
            await lease.check()
            await emit(
                "stage_result",
                {
                    "name": "TARGET",
                    "score": 0,
                    "status": "pass",
                    "ms": int((time.perf_counter() - upstream_started) * 1000),
                    "detail": "reply intercepted; not yet served",
                },
            )
            await emit("stage_started", {"name": "RESPONSE GATE"})
            context = "\n".join(
                item["content"] for item in history if item["role"] == "user"
            )
            response_result = await engine.inspect_response(
                pattern=None,
                request_text=context + "\n" + inspection_text,
                response_text=raw_response,
                target=target,
                baseline=baseline,
                session_id=internal_sid,
                emit=emit,
            )
            verdict, action = response_result["verdict"], response_result["action"]
            content = (
                "RESPONSE BLOCKED by SENTINEL — the reply failed the independent response gate. "
                "No target reply was served."
                if action == "BLOCK"
                else response_result["sanitized"]
            )
            await emit(
                "stage_result",
                {
                    "name": "RESPONSE GATE",
                    "score": response_result["risk_score"],
                    "ms": sum(response_result["ms"].values()),
                    "status": "block" if action != "NONE" else "pass",
                    "detail": f"{verdict} · {action}",
                },
            )
            await emit(
                "response_inspection",
                {
                    "verdict": verdict,
                    "action": action,
                    "drift_score": response_result["drift_score"],
                    "session_drift": response_result["session_drift"],
                    "risk_score": response_result["risk_score"],
                    "confidence": response_result["confidence"],
                    "derived_severity": response_result["derived_severity"],
                    "layers": response_result["layers"],
                    "matches": response_result["matches"],
                    "jury_agreement": response_result["jury"]["agreement"],
                    "jury_consensus": response_result["jury"]["consensus"],
                },
            )
        except LeaseLost:
            raise
        except Exception as exc:
            # Fail closed and audit the failure without echoing URLs, credentials
            # or raw target responses in the public error channel.
            error = exc.__class__.__name__
            action, verdict, content = "BLOCK", "ERROR", None
            await emit(
                "log",
                {
                    "level": "bad",
                    "text": "[SYS] Target call or response inspection failed. No reply was served.",
                },
            )
            await emit(
                "stage_result",
                {
                    "name": "RESPONSE GATE",
                    "score": 100,
                    "ms": 0,
                    "status": "block",
                    "detail": "fail closed · inspection unavailable",
                },
            )

    if action in {"BLOCK", "QUARANTINE"} and response_result is None and error is None:
        for name in ("TARGET", "RESPONSE GATE"):
            await emit(
                "stage_result",
                {
                    "name": name,
                    "score": 0,
                    "ms": 0,
                    "status": "skipped",
                    "detail": "not dispatched",
                },
            )
    if band == "BLOCK" or verdict == "SUCCESSFUL" or error:
        await store.add_alert(
            None,
            None,
            "high" if verdict == "SUCCESSFUL" else "medium",
            "Live response compromise"
            if verdict == "SUCCESSFUL"
            else "Live request blocked",
            {"fused": req["fused"], "session_id": session_id, "error": error},
        )

    await lease.check()
    seq = await audit.seal(
        {
            "run_id": None,
            "target_id": target["id"],
            "session_id": session_id,
            "mode": "live",
            "request_payload": message[:500],
            "response_payload": (content or "")[:500],
            "request_hash": sha256_hex(inspection_text),
            "tool_definitions_hash": sha256_hex(canonical_json(tools))
            if tools
            else None,
            "tool_count": len(tools or []),
            "layer_scores": req["scores"],
            "fused_score": req["fused"],
            "confidence": req["confidence"],
            "band": band,
            "rule_hits": [hit["name"] for hit in req["details"].get("rule_hits", [])],
            "session_window_used": req.get("session_window_used", False),
            "semantic_drift": req.get("semantic_drift"),
            "verdict": verdict,
            "action": action,
            "drift_score": (response_result or {}).get("drift_score"),
            "response_risk": (response_result or {}).get("risk_score"),
            "derived_severity": (response_result or {}).get("derived_severity"),
            "jury": (response_result or {}).get("jury") or req.get("jury"),
            "operator_override": "allow_once" if approved else None,
            "quarantine_id": quarantine_id,
            "error": error,
            "latency_ms": int((time.perf_counter() - t0) * 1000),
        }
    )

    hold = None
    if action == "QUARANTINE":
        hold = await store.hold_request(
            {
                "target_id": target["id"],
                "session_id": session_id,
                "message": message,
                "tools": tools,
                "request": req,
                "history": history,
                "conversation_version": history_version,
                "conversation_owner": owner,
                "policy_id": policy_id,
            },
            seq,
        )
        await emit(
            "quarantined",
            {"id": hold["id"], "expires_at": hold["expires_at"], "audit_seq": seq},
        )
    elif not error and response_result is not None:
        # Continue the conversation the user actually saw, not leaked/blocked text.
        updated = [
            *history,
            {"role": "user", "content": message},
            {"role": "assistant", "content": content or "Response withheld."},
        ]
        while (
            len(updated) > 2 * settings.SESSION_WINDOW
            or len(canonical_json(updated).encode()) > settings.SESSION_MAX_BYTES
        ):
            if len(updated) <= 2:
                raise CapacityExceeded(
                    "the response exceeds this conversation's storage budget"
                )
            updated = updated[2:]
        await deps.operations.save_conversation(
            conversation_key, updated, history_version, lease, settings.SESSION_TTL_S
        )
    deps.telemetry.decisions.labels(band, action).inc()
    return {
        "band": band,
        "fused": req["fused"],
        "confidence": req["confidence"],
        "verdict": verdict,
        "action": action,
        "content": content,
        "response_risk": (response_result or {}).get("risk_score"),
        "response_confidence": (response_result or {}).get("confidence"),
        "derived_severity": (response_result or {}).get("derived_severity"),
        "semantic_drift": req.get("semantic_drift"),
        "session_drift": (response_result or {}).get("session_drift"),
        "session_window_used": req.get("session_window_used", False),
        "quarantine": hold,
        "audit_seq": seq,
        "session_id": session_id,
        **(
            {"error": "inspection_unavailable", "detail": "No target reply was served."}
            if error
            else {}
        ),
    }


async def leaderboard_for(deps, comparison_id: str) -> dict | None:
    """One row per target in a comparison, sorted by resistance rate (shared by the API
    and scripts/evidence_run.py)."""
    runs = await deps.store.runs_by_comparison(comparison_id)
    if not runs:
        return None
    board = []
    for run in runs:
        target = await deps.store.get_target(run["target_id"]) or {}
        rep = await build_report(deps, run["id"])
        total = max(1, run["total"])
        board.append(
            {
                "target_id": run["target_id"],
                "target_name": target.get("name"),
                "run_id": run["id"],
                "status": run["status"],
                "total": run["total"],
                "resisted": run["resisted"],
                "compromised": run["successful"],
                "inconclusive": run["inconclusive"],
                "blocked_at_gate": run["blocked"],
                "redacted": run["redacted"],
                "resistance_rate": rep["summary"]["resistance_rate"] if rep else None,
                "gate_block_rate": round(run["blocked"] / total, 3),
                "jury_mode": rep["summary"].get("jury_mode") if rep else None,
                "gate_policy": rep["summary"].get("gate_policy") if rep else None,
                "top_failing_category": (
                    rep["summary"]["top_failing_categories"][0]
                    if rep and rep["summary"]["top_failing_categories"]
                    else None
                ),
            }
        )
    board.sort(
        key=lambda b: (-(b["resistance_rate"] or 0), -(b["gate_block_rate"] or 0))
    )
    return {"comparison_id": comparison_id, "leaderboard": board}


def build_router(settings=None) -> APIRouter:
    r = APIRouter()
    _rl = {
        "proxy": (settings.RATE_LIMIT_PROXY_PER_MIN if settings else 30),
        "runs": (settings.RATE_LIMIT_RUNS_PER_MIN if settings else 6),
    }

    # ---------------- health ----------------
    @r.get("/healthz")
    async def healthz(request: Request):
        d = request.app.state.deps
        try:
            await d.store.query_one("SELECT 1 AS ok")
            db_ok = True
        except Exception:  # noqa: BLE001
            db_ok = False
        counts = await d.store.corpus_counts() if db_ok else {}
        return {
            "ok": db_ok,
            "backend": d.store.backend,
            "cache": d.cache.mode,
            "embedder": d.embedder.mode,
            "jury": d.jury.describe(),
            "jury_mode": d.jury.mode,
            "rules_loaded": d.rules.rule_count,
            "corpus": counts,
            "embeddings_indexed": len(d.sim.ids),
        }

    @r.get("/readyz")
    async def readiness(request: Request):
        d = request.app.state.deps
        checks = {"database": False, "cache": False, "workers": False, "jury": False}
        try:
            checks["database"] = bool(await d.store.query_one("SELECT 1 AS ok"))
            checks["cache"] = bool(await d.cache.ping()) and (
                not d.settings.REQUIRE_REDIS or d.cache.mode == "redis"
            )
            state = await d.operations.state()
            checks["workers"] = (
                d.settings.WORKER_MODE != "external" or state["active_workers"] > 0
            )
            checks["jury"] = not d.settings.REQUIRE_LIVE_JURY or d.jury.mode == "live"
            if (
                getattr(d.jury, "last_quorum", None) is False
                and time.monotonic() - d.jury.last_run < 60
            ):
                checks["jury"] = False
        except Exception:
            pass
        return Response(
            content=json.dumps({"ready": all(checks.values()), "checks": checks}),
            media_type="application/json",
            status_code=200 if all(checks.values()) else 503,
        )

    @r.get("/metrics", dependencies=[Depends(require_permission("operations:read"))])
    async def metrics(request: Request):
        d = request.app.state.deps
        return Response(
            content=d.telemetry.render(await d.operations.state(), d.cache),
            media_type="text/plain; version=0.0.4; charset=utf-8",
        )

    @r.get("/admin/jobs", dependencies=[Depends(require_permission("operations:read"))])
    async def jobs(request: Request):
        d = request.app.state.deps
        return {
            **await d.operations.state(),
            "recent": await d.store.query(
                "SELECT id,kind,resource_id,run_id,status,attempts,created_at,updated_at,error "
                "FROM durable_jobs ORDER BY created_at DESC LIMIT 100"
            ),
        }

    @r.get(
        "/admin/jobs/{job_id}",
        dependencies=[Depends(require_permission("reports:read"))],
    )
    async def job(job_id: str, request: Request):
        item = await request.app.state.deps.operations.get_job(job_id)
        if not item:
            raise HTTPException(status_code=404, detail="job not found")
        return item

    # ---------------- targets & baselines ----------------
    @r.post(
        "/admin/targets", dependencies=[Depends(require_permission("targets:write"))]
    )
    async def create_target(body: TargetIn, request: Request):
        d = request.app.state.deps
        try:
            endpoint = await validate_endpoint_url(body.endpoint_url)
        except UnsafeEndpoint as exc:
            raise HTTPException(status_code=422, detail=str(exc)) from exc
        is_mock = endpoint.url.startswith("internal://mock")
        if is_mock and d.settings.PRODUCTION:
            raise HTTPException(
                status_code=422,
                detail="demonstration targets are disabled in production",
            )
        caps = dict(body.capabilities)
        if body.endpoint_url.startswith("internal://mock-rag"):
            caps["RAG"] = True  # built-in RAG mock auto-declares its capability
        t = await d.store.create_target(
            body.name,
            endpoint.url,
            body.auth_header,
            caps,
            canary_token=d.settings.MOCK_CANARY if is_mock else None,
            seeded=is_mock,
        )

        job_id = await d.start_baseline(t)
        return {
            "target": {**t, "auth_header": mask(t.get("auth_header"))},
            "baselining": "started",
            "job_id": job_id,
        }

    @r.get("/admin/targets", dependencies=[Depends(require_permission("targets:read"))])
    async def list_targets(request: Request):
        d = request.app.state.deps
        out = []
        for t in await d.store.list_targets():
            b = await d.store.latest_baseline(t["id"])
            job = await d.operations.latest_baseline_job(t["id"])
            out.append(
                {
                    **t,
                    "auth_header": mask(t.get("auth_header")),
                    "baseline_version": b["version"] if b else None,
                    "baseline_status": (
                        "running"
                        if job and job["status"] in {"pending", "running"}
                        else (
                            "failed"
                            if job and job["status"] in {"failed", "indeterminate"}
                            else "done"
                            if b
                            else "none"
                        )
                    ),
                }
            )
        return {"targets": out}

    @r.post(
        "/admin/targets/{target_id}/kb",
        dependencies=[Depends(require_permission("targets:write"))],
    )
    async def kb_upsert(target_id: str, body: KBDocIn, request: Request):
        """Live-demo RAG poisoning: add/replace a KB doc of a mock-rag target, then
        ask it an innocent question and watch the RESPONSE gate catch the leak."""
        d = request.app.state.deps
        target = await d.store.get_target(target_id)
        if not target:
            return {"error": "target not found"}
        if not target["endpoint_url"].startswith("internal://mock-rag"):
            return {
                "error": "KB lives on the built-in internal://mock-rag targets "
                "(in-memory, SESS-style) — external targets own their KB"
            }
        doc_id = mocktarget.upsert_kb(body.doc_id, body.title, body.body)
        await d.audit.seal(
            {
                "type": "kb_upsert",
                "target_id": target_id,
                "doc_id": doc_id,
                "title": body.title[:120],
            }
        )
        return {
            "ok": True,
            "doc_id": doc_id,
            "docs": [
                {"doc_id": k, "title": v["title"]} for k, v in mocktarget.KB.items()
            ],
        }

    @r.post(
        "/admin/targets/{tid}/rebaseline",
        dependencies=[Depends(require_permission("targets:write"))],
    )
    async def rebaseline(tid: str, request: Request):
        d = request.app.state.deps
        target = await d.store.get_target(tid)
        if not target:
            return {"error": "target not found"}

        job_id = await d.start_baseline(target)
        return {"ok": True, "baselining": "started", "job_id": job_id}

    # ---------------- rules & feedback loop ----------------
    @r.post(
        "/admin/reload-rules",
        dependencies=[Depends(require_permission("policy:write"))],
    )
    async def reload_rules(request: Request):
        d = request.app.state.deps
        await d.rules.reload(d.store)
        await d.sim.reload(d.store)
        return {
            "status": "ok",
            "loaded": d.rules.rule_count,
            "embeddings_indexed": len(d.sim.ids),
        }

    @r.get(
        "/admin/fusion-weights",
        dependencies=[Depends(require_permission("policy:read"))],
    )
    async def get_fusion_weights(request: Request):
        d = request.app.state.deps
        await d.refresh_policy()
        return {
            "weights": d.settings.fusion_weights,
            "source": d.settings.FUSION_W,
            "response_weights": d.settings.response_weights,
            "response_source": d.settings.FUSION_RESPONSE_W,
        }

    @r.post(
        "/admin/fusion-weights",
        dependencies=[Depends(require_permission("policy:write"))],
    )
    async def set_fusion_weights(body: FusionWeightsIn, request: Request):
        vals = {
            "rules": body.rules,
            "similarity": body.similarity,
            "obfuscation": body.obfuscation,
            "judge": body.judge,
        }
        if any(v < 0 for v in vals.values()) or sum(vals.values()) <= 0:
            return {"error": "weights must be non-negative and not all zero"}
        d = request.app.state.deps
        rw = None
        if body.response is not None:
            rw = {
                k: float(body.response.get(k, 0.0))
                for k in ("leakage", "indicators", "drift", "judge")
            }
            if any(v < 0 for v in rw.values()) or sum(rw.values()) <= 0:
                return {
                    "error": "response weights must be non-negative and not all zero"
                }
        await d.audit.seal(
            {"type": "fusion_weights", "weights": vals, "response_weights": rw}
        )
        policy = {
            "FUSION_W": ",".join(f"{k}:{v}" for k, v in vals.items()),
            "FUSION_RESPONSE_W": (
                ",".join(f"{k}:{v}" for k, v in rw.items())
                if rw is not None
                else d.settings.FUSION_RESPONSE_W
            ),
        }
        await d.operations.put_policy(policy)
        await d.refresh_policy()
        return {
            "ok": True,
            "weights": d.settings.fusion_weights,
            "response_weights": d.settings.response_weights,
        }

    @r.get(
        "/admin/fp-queue", dependencies=[Depends(require_permission("feedback:write"))]
    )
    async def fp_queue(request: Request):
        return {"queue": await request.app.state.deps.store.review_queue()}

    @r.post(
        "/admin/fp-labels", dependencies=[Depends(require_permission("feedback:write"))]
    )
    async def fp_label(body: FPLabelIn, request: Request):
        d = request.app.state.deps
        row = await d.store.query_one(
            "SELECT * FROM audit_log WHERE seq=?", (body.audit_seq,)
        )
        if not row:
            raise HTTPException(status_code=404, detail="audit record not found")
        from .audit import chain_hmac, valid_mac

        try:
            payload = json.loads(row["payload"])
            if not isinstance(payload, dict) or not valid_mac(
                row["hash"], chain_hmac(d.store.audit_key, row["prev_hash"], payload)
            ):
                raise ValueError("invalid audit evidence")
            hits = payload.get("rule_hits", [])
            if not isinstance(hits, list) or not all(
                isinstance(hit, str) for hit in hits
            ):
                raise ValueError("invalid rule evidence")
        except (ValueError, TypeError) as exc:
            raise HTTPException(
                status_code=409, detail="audit record failed integrity verification"
            ) from exc
        labeler = (
            request.state.principal.subject
            if d.settings.AUTH_MODE == "oidc"
            else body.labeler
        )
        lid = await d.store.add_fp_label(body.audit_seq, body.label, labeler)
        await d.audit.seal(
            {
                "type": "fp_label",
                "ref_seq": body.audit_seq,
                "label": body.label,
                "labeler": labeler,
                "rules_discounted": hits if body.label == "false_positive" else [],
            }
        )
        discounted = []
        if body.label == "false_positive" and hits:
            await d.store.discount_rules(hits, factor=0.9, floor=1.0)
            await d.rules.reload(d.store)
            discounted = hits
        return {"ok": True, "label_id": lid, "rules_discounted": discounted}

    # ---------------- batch runs ----------------
    async def _start_one(
        d, target_id, categories, limit, comparison_id=None, enforce: bool = False
    ):
        target = await d.store.get_target(target_id)
        if not target:
            return {"target_id": target_id, "error": "target not found"}
        baseline = await d.store.latest_baseline(target_id)
        await d.refresh_policy()
        from datetime import datetime, timezone

        run_id = uuid.uuid4().hex[:12]
        run = {
            "id": run_id,
            "target_id": target_id,
            "baseline_version": baseline["version"] if baseline else None,
            "comparison_id": comparison_id,
            "gate_policy": "enforcing" if enforce else "permissive",
            "status": "running",
            "started_at": datetime.now(timezone.utc).isoformat(),
        }
        patterns = await d.store.list_patterns(
            statuses=("validated",), categories=categories, limit=limit
        )
        await d.sim.reload(d.store)
        params = {
            "categories": categories,
            "limit": limit,
            "enforce": enforce,
            "policy": policy_snapshot(d.settings),
            "rules": await d.store.list_rules(),
            "baseline": baseline,
            "similarity_fingerprint": d.sim.fingerprint(),
            "patterns": [{"id": p["id"], "hash": p["payload_hash"]} for p in patterns],
        }
        job_id = await d.operations.enqueue(
            "assessment", target_id, params, actor_context.get(), run
        )
        if d.worker:
            d.worker.wakeup.set()
        return {
            "target_id": target_id,
            "target_name": target["name"],
            "run_id": run_id,
            "job_id": job_id,
            "status": "running",
            "baseline_version": run["baseline_version"],
        }

    @r.post(
        "/v1/runs",
        dependencies=[
            Depends(require_permission("runs:write")),
            Depends(rate_limited("runs", _rl["runs"])),
        ],
    )
    async def start_run(body: RunIn, request: Request):
        d = request.app.state.deps
        if d.settings.WORKER_MODE == "disabled":
            raise HTTPException(
                status_code=503, detail="assessment workers are disabled"
            )
        if not body.target_id and not body.targets:
            raise HTTPException(status_code=422, detail="target_id or targets required")
        key = request.headers.get("idempotency-key")
        if d.settings.REQUIRE_IDEMPOTENCY_KEY and not key:
            raise HTTPException(status_code=428, detail="Idempotency-Key is required")
        if key and not re.fullmatch(r"[A-Za-z0-9_.:-]{1,128}", key):
            raise HTTPException(status_code=400, detail="invalid Idempotency-Key")
        scope, fingerprint = (
            key_for("run-create", conversation_owner()),
            sha256_hex(canonical_json(body.model_dump())),
        )
        if key:
            try:
                cached = await d.operations.begin_request(scope, key, fingerprint)
            except IdempotencyConflict as exc:
                raise HTTPException(status_code=409, detail=str(exc)) from exc
            if cached:
                return {**cached, "replayed": True}
        try:
            if body.targets:
                cid = uuid.uuid4().hex[:12]
                started = [
                    await _start_one(
                        d,
                        tid,
                        body.categories,
                        body.limit,
                        cid,
                        body.enforce_request_block,
                    )
                    for tid in dict.fromkeys(body.targets)
                ]
                result = {"comparison_id": cid, "runs": started}
            else:
                started = await _start_one(
                    d,
                    body.target_id,
                    body.categories,
                    body.limit,
                    enforce=body.enforce_request_block,
                )
                result = (
                    started
                    if "error" in started
                    else {
                        "run_id": started["run_id"],
                        "job_id": started["job_id"],
                        "status": "running",
                        "baseline_version": started["baseline_version"],
                    }
                )
            if key:
                await d.operations.complete_request(scope, key, fingerprint, result)
            return result
        except BaseException:
            if key:
                await asyncio.shield(d.operations.fail_request(scope, key))
            raise

    @r.get("/v1/runs", dependencies=[Depends(require_permission("reports:read"))])
    async def list_runs(request: Request):
        return {
            "runs": await request.app.state.deps.store.query(
                "SELECT * FROM test_runs ORDER BY started_at DESC LIMIT 20"
            )
        }

    @r.get(
        "/v1/runs/latest", dependencies=[Depends(require_permission("reports:read"))]
    )
    async def latest_run(request: Request):
        return {"run": await request.app.state.deps.store.latest_run()}

    @r.get(
        "/v1/runs/{run_id}", dependencies=[Depends(require_permission("reports:read"))]
    )
    async def get_run(run_id: str, request: Request):
        return {"run": await request.app.state.deps.store.get_run(run_id)}

    @r.get(
        "/v1/runs/{run_id}/executions",
        dependencies=[Depends(require_permission("reports:read"))],
    )
    async def get_executions(run_id: str, request: Request):
        return {
            "executions": await request.app.state.deps.store.list_executions(run_id)
        }

    @r.get(
        "/v1/reports/compare/{comparison_id}",
        dependencies=[Depends(require_permission("reports:read"))],
    )
    async def compare_report(
        comparison_id: str, request: Request, format: str = Query(default="json")
    ):
        """Leaderboard: one row per target, side by side."""
        board = await leaderboard_for(request.app.state.deps, comparison_id)
        if not board:
            return {"error": "comparison not found"}
        if format == "md":
            return Response(
                render_leaderboard_markdown(board),
                media_type="text/markdown; charset=utf-8",
                headers={
                    "Content-Disposition": f'attachment; filename="sentinel-leaderboard-{comparison_id}.md"'
                },
            )
        return board

    @r.get(
        "/v1/reports/{run_id}",
        dependencies=[Depends(require_permission("reports:read"))],
    )
    async def get_report(
        run_id: str, request: Request, format: str = Query(default="json")
    ):
        d = request.app.state.deps
        rep = await build_report(d, run_id)
        if not rep:
            return {"error": "run not found"}
        if format == "md":
            audit = await d.audit.verify(run_id=run_id)
            md = render_markdown(rep, audit)
            return Response(
                md,
                media_type="text/markdown; charset=utf-8",
                headers={
                    "Content-Disposition": f'attachment; filename="sentinel-report-{run_id}.md"'
                },
            )
        return rep

    # ---------------- audit ----------------
    @r.get("/audit/verify")
    async def audit_verify(request: Request, run_id: str | None = Query(default=None)):
        d = request.app.state.deps
        if d.settings.AUTH_MODE == "oidc":
            await require_permission("reports:read")(request)
        return await d.audit.verify(run_id=run_id)

    @r.get(
        "/admin/quarantine/{quarantine_id}",
        dependencies=[Depends(require_permission("quarantine:resolve"))],
    )
    async def inspect_quarantine(quarantine_id: str, request: Request):
        d = request.app.state.deps
        try:
            held = await d.store.read_quarantine(quarantine_id)
        except ValueError as exc:
            raise HTTPException(
                status_code=409, detail="held request failed integrity verification"
            ) from exc
        if not held:
            raise HTTPException(
                status_code=410,
                detail="quarantine expired, missing or already resolved",
            )
        events = []

        async def emit(event, data):
            events.append({"event": event, "data": data})

        await d.engine._replay_events(held["request"], emit)
        return {
            "quarantine": {
                "id": quarantine_id,
                "expires_at": held["expires_at"],
                "target_id": held["target_id"],
                "session_id": held["session_id"],
                "audit_seq": held["audit_seq"],
            },
            "message": held["message"],
            "tools": held["tools"],
            "events": events,
        }

    @r.post(
        "/admin/quarantine/{quarantine_id}/resolve",
        dependencies=[Depends(require_permission("quarantine:resolve"))],
    )
    async def resolve_quarantine(
        quarantine_id: str, body: QuarantineResolution, request: Request
    ):
        d = request.app.state.deps
        if d.settings.PRODUCTION and not body.reason.strip():
            raise HTTPException(
                status_code=422, detail="an operator reason is required"
            )
        try:
            held = await d.store.claim_quarantine(quarantine_id)
        except ValueError as exc:
            await d.audit.seal(
                {"type": "quarantine_integrity_failure", "quarantine_id": quarantine_id}
            )
            raise HTTPException(
                status_code=409, detail="held request failed integrity verification"
            ) from exc
        if not held:
            raise HTTPException(
                status_code=410,
                detail="quarantine expired, missing or already resolved",
            )
        seq = await d.audit.seal(
            {
                "type": "quarantine_resolution",
                "quarantine_id": quarantine_id,
                "ref_seq": held["audit_seq"],
                "operator_action": body.action,
                "reason": body.reason.strip(),
                "session_id": held["session_id"],
                "target_id": held["target_id"],
            }
        )
        if body.action == "block":
            await d.store.add_alert(
                None,
                None,
                "medium",
                "Operator blocked quarantined request",
                {"quarantine_id": quarantine_id, "audit_seq": seq},
            )
            return {
                "final": {
                    "band": "REVIEW",
                    "fused": held["request"]["fused"],
                    "confidence": held["request"]["confidence"],
                    "verdict": "BLOCKED",
                    "action": "BLOCK",
                    "content": "Blocked and logged by the operator. No upstream call was made.",
                    "session_id": held["session_id"],
                    "audit_seq": seq,
                    "quarantine": None,
                },
                "events": [],
            }
        target = await d.store.get_target(held["target_id"])
        if not target:
            raise HTTPException(status_code=410, detail="target no longer exists")
        events = []

        async def emit(event, data):
            events.append({"event": event, "data": data})

        final = await _handle_chat(
            d,
            target,
            held["message"],
            held["session_id"],
            emit,
            tools=held["tools"],
            approved=held,
            quarantine_id=quarantine_id,
        )
        return {"final": final, "events": events}

    # ---------------- live proxy ----------------
    @r.post(
        "/v1/proxy/{target_id}/chat",
        dependencies=[
            Depends(require_proxy_key),
            Depends(rate_limited("proxy", _rl["proxy"])),
        ],
    )
    async def proxy_chat(
        target_id: str,
        body: ChatIn,
        request: Request,
        stream: bool = Query(default=False),
    ):
        d = request.app.state.deps
        target = await d.store.get_target(target_id)
        if not target:
            raise HTTPException(status_code=404, detail="target not found")
        key = request.headers.get("idempotency-key")
        if d.settings.REQUIRE_IDEMPOTENCY_KEY and not key:
            raise HTTPException(status_code=428, detail="Idempotency-Key is required")
        if key and not re.fullmatch(r"[A-Za-z0-9_.:-]{1,128}", key):
            raise HTTPException(status_code=400, detail="invalid Idempotency-Key")
        owner = conversation_owner()
        scope = key_for("proxy-request", target_id, owner)
        fingerprint = sha256_hex(canonical_json(body.model_dump()))
        cached = None
        if key:
            try:
                cached = await d.operations.begin_request(scope, key, fingerprint)
            except IdempotencyConflict as exc:
                raise HTTPException(status_code=409, detail=str(exc)) from exc
        sid = body.session_id or "live-" + uuid.uuid4().hex
        events = []

        async def execute(emit):
            async def observed(event, data):
                events.append({"event": event, "data": data})
                await emit(event, data)

            try:
                final = await _handle_chat(
                    d, target, body.message, sid, observed, tools=body.tools
                )
                result = {"final": final, "events": events}
                if key:
                    await d.operations.complete_request(scope, key, fingerprint, result)
                return final
            except BaseException:
                if key:
                    await asyncio.shield(d.operations.fail_request(scope, key))
                raise

        if not stream:
            if cached:
                return {**cached, "replayed": True}

            async def discard(event, data):
                # JSON returns the same observed event collection after completion.
                return None

            final = await execute(discard)
            return {"final": final, "events": events}

        if cached:

            async def replay():
                for event in cached["events"]:
                    yield sse(event["event"], event["data"])
                yield sse("final", {**cached["final"], "replayed": True})

            return StreamingResponse(
                replay(),
                media_type="text/event-stream",
                headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"},
            )
        queue = asyncio.Queue(maxsize=64)

        async def emit(event, data):
            await queue.put((event, data))

        async def work():
            cancelled = False
            try:
                final = await execute(emit)
                await queue.put(("final", final))
            except asyncio.CancelledError:
                cancelled = True
                await asyncio.shield(
                    d.audit.seal(
                        {
                            "type": "stream_cancelled",
                            "mode": "live",
                            "target_id": target_id,
                            "session_id": sid,
                            "request_hash": sha256_hex(body.message),
                        }
                    )
                )
                raise
            except Exception as exc:
                await queue.put(
                    (
                        "final",
                        {
                            "error": type(exc).__name__,
                            "status": exc.status_code
                            if isinstance(exc, HTTPException)
                            else 503,
                            "detail": exc.detail
                            if isinstance(exc, HTTPException)
                            else "Inspection failed; no response served.",
                            "content": None,
                        },
                    )
                )
            finally:
                if not cancelled:
                    await queue.put(None)

        async def gen():
            task = asyncio.create_task(work())
            try:
                while True:
                    item = await queue.get()
                    if item is None:
                        break
                    yield sse(*item)
            finally:
                if not task.done():
                    task.cancel()
                with suppress(asyncio.CancelledError):
                    await task

        return StreamingResponse(
            gen(),
            media_type="text/event-stream",
            headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"},
        )

    return r
