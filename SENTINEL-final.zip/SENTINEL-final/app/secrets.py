"""Versioned Fernet credentials, derived with PBKDF2-HMAC-SHA256 (100,000 rounds).

SENTINEL_SALT is used for new ciphertext when configured; otherwise each value gets
an independent 128-bit random salt. The salt travels with the ciphertext, so
rotating the configured salt does not strand existing values. Legacy enc: values
are readable only for migration; all new writes use the versioned KDF.
"""

from __future__ import annotations

import base64
import hashlib
import os
import secrets
from functools import lru_cache

from cryptography.fernet import Fernet, InvalidToken

_PREFIX = "enc:"
_V2 = "enc:v2:"
_ITERATIONS = 100_000


@lru_cache(maxsize=128)
def _fernet(secret: str, salt: bytes) -> Fernet:
    key = hashlib.pbkdf2_hmac(
        "sha256", secret.encode("utf-8"), salt, _ITERATIONS, dklen=32
    )
    return Fernet(base64.urlsafe_b64encode(key))


def available(secret: str) -> bool:
    return bool(secret)


def protect(value: str | None, secret: str, salt: str | None = None) -> str | None:
    if not value:
        return value
    if value.startswith(_V2):
        return value
    if value.startswith(_PREFIX):
        value = reveal(
            value, secret
        )  # read-only legacy migration, never double-encrypt
    if not secret:
        return (
            value  # explicit offline/demo mode; startup warns about plaintext storage
        )
    configured_salt = salt if salt is not None else os.environ.get("SENTINEL_SALT", "")
    raw_salt = (
        configured_salt.encode("utf-8") if configured_salt else secrets.token_bytes(16)
    )
    encoded_salt = base64.urlsafe_b64encode(raw_salt).decode("ascii")
    token = _fernet(secret, raw_salt).encrypt(value.encode("utf-8")).decode("ascii")
    return f"{_V2}{encoded_salt}:{token}"


def reveal(value: str | None, secret: str) -> str | None:
    if not value or not value.startswith(_PREFIX):
        return value
    if not secret:
        raise RuntimeError(
            "auth_header is encrypted but SENTINEL_SECRET is unavailable"
        )
    if value.startswith(_V2):
        try:
            salt_text, token = value[len(_V2) :].split(":", 1)
            salt = base64.b64decode(salt_text, altchars=b"-_", validate=True)
            if not salt or len(salt) > 4096:
                raise ValueError("invalid salt")
            return _fernet(secret, salt).decrypt(token.encode("ascii")).decode("utf-8")
        except (ValueError, UnicodeError) as exc:
            raise InvalidToken("malformed versioned credential") from exc
    # Compatibility for pre-hardening databases. Store.connect upgrades these
    # values to PBKDF2 ciphertext when the original SENTINEL_SECRET is available.
    legacy_key = base64.urlsafe_b64encode(
        hashlib.sha256(secret.encode("utf-8")).digest()
    )
    return (
        Fernet(legacy_key)
        .decrypt(value[len(_PREFIX) :].encode("ascii"))
        .decode("utf-8")
    )


def mask(value: str | None) -> str | None:
    """Return an operator-safe hint, never a plaintext/ciphertext credential."""
    if not value:
        return value
    if value.startswith(_PREFIX):
        return "****(encrypted)"
    scheme, _, rest = value.partition(" ")
    token = rest or scheme
    tail = token[-4:] if len(token) > 8 else ""
    return (f"{scheme} ****{tail}" if rest else f"****{tail}").strip()
