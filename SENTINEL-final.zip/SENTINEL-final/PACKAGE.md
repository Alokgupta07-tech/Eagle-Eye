# SENTINEL — latest completed package

This ZIP contains the latest working-tree source from `arena/01a07271-eagle-eye`,
including all source changes and new files. It supersedes the earlier ZIP.

## Included

- The hardened detection engine and interactive SOC dashboard.
- OIDC/PKCE sign-in, role-based permissions and operator audit identity.
- Durable SQL workers, Redis quotas/leases, idempotency and signed SQL histories.
- Independent evaluation tooling, observable canary/tool assertions and budgets.
- Regression/integration tests, CI, Locust profiles and deployment documentation.

## Offline quick start

Use Python 3.11 or newer. Linux was validated; Windows users can use WSL.
From this extracted directory:

```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
python scripts/demo_setup.py
python run.py
```

Open http://localhost:8000/ for the console or
http://localhost:8000/report.html for assessment reports.

The included `.env` is copied from `.env.example`, using the public demo key
`sentinel-admin-demo-key`. It contains no real provider or installation secrets.
Do not use public demo credentials in production. Follow `docs/PRODUCTION.md` for
private environment injection, OIDC, shared backends and external workers.

## Validation

The completed implementation passed **376 tests**, including real PostgreSQL/Redis
integration tests. Ordinary `pytest -q` runs 362 offline cases and skips the 14
explicit opt-in integration cases. See `docs/TESTING.md` for service configuration
and the command that runs all tests.

Browser workflows passed across desktop, tablet and mobile. A separate two-minute,
10-user mock/offline staging load test completed 5,419 HTTP requests with no failures.
These results do not establish production capacity or real-model detection accuracy.

The public reference evaluation exposed low request-only heuristic recall (5.9%).
No modeled unsafe deliveries were observed, but these are distinct measurements,
not proof of general protection. No paid model evaluation, external IdP deployment
validation or cloud deployment was performed. Read `docs/EVALUATION.md` before
making detection claims or starting a paid evaluation.

## Exclusions and generated data

Git history, local dependencies, caches, runtime databases, private keys, generated
test reports and the obsolete nested `sentinel/` snapshot are not bundled. The
original legacy database is also omitted. `scripts/demo_setup.py` creates a fresh
secure demo database and its independent private audit key. Preserve that key with
backups; never re-sign old evidence to manufacture authenticity.

`SHA256SUMS` contains checksums of the packaged files. From this directory on Linux:

```bash
sha256sum -c SHA256SUMS
```
