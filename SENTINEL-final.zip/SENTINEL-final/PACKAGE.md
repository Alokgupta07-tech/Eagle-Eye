# SENTINEL — latest 160-seed package

This archive packages the current `arena/01a07271-eagle-eye` working tree,
including all uncommitted source changes and new files. It supersedes the
previous downloadable ZIP.

## Latest additions

- 160 curated seeds across 17 categories: 20 direct overrides, 20 RAG injections,
  20 tool-poisoning cases, and 17 language-switching cases.
- 12 new Arabic/Chinese/Hindi candidates and 16 structured tool-schema fixtures.
- 29 weighted rules, ROT13/composed decoding, expanded homoglyphs, spaced keyword
  folding, bounded nested JSON and textual HTML/XML entity inspection.
- JWT, complete/truncated private-key, AWS access/session, password-assignment
  and configurable private-IPv4 response redaction.
- Corpus authoring schema, contributor guide, safe mock-only validation CLI and
  prominent public-demo-key warnings.

The prior OIDC/PKCE/RBAC, durable workers, Redis coordination, idempotency, signed
SQL histories, audit integrity, evaluation budgets, deployment files, CI and
load-test tooling are included as well.

## Offline quick start

Use Python 3.11 or newer. Linux was validated; Windows users can use WSL.
From the extracted directory:

```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
python scripts/seed_corpus.py --check
OPENAI_API_KEY= ANTHROPIC_API_KEY= GOOGLE_API_KEY= CORPUS_VALIDATION_TARGET=internal://mock EMBEDDER=offline python scripts/demo_setup.py
python run.py
```

Open http://localhost:8000/ for the console or
http://localhost:8000/report.html for assessment reports. The demo setup creates
a fresh secure database and private installation audit key; retain that key with
backups.

The included `.env` is copied from the public `.env.example`. It uses
`SENTINEL_ADMIN_KEY=sentinel-admin-demo-key` and contains no real provider,
installation or identity-provider secrets. Replace demo credentials before any
non-local use. Read `docs/PRODUCTION.md` for OIDC, shared services and secret
injection. A provider API key is not the dashboard admin key.

## Tests and validation boundaries

The completed source passed 480 tests, including 15 real PostgreSQL/Redis
integration tests. The default `pytest -q` runs 465 offline tests and skips the 15
explicit opt-in integration tests. See `docs/TESTING.md` for the real-service
configuration and the command that runs all tests. Browser workflows also passed.

Fresh local canary validation checked 160 seeds plus 244 mutations: 355 cases were
reproduced and 49 were retained as unreproduced (`dead`, the legacy status name).
No live-model validation is claimed. New additions are labelled AI-assisted;
the original 92 seeds and reference evaluation set remain unchanged.

The earlier 5.9% request-only reference recall and mock-only load results are
historical, not current accuracy or production-capacity guarantees. Use independent
held-out data, approved model accounts and explicit spending limits before making
production protection claims. No paid model evaluations or cloud deployment were
performed in this implementation.

## What is not included

Git history, local dependencies, caches, runtime databases, private keys,
generated test reports and the obsolete nested `sentinel/` project snapshot are
excluded. The legacy database is not distributed or re-signed. All active source,
tests, scripts, seeds and setup documentation are included.

See `CONTRIBUTING.md` for seed fields, taxonomy/provenance rules, supported mutation
names, validation requirements and benign counterexamples.

`SHA256SUMS` records the packaged files. On Linux, verify before changing files:

```bash
sha256sum -c SHA256SUMS
```
