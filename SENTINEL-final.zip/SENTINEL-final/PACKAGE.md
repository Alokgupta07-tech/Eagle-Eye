# SENTINEL final package

This archive contains the completed hardened application from the current
`arena/01a07271-eagle-eye` working tree, including all uncommitted source changes,
new regression tests, the SOC dashboard, seeds, scripts, and documentation.

## Start the offline demo

Use Python 3.11 or newer (validated on Linux; Windows users can use WSL).
From this extracted directory, install dependencies in a virtual environment:

```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
python scripts/demo_setup.py
python run.py
```

Then open http://localhost:8000/ for the console, or
http://localhost:8000/report.html for assessment reports.

The included `.env` is a copy of the public demo configuration in `.env.example`.
Both use `SENTINEL_ADMIN_KEY=sentinel-admin-demo-key`. The console is configured
for that demo key. Replace public demo credentials and configure independent
secrets before deployment; see `docs/HARDENING.md`.

## Validate

```bash
pytest -q
```

The final source passed all 295 regression tests. The real-browser smoke suite
also passed for benign/attack requests, quarantine approvals and blocking,
restoration after reload, key unlock, tool inspection, redaction, authenticated
report downloads, keyboard controls, and desktop/tablet/mobile layouts.
For browser test setup, see the Validation section in `README.md`.
Live provider, PostgreSQL, and Redis deployment validation was not performed.

## What is intentionally not bundled

- Git history, installed dependencies, caches, and developer browser binaries.
- Runtime databases, installation-specific audit keys, and private credentials.
- The repository's obsolete nested `sentinel/` source snapshot. Use this package's
  top-level `app/`, `static/`, and `tests/` directories, which contain the final work.

The repository's legacy `data/sentinel.db` was not modified and is not distributed
in this clean package. Run `scripts/demo_setup.py` to generate a fresh
`data/sentinel-secure.db`, its independent private audit key, and demonstration
assessments. Do not re-sign legacy evidence or lose the generated key.

`SHA256SUMS` records checksums for the packaged files. On Linux, run
`sha256sum -c SHA256SUMS` from this directory to check them.
