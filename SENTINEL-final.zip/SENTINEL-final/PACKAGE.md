# SENTINEL — final Groq-ready source package

This ZIP contains the latest completed working-tree source from
`arena/01a07271-eagle-eye`, including uncommitted changes and new files.
It supersedes the previous download.

## Included

- 160 curated attack seeds, 29 rules, ROT13/composed decoding, expanded Unicode
  normalization, structured tool fixtures and additional leakage protection.
- Interactive seven-stage SOC console, quarantine controls and assessment reports.
- OIDC/PKCE/RBAC, durable workers, Redis coordination, idempotency, signed SQL
  conversation histories, HMAC audit integrity, metrics and production safeguards.
- Groq-hosted GPT-OSS 120B integration, with GPT-OSS 20B as an alternative:
  target/jury adapters, strict structured judgments, quota handling and no paid
  provider/model fallback.
- Independent evaluation tools, a Groq-only free-tier request/token budget,
  tests, CI, load profiles and deployment documentation.

## Offline quick start

Use Python 3.11 or newer. Linux was validated; Windows users can use WSL.
From this extracted directory:

```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
python scripts/seed_corpus.py --check
OPENAI_API_KEY= ANTHROPIC_API_KEY= GOOGLE_API_KEY= GROQ_API_KEY= GROQ_FREE_PLAN_CONFIRMED=false CORPUS_VALIDATION_TARGET=internal://mock EMBEDDER=offline python scripts/demo_setup.py
OPENAI_API_KEY= ANTHROPIC_API_KEY= GOOGLE_API_KEY= GROQ_API_KEY= GROQ_FREE_PLAN_CONFIRMED=false CORPUS_VALIDATION_TARGET=internal://mock EMBEDDER=offline python run.py
```

Open http://localhost:8000/ for the console and
http://localhost:8000/report.html for reports. The demo setup creates a fresh
secure database and a private installation audit key. Retain that key with backups.

The included `.env` is copied from the public `.env.example`; it deliberately
uses `SENTINEL_ADMIN_KEY=sentinel-admin-demo-key` for the offline demo. Never expose
that key on a non-local service. No real provider/installation credentials are
included. The private `.env.groq` file is intentionally NOT in this package.

## Activate Groq privately

1. Copy `.env.groq.example` to `.env.groq` (Git-ignored).
2. Put your own Groq API key in that private file. Verify your account is on its
   Free plan before setting `GROQ_FREE_PLAN_CONFIRMED=true`.
3. Generate two distinct private SENTINEL access keys (at least 32 characters)
   for `SENTINEL_ADMIN_KEY` and `SENTINEL_PROXY_KEY`. Never reuse the provider key.
4. Stop any earlier local server on the selected port, then run:

```bash
python scripts/run_free_ai.py --env-file .env.groq --check
python scripts/run_free_ai.py --env-file .env.groq
```

5. Enter the SENTINEL access keys in the console's Access keys panel, then choose
   Free AI option > Register & select model. Registration makes no provider call.

`--check` performs local configuration validation only. The API key does not let
SENTINEL verify your account's billing tier. Hosted requests leave your machine;
review Groq's account limits/data policy before sending sensitive information.
One Groq judge is not a three-provider production jury. No paid fallback or plan
upgrade is performed. Read `docs/FREE_AI.md` for complete instructions.

## Validation and limitations

The completed implementation passed 515 tests, including 15 real PostgreSQL/Redis
integration tests. Default `pytest -q` runs 500 offline tests and skips the 15
explicit opt-in integration tests. See `docs/TESTING.md` for real-service setup.
The browser workflows, including the new free-model setup/selection controls,
also passed.

Provider transport responses in the integration tests were synthetic. No actual
Groq account, paid model evaluation, external IdP deployment validation or cloud
deployment was performed. The model is ready to configure, not already connected.

A prior fresh local canary run reproduced 355 of 404 seed-plus-mutation cases;
49 were retained as unreproduced. That is fixture behavior, not general detection
accuracy. The documented earlier reference recall/load figures are historical,
not measurements of this Groq integration. Use independent, authorized and
explicitly budgeted real-model evaluations before production protection claims.

## Excluded from this clean source ZIP

Git history, local dependencies, caches, runtime databases, private keys,
private environment files, generated test reports and the obsolete nested
`sentinel/` snapshot are omitted. All active source, tests, scripts, safe example
configuration and documentation are included.

Start with `README.md`, `CONTRIBUTING.md`, `docs/FREE_AI.md`,
`docs/PRODUCTION.md`, `docs/EVALUATION.md` and `docs/TESTING.md`.

`SHA256SUMS` records the packaged files. Before editing them, verify on Linux with:

```bash
sha256sum -c SHA256SUMS
```
